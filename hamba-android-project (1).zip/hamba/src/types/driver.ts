import { LocationPoint, RideCategory } from './index';

export type DriverDutyStatus =
  | 'offline'
  | 'online_searching'
  | 'request_received'
  | 'navigating_to_pickup'
  | 'arrived_at_pickup'
  | 'in_trip'
  | 'trip_completed';

export interface DriverRideRequest {
  id: string;
  passengerName: string;
  passengerPhoto: string;
  passengerRating: number;
  passengerTotalTrips: number;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  category: RideCategory;
  distanceToPickupKm: number;
  pickupEtaMin: number;
  tripDistanceKm: number;
  tripDurationMin: number;
  estimatedNetEarnings: number;
  surgeBonus: number;
  paymentMethod: 'card' | 'cash' | 'wallet';
  safetyPin: string;
  expiresInSeconds: number;
  specialNote?: string;
}

export interface DriverActiveTrip {
  request: DriverRideRequest;
  currentPhase: 'to_pickup' | 'at_pickup' | 'in_transit' | 'dropped_off';
  driverLat: number;
  driverLng: number;
  driverHeading: number;
  routeCoordinates: [number, number][];
  routeIndex: number;
  arrivedAtPickupTime: number | null;
  startedTripTime: number | null;
  completedTripTime: number | null;
  pinVerified: boolean;
  currentInstruction: string;
  remainingEtaMin: number;
  remainingDistanceKm: number;
  speedKmh: number;
  waitingSeconds: number;
}

export interface DriverEarningsData {
  todayEarnings: number;
  todayTrips: number;
  todayOnlineMinutes: number;
  weeklyEarnings: number;
  weeklyGoal: number;
  driverBalance: number;
  tipsToday: number;
  surgeBonusToday: number;
  dailyBreakdown: {
    day: string;
    amount: number;
    trips: number;
  }[];
  monthlyBreakdown?: {
    month: string;
    shortMonth: string;
    year: number;
    amount: number;
    trips: number;
    hoursOnline: number;
  }[];
  recentTrips: {
    id: string;
    time: string;
    date: string;
    passengerName: string;
    pickup: string;
    dropoff: string;
    netPayout: number;
    grossFare: number;
    distanceKm: number;
    durationMin: number;
    paymentType: string;
    tip: number;
  }[];
}

export interface DriverPerformanceData {
  acceptanceRate: number;
  cancellationRate: number;
  driverRating: number;
  totalTrips: number;
  tier: 'Standard' | 'Silver' | 'Gold' | 'Platinum Partner';
  tierProgress: number; // 0-100
  commissionRate: number; // e.g. 12%
  compliments: {
    label: string;
    count: number;
  }[];
}

export interface SurgeZone {
  id: string;
  name: string;
  area: string;
  lat: number;
  lng: number;
  radiusMeters: number;
  surgeMultiplier: number;
  bonusAmount: number;
  demandLevel: 'high' | 'very_high' | 'extreme';
}

export interface DriverVerificationData {
  isVerified: boolean;
  phoneNumber: string;
  selfieUrl: string;
  email?: string;
  verifiedAt?: string;
  driverName?: string;
}

