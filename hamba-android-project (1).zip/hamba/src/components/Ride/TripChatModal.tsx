import React, { useState } from 'react';
import { ArrowLeft, Phone, Send } from 'lucide-react';
import { QUICK_CHAT_PRESETS } from '../../data/mockData';
import { sound } from '../../services/audio';
import { ChatMessage, Driver } from '../../types';

interface TripChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  driver: Driver;
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
}

export const TripChatModal: React.FC<TripChatModalProps> = ({
  isOpen,
  onClose,
  driver,
  messages,
  onSendMessage,
}) => {
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    onSendMessage(text.trim());
    setInputText('');
    sound.playTap();
  };

  return (
    <div className="absolute inset-0 z-50 bg-neutral-950 flex flex-col animate-in slide-in-from-bottom duration-200">
      {/* Header */}
      <div className="p-3.5 border-b border-neutral-800 bg-neutral-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1.5 -ml-1 text-neutral-400 hover:text-white rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="relative">
            <img
              src={driver.photo}
              alt={driver.name}
              className="w-9 h-9 rounded-full object-cover border border-emerald-500"
            />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 absolute bottom-0 right-0 border-2 border-neutral-900" />
          </div>
          <div>
            <div className="font-bold text-sm text-neutral-100">{driver.name}</div>
            <div className="text-[11px] text-neutral-400">
              {driver.carModel} · {driver.licensePlate}
            </div>
          </div>
        </div>

        <button
          onClick={() => alert(`Calling driver ${driver.name} at ${driver.phoneNumber}`)}
          className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-sky-400 border border-neutral-700"
        >
          <Phone className="w-4 h-4" />
        </button>
      </div>

      {/* Messages List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {/* Encrypted Notice */}
        <div className="text-center">
          <span className="text-[10px] text-neutral-500 bg-neutral-900 border border-neutral-800/80 px-2.5 py-1 rounded-full">
            In-app chat is end-to-end encrypted for your safety
          </span>
        </div>

        {messages.map((msg) => {
          const isUser = msg.sender === 'rider';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-br-xs'
                    : 'bg-neutral-850 text-neutral-100 border border-neutral-750 rounded-bl-xs'
                }`}
              >
                {msg.text}
              </div>
              <span className="text-[9px] text-neutral-500 mt-1 px-1">{msg.time}</span>
            </div>
          );
        })}
      </div>

      {/* Quick Replies Carousel */}
      <div className="p-2 border-t border-neutral-850 bg-neutral-900/40 overflow-x-auto flex gap-1.5 no-scrollbar">
        {QUICK_CHAT_PRESETS.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(preset)}
            className="flex-shrink-0 text-[11px] font-medium px-3 py-1.5 rounded-full bg-neutral-850 hover:bg-neutral-800 text-neutral-300 border border-neutral-750 transition-colors"
          >
            {preset}
          </button>
        ))}
      </div>

      {/* Input Field */}
      <div className="p-3 border-t border-neutral-800 bg-neutral-900 flex items-center gap-2">
        <input
          type="text"
          placeholder="Message driver..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend(inputText)}
          className="flex-1 bg-neutral-850 text-neutral-100 text-xs px-3.5 py-2.5 rounded-xl border border-neutral-750 focus:outline-none focus:border-emerald-500"
        />
        <button
          onClick={() => handleSend(inputText)}
          disabled={!inputText.trim()}
          className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-neutral-950 transition-colors"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
