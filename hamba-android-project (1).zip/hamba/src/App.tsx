/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  Bell,
  Calendar,
  Car,
  Clock,
  Compass,
  Layers,
  MapPin,
  Menu,
  Moon,
  Navigation,
  PictureInPicture,
  Search,
  Shield,
  ShieldAlert,
  Sparkles,
  Sun,
  User,
  Zap,
} from 'lucide-react';
import { ActivityView } from './components/Activity/ActivityView';
import { HambaDriverApp } from './components/Driver/HambaDriverApp';
import { LiveMap } from './components/Map/LiveMap';
import { PaymentDrawer } from './components/Payment/PaymentDrawer';
import { ActiveTripCard } from './components/Ride/ActiveTripCard';
import { DriverApproachingAlert } from './components/Ride/DriverApproachingAlert';
import { RideCategorySelector } from './components/Ride/RideCategorySelector';
import { ScheduleRideModal } from './components/Ride/ScheduleRideModal';
import { TripChatModal } from './components/Ride/TripChatModal';
import { TripReceiptModal } from './components/Ride/TripReceiptModal';
import { WhereToModal } from './components/Ride/WhereToModal';
import { SafetyModal } from './components/Safety/SafetyModal';
import { SosDriverModal } from './components/Safety/SosDriverModal';
import { FloatingPipWidget } from './components/UI/FloatingPipWidget';
import { MobileFrame } from './components/UI/MobileFrame';
import { WalletView } from './components/Wallet/WalletView';
import { ClientRideRewardsBadge } from './components/Loyalty/ClientRideRewardsBadge';
import { ClientRideRewardsModal } from './components/Loyalty/ClientRideRewardsModal';
import { PWAInstallButton } from './components/PWA/PWAInstallButton';
import { OfflineIndicator } from './components/PWA/OfflineIndicator';
import confetti from 'canvas-confetti';
import {
  INITIAL_DROPOFF,
  INITIAL_PAST_RIDES,
  INITIAL_PAYMENT_METHODS,
  INITIAL_PICKUP,
  INITIAL_SCHEDULED_RIDES,
  INITIAL_WALLET_TRANSACTIONS,
  MOCK_DRIVERS,
  NATIONWIDE_LOCATIONS,
  RIDE_CATEGORIES,
} from './data/mockData';
import { sound } from './services/audio';
import {
  ActiveTrip,
  ChatMessage,
  ClientLoyaltyData,
  Driver,
  LocationPoint,
  PastRideRecord,
  PaymentMethod,
  RideCategory,
  ScheduledRideRecord,
  TripStatus,
  WalletTransaction,
} from './types';
import {
  formatCurrency,
  generateRoutePoints,
  getDistanceKm,
  getHeading,
} from './utils/geo';
import {
  requestNotificationPermission,
  sendBrowserPushNotification,
} from './utils/notifications';

export default function App() {
  // Mode switcher: Passenger (Rider) vs Hamba Driver (Partner)
  const [appMode, setAppMode] = useState<'rider' | 'driver'>('rider');

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'rides' | 'activity' | 'wallet'>('rides');

  // Client Ride Rewards Loyalty Program (10 Rides = 1 Free Ride up to R50, 7 Days Validity)
  const [loyalty, setLoyalty] = useState<ClientLoyaltyData>(() => {
    try {
      const saved = localStorage.getItem('hamba_client_loyalty');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.freeRideExpiresAt && Date.now() > parsed.freeRideExpiresAt) {
          return {
            ...parsed,
            freeRidesAvailable: 0,
            freeRideUnlockedAt: null,
            freeRideExpiresAt: null,
          };
        }
        return parsed;
      }
    } catch {}
    return {
      completedRidesCount: 7, // Default 7 of 10 completed rides
      freeRidesAvailable: 0,
      freeRideUnlockedAt: null,
      freeRideExpiresAt: null,
      maxDiscount: 50,
      totalFreeRidesRedeemed: 0,
    };
  });
  const [isRewardsModalOpen, setIsRewardsModalOpen] = useState<boolean>(false);
  const isFreeRideAppliedToTripRef = useRef<boolean>(false);

  // Sync loyalty to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('hamba_client_loyalty', JSON.stringify(loyalty));
    } catch {}
  }, [loyalty]);

  // South Africa Nationwide Geo state
  const saCenter: [number, number] = [-26.1076, 28.0567]; // Gauteng / SA hub baseline
  const saZoom = 14;
  const [pickup, setPickup] = useState<LocationPoint>(INITIAL_PICKUP);
  const [dropoff, setDropoff] = useState<LocationPoint | null>(null);
  const [nearbyDrivers, setNearbyDrivers] = useState<Driver[]>(MOCK_DRIVERS);

  // App UI state
  const [isNightMap, setIsNightMap] = useState<boolean>(true);
  const [isWhereToOpen, setIsWhereToOpen] = useState<boolean>(false);
  const [isPaymentDrawerOpen, setIsPaymentDrawerOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isSafetyOpen, setIsSafetyOpen] = useState<boolean>(false);
  const [isSosModalOpen, setIsSosModalOpen] = useState<boolean>(false);
  const [isFloatingPipOpen, setIsFloatingPipOpen] = useState<boolean>(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState<boolean>(false);
  const [scheduleNotice, setScheduleNotice] = useState<string | null>(null);
  const [isDriverOneMinuteAlertOpen, setIsDriverOneMinuteAlertOpen] = useState<boolean>(false);
  const hasNotifiedOneMinuteAwayRef = useRef<boolean>(false);

  // Payment methods & wallet state
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(INITIAL_PAYMENT_METHODS);
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>(INITIAL_PAYMENT_METHODS[0]);
  const [walletBalance, setWalletBalance] = useState<number>(420.0);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(
    INITIAL_WALLET_TRANSACTIONS
  );
  const [pastRides, setPastRides] = useState<PastRideRecord[]>(INITIAL_PAST_RIDES);
  const [scheduledRides, setScheduledRides] = useState<ScheduledRideRecord[]>(INITIAL_SCHEDULED_RIDES);

  // Ride booking & Category
  const [selectedCategory, setSelectedCategory] = useState<RideCategory>(RIDE_CATEGORIES[0]);
  const [tripStatus, setTripStatus] = useState<TripStatus>('idle');
  const [activeTrip, setActiveTrip] = useState<ActiveTrip | null>(null);

  // Chat messages during active ride
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  // Simulation speed (1x, 2x, 5x)
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);

  // Interval reference for live driver movement
  const driverMovementTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Keep-alive heartbeat: Operates in background & over other apps without shutting down when online
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        // When user switches to other open apps, maintain active tracking in floating overlay
        if (tripStatus !== 'idle') {
          setIsFloatingPipOpen(true);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);

    // Audio context ping keep-alive
    const keepAlivePing = setInterval(() => {
      // Periodic ping prevents browser tab sleep
    }, 3000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      clearInterval(keepAlivePing);
    };
  }, [tripStatus]);

  // Subtle roaming motion of nearby drivers on idle screen
  useEffect(() => {
    if (tripStatus !== 'idle') return;
    const interval = setInterval(() => {
      setNearbyDrivers((prev) =>
        prev.map((d) => {
          const deltaLat = (Math.random() - 0.5) * 0.0006;
          const deltaLng = (Math.random() - 0.5) * 0.0006;
          const newLat = d.currentLat + deltaLat;
          const newLng = d.currentLng + deltaLng;
          return {
            ...d,
            currentLat: newLat,
            currentLng: newLng,
            heading: getHeading(d.currentLat, d.currentLng, newLat, newLng) || d.heading,
          };
        })
      );
    }, 3500);

    return () => clearInterval(interval);
  }, [tripStatus]);

  // Initiate booking a ride
  const handleStartBooking = () => {
    sound.playTap();
    setIsWhereToOpen(true);
  };

  // Destination confirmed from search
  const handleConfirmDestination = () => {
    setIsWhereToOpen(false);
    if (!dropoff) {
      setDropoff(INITIAL_DROPOFF);
    }
    setTripStatus('selecting_ride');
  };

  // User confirms category and taps "Confirm Hamba"
  const handleConfirmRide = (fare: number, discount: number) => {
    if (!dropoff) return;

    sound.playTap();
    hasNotifiedOneMinuteAwayRef.current = false;
    setIsDriverOneMinuteAlertOpen(false);
    requestNotificationPermission().catch(() => {});
    setTripStatus('searching_driver');

    // Generate random 4-digit safety PIN
    const safetyPin = Math.floor(1000 + Math.random() * 9000).toString();

    // Select closest driver
    const assignedDriver = nearbyDrivers[0] || MOCK_DRIVERS[0];

    // Compute route waypoints:
    // 1. Waypoints from Driver's current position to Pickup
    const driverToPickupRoute = generateRoutePoints(
      [assignedDriver.currentLat, assignedDriver.currentLng],
      [pickup.lat, pickup.lng],
      16
    );

    // 2. Waypoints from Pickup to Dropoff
    const tripRoute = generateRoutePoints([pickup.lat, pickup.lng], [dropoff.lat, dropoff.lng], 30);

    const distance = Math.max(1.8, getDistanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng));

    const newTrip: ActiveTrip = {
      id: `hb-${Math.floor(100000 + Math.random() * 900000)}`,
      category: selectedCategory,
      pickup,
      dropoff,
      driver: { ...assignedDriver },
      status: 'searching_driver',
      safetyPin,
      etaMinutes: selectedCategory.etaMinutes,
      distanceKm: distance,
      estimatedFare: fare + discount,
      finalFare: fare,
      paymentMethod: selectedPayment,
      requestTime: Date.now(),
      routeCoordinates: driverToPickupRoute,
      driverCoordinates: [assignedDriver.currentLat, assignedDriver.currentLng],
      driverHeading: assignedDriver.heading,
      driverStepIndex: 0,
      tripStepIndex: 0,
      tipAmount: 0,
      discountAmount: discount,
    };

    setActiveTrip(newTrip);

    // Consume free ride voucher if applied to this trip
    if (isFreeRideAppliedToTripRef.current) {
      setLoyalty((prev) => ({
        ...prev,
        freeRidesAvailable: Math.max(0, prev.freeRidesAvailable - 1),
        freeRideUnlockedAt: null,
        freeRideExpiresAt: null,
        completedRidesCount: 0,
        totalFreeRidesRedeemed: prev.totalFreeRidesRedeemed + 1,
      }));
    }

    // Initial driver message setup
    setChatMessages([
      {
        id: 'msg-1',
        sender: 'system',
        text: `Trip confirmed. Safety PIN: ${safetyPin}. Verify PIN before entry.`,
        time: 'Just now',
      },
    ]);

    // Simulate driver matching after 2.2 seconds
    setTimeout(() => {
      sound.playDriverFound();
      setTripStatus('driver_arriving');
      setActiveTrip((prev) =>
        prev
          ? {
              ...prev,
              status: 'driver_arriving',
              etaMinutes: Math.max(2, prev.category.etaMinutes),
            }
          : null
      );

      // Driver greeting
      setTimeout(() => {
        sound.playMessagePop();
        setChatMessages((prevMsgs) => [
          ...prevMsgs,
          {
            id: `msg-${Date.now()}`,
            sender: 'driver',
            text: `Hello! I'm on my way in a ${assignedDriver.carColor} ${assignedDriver.carModel}. See you shortly!`,
            time: 'Just now',
          },
        ]);
      }, 1500);
    }, 2200);
  };

  // Real-Time Driver Tracking Engine (animates driver along waypoints)
  useEffect(() => {
    if (!activeTrip) return;

    if (driverMovementTimerRef.current) {
      clearInterval(driverMovementTimerRef.current);
      driverMovementTimerRef.current = null;
    }

    const intervalTime = Math.max(200, 1000 / simulationSpeed);

    if (activeTrip.status === 'driver_arriving') {
      // Driver moving to pickup
      const route = activeTrip.routeCoordinates;
      let currentIndex = activeTrip.driverStepIndex;

      driverMovementTimerRef.current = setInterval(() => {
        if (currentIndex < route.length - 1) {
          currentIndex++;
          const nextCoord = route[currentIndex];
          const prevCoord = route[currentIndex - 1];
          const newHeading = getHeading(prevCoord[0], prevCoord[1], nextCoord[0], nextCoord[1]);
          const remainingSteps = route.length - 1 - currentIndex;
          const updatedEta = Math.max(1, Math.ceil(remainingSteps / 5));

          // Trigger browser push notification & subtle visual alert when driver is exactly 1 minute away
          if (updatedEta === 1 && !hasNotifiedOneMinuteAwayRef.current) {
            hasNotifiedOneMinuteAwayRef.current = true;
            sound.playDriverOneMinuteAway();
            setIsDriverOneMinuteAlertOpen(true);

            // Trigger Browser Push Notification
            sendBrowserPushNotification({
              title: `HAMBA · ${activeTrip.driver.name} is 1 min away!`,
              body: `${activeTrip.driver.carColor} ${activeTrip.driver.carModel} (${activeTrip.driver.licensePlate}) is approaching ${activeTrip.pickup.name}. Head to pickup!`,
              icon: activeTrip.driver.photo,
              tag: 'driver-1min-arrival',
            });
          }

          setActiveTrip((prev) =>
            prev
              ? {
                  ...prev,
                  driverCoordinates: nextCoord,
                  driverHeading: newHeading,
                  driverStepIndex: currentIndex,
                  etaMinutes: updatedEta,
                }
              : null
          );
        } else {
          // Driver has arrived at pickup!
          if (driverMovementTimerRef.current) clearInterval(driverMovementTimerRef.current);
          setIsDriverOneMinuteAlertOpen(false);
          sound.playDriverArrived();
          setTripStatus('driver_arrived');
          setActiveTrip((prev) =>
            prev
              ? {
                  ...prev,
                  status: 'driver_arrived',
                  driverCoordinates: [prev.pickup.lat, prev.pickup.lng],
                  etaMinutes: 0,
                }
              : null
          );

          // Rider notification
          sound.playMessagePop();
          setChatMessages((prevMsgs) => [
            ...prevMsgs,
            {
              id: `msg-${Date.now()}`,
              sender: 'driver',
              text: `I have arrived at ${activeTrip.pickup.name}! Hazard lights are blinking.`,
              time: 'Just now',
            },
          ]);

          // Automatically start trip after 3.5 seconds
          setTimeout(() => {
            if (!activeTrip.dropoff) return;
            const fullTripRoute = generateRoutePoints(
              [activeTrip.pickup.lat, activeTrip.pickup.lng],
              [activeTrip.dropoff.lat, activeTrip.dropoff.lng],
              32
            );
            setTripStatus('in_progress');
            setActiveTrip((prev) =>
              prev
                ? {
                    ...prev,
                    status: 'in_progress',
                    routeCoordinates: fullTripRoute,
                    driverCoordinates: fullTripRoute[0],
                    tripStepIndex: 0,
                    etaMinutes: Math.round((prev.distanceKm / 32) * 60) + 2,
                  }
                : null
            );
          }, 3500);
        }
      }, intervalTime);
    } else if (activeTrip.status === 'in_progress') {
      // Driver moving to dropoff
      const route = activeTrip.routeCoordinates;
      let currentIndex = activeTrip.tripStepIndex;

      driverMovementTimerRef.current = setInterval(() => {
        if (currentIndex < route.length - 1) {
          currentIndex++;
          const nextCoord = route[currentIndex];
          const prevCoord = route[currentIndex - 1];
          const newHeading = getHeading(prevCoord[0], prevCoord[1], nextCoord[0], nextCoord[1]);
          const remainingSteps = route.length - 1 - currentIndex;
          const updatedEta = Math.max(1, Math.ceil(remainingSteps / 4));

          setActiveTrip((prev) =>
            prev
              ? {
                  ...prev,
                  driverCoordinates: nextCoord,
                  driverHeading: newHeading,
                  tripStepIndex: currentIndex,
                  etaMinutes: updatedEta,
                }
              : null
          );
        } else {
          // Trip Completed!
          if (driverMovementTimerRef.current) clearInterval(driverMovementTimerRef.current);
          setTripStatus('completed');
          setActiveTrip((prev) =>
            prev
              ? {
                  ...prev,
                  status: 'completed',
                  driverCoordinates: [prev.dropoff.lat, prev.dropoff.lng],
                  etaMinutes: 0,
                }
              : null
          );
        }
      }, intervalTime);
    }

    return () => {
      if (driverMovementTimerRef.current) {
        clearInterval(driverMovementTimerRef.current);
      }
    };
  }, [activeTrip?.status, simulationSpeed]);

  // Handle speed up simulation toggle
  const handleSpeedUpSimulation = () => {
    sound.playTap();
    const nextSpeed = simulationSpeed === 1 ? 2 : simulationSpeed === 2 ? 5 : 1;
    setSimulationSpeed(nextSpeed);
  };

  // Cancel active trip
  const handleCancelTrip = () => {
    sound.playTap();
    if (confirm('Are you sure you want to cancel this HAMBA request?')) {
      if (driverMovementTimerRef.current) clearInterval(driverMovementTimerRef.current);
      setIsDriverOneMinuteAlertOpen(false);
      hasNotifiedOneMinuteAwayRef.current = false;
      setTripStatus('idle');
      setActiveTrip(null);
      setDropoff(null);
    }
  };

  // Send in-app chat message
  const handleSendMessage = (text: string) => {
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'rider',
      text,
      time: 'Just now',
    };
    setChatMessages((prev) => [...prev, newMessage]);

    // Simulated driver response after 1.5 seconds
    setTimeout(() => {
      sound.playMessagePop();
      const driverReplies = [
        'Understood! Be there in a second.',
        'Got it, standing by!',
        'Thank you, headlights are flashing.',
        'All good, see you shortly!',
      ];
      const randomReply = driverReplies[Math.floor(Math.random() * driverReplies.length)];
      setChatMessages((prev) => [
        ...prev,
        {
          id: `msg-drv-${Date.now()}`,
          sender: 'driver',
          text: randomReply,
          time: 'Just now',
        },
      ]);
    }, 1600);
  };

  // Complete and rate trip
  const handleFinishTrip = (tip: number, driverRating: number, passengerRatingReceived: number) => {
    if (!activeTrip) return;

    const isCash = activeTrip.paymentMethod.type === 'cash';
    const totalCharged = activeTrip.finalFare + (isCash ? 0 : tip);

    // Deduct from wallet if paid via wallet
    if (activeTrip.paymentMethod.type === 'wallet') {
      setWalletBalance((prev) => Math.max(0, prev - totalCharged));
      const newTx: WalletTransaction = {
        id: `tx_${Date.now()}`,
        type: 'ride_payment',
        title: `Trip to ${activeTrip.dropoff.name}`,
        date: 'Today, Just now',
        amount: totalCharged,
        isCredit: false,
        reference: activeTrip.id,
        status: 'successful',
      };
      setWalletTransactions((prev) => [newTx, ...prev]);
    }

    // Save to past rides activity
    const newPastRide: PastRideRecord = {
      id: activeTrip.id,
      date: 'Today, Just now',
      pickupName: activeTrip.pickup.name,
      dropoffName: activeTrip.dropoff.name,
      fare: totalCharged,
      categoryName: activeTrip.category.name,
      driverName: activeTrip.driver.name,
      driverRating: driverRating,
      status: 'completed',
      paymentMethodLabel: isCash ? 'Cash Payment' : activeTrip.paymentMethod.title,
    };
    setPastRides((prev) => [newPastRide, ...prev]);

    // Client Ride Rewards: Count completed rides towards 10 or finalize free ride
    if (isFreeRideAppliedToTripRef.current) {
      isFreeRideAppliedToTripRef.current = false;
    } else {
      setLoyalty((prev) => {
        const isExpired =
          prev.freeRideExpiresAt !== null && Date.now() > prev.freeRideExpiresAt;
        const available = isExpired ? 0 : prev.freeRidesAvailable;

        if (available > 0) {
          return prev;
        }

        const nextCount = prev.completedRidesCount + 1;
        if (nextCount >= 10) {
          const now = Date.now();
          sound.playFreeRideUnlocked();
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#10b981', '#f59e0b', '#3b82f6', '#ec4899'],
          });
          return {
            ...prev,
            completedRidesCount: 10,
            freeRidesAvailable: 1,
            freeRideUnlockedAt: now,
            freeRideExpiresAt: now + 7 * 24 * 60 * 60 * 1000,
          };
        }
        return {
          ...prev,
          completedRidesCount: nextCount,
        };
      });
    }

    // Reset back to idle map
    setIsDriverOneMinuteAlertOpen(false);
    hasNotifiedOneMinuteAwayRef.current = false;
    setTripStatus('idle');
    setActiveTrip(null);
    setDropoff(null);
    setSimulationSpeed(1);
    sound.playTap();
  };

  // Rebook a past ride
  const handleRebook = (past: PastRideRecord) => {
    setActiveTab('rides');
    const matchedDropoff = NATIONWIDE_LOCATIONS.find((l) => l.name === past.dropoffName) || {
      id: `rebook_${Date.now()}`,
      name: past.dropoffName,
      address: `${past.dropoffName}, South Africa`,
      lat: saCenter[0] - 0.025,
      lng: saCenter[1] + 0.015,
      type: 'popular',
    };
    setDropoff(matchedDropoff);
    setTripStatus('selecting_ride');
    sound.playTap();
  };

  // Top up wallet
  const handleTopUpWallet = (amount: number) => {
    setWalletBalance((prev) => prev + amount);
    const newTx: WalletTransaction = {
      id: `tx_topup_${Date.now()}`,
      type: 'top_up',
      title: 'Wallet Instant Top-Up',
      date: 'Today, Just now',
      amount,
      isCredit: true,
      reference: `TOP-${Math.floor(100000 + Math.random() * 900000)}`,
      status: 'successful',
    };
    setWalletTransactions((prev) => [newTx, ...prev]);
    sound.playPaymentSuccess();
  };

  // Add new payment method
  const handleAddPaymentMethod = (method: PaymentMethod) => {
    setPaymentMethods((prev) => [method, ...prev]);
    setSelectedPayment(method);
  };

  // Schedule a ride confirmation
  const handleScheduleConfirmed = (newScheduledRide: ScheduledRideRecord) => {
    setScheduledRides((prev) => [newScheduledRide, ...prev]);
    setIsScheduleModalOpen(false);
    setTripStatus('scheduled');
    setScheduleNotice(
      `Ride scheduled for ${newScheduledRide.scheduledDate} · ${newScheduledRide.scheduledTime}`
    );
    setTimeout(() => {
      setScheduleNotice(null);
      setTripStatus('idle');
    }, 4500);
  };

  // Start scheduled ride immediately
  const handleStartScheduledRide = (sch: ScheduledRideRecord) => {
    setActiveTab('rides');
    setPickup(sch.pickup);
    setDropoff(sch.dropoff);
    setSelectedCategory(sch.category);
    setScheduledRides((prev) => prev.filter((r) => r.id !== sch.id));
    handleConfirmRide(sch.estimatedFare, 0);
  };

  // Cancel scheduled ride
  const handleCancelScheduledRide = (rideId: string) => {
    setScheduledRides((prev) => prev.filter((r) => r.id !== rideId));
    sound.playTap();
  };

  return (
    <MobileFrame
      activeTab={activeTab}
      onChangeTab={setActiveTab}
      hasActiveTrip={tripStatus !== 'idle'}
      appMode={appMode}
      onToggleAppMode={(mode) => {
        setAppMode(mode);
        sound.playTap();
      }}
    >
      {appMode === 'driver' ? (
        <HambaDriverApp onSwitchToRider={() => setAppMode('rider')} />
      ) : (
        <>
          {/* Tab 1: Rides (Interactive Map & E-Hailing Workflow) */}
          {activeTab === 'rides' && (
            <div className="relative w-full h-full flex flex-col">
              {/* Live Map Background */}
              <LiveMap
                center={saCenter}
                zoom={saZoom}
                pickup={pickup}
                dropoff={dropoff}
                activeTrip={activeTrip}
                nearbyDrivers={nearbyDrivers}
                isNightMode={isNightMap}
                className="absolute inset-0 z-0"
              />

              {/* Floating Map Header Overlay */}
              <div className="absolute top-3 inset-x-3 z-20 flex items-center justify-between pointer-events-none">
                {/* Client Ride Rewards Badge (10 rides = 1 Free Ride) & Driver Mode Switcher */}
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  <ClientRideRewardsBadge
                    loyalty={loyalty}
                    onClick={() => {
                      sound.playTap();
                      setIsRewardsModalOpen(true);
                    }}
                  />

                  {/* Install APK / Download App Button */}
                  <PWAInstallButton />

                  <button
                    onClick={() => {
                      setAppMode('driver');
                      sound.playTap();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/90 hover:bg-emerald-900/90 border border-emerald-500/70 text-emerald-300 backdrop-blur-md shadow-lg transition-all active:scale-95 text-xs font-bold"
                    title="Switch to Hamba Driver Partner App"
                  >
                    <Car className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Driver App</span>
                  </button>
                </div>

            {/* Right Tools (SOS Driver Button, Float Over Apps, Night Mode, Safety) */}
            <div className="flex items-center gap-1.5 pointer-events-auto">
              {/* Prominent SOS Driver / Armed Response Emergency Button */}
              <button
                onClick={() => {
                  setIsSosModalOpen(true);
                  sound.playEmergencySiren();
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/60 border border-rose-400 font-black text-xs transition-all animate-pulse active:scale-95"
                title="SOS Armed Response & SAPS 10111 Dispatch"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>SOS</span>
              </button>

              {/* Float Over Other Apps Button */}
              <button
                onClick={() => {
                  setIsFloatingPipOpen(!isFloatingPipOpen);
                  sound.playTap();
                }}
                className={`p-2 rounded-full border backdrop-blur-md shadow-lg transition-colors ${
                  isFloatingPipOpen
                    ? 'bg-emerald-500 text-neutral-950 border-emerald-400'
                    : 'bg-neutral-900/90 border-neutral-750 text-neutral-300 hover:text-white hover:bg-neutral-850'
                }`}
                title="Float on Top of Other Open Apps"
              >
                <PictureInPicture className="w-4 h-4" />
              </button>

              {/* Day/Night Map Toggle */}
              <button
                onClick={() => setIsNightMap(!isNightMap)}
                className="p-2 rounded-full bg-neutral-900/90 border border-neutral-750 text-neutral-300 hover:text-white backdrop-blur-md shadow-lg transition-colors"
                title="Toggle Day/Night Map"
              >
                {isNightMap ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-400" />}
              </button>

              <button
                onClick={() => setIsSafetyOpen(true)}
                className="p-2 rounded-full bg-neutral-900/90 border border-neutral-750 text-emerald-400 hover:bg-neutral-850 backdrop-blur-md shadow-lg transition-colors"
                title="Safety Toolkit"
              >
                <Shield className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Floating Notice when a Ride is Scheduled */}
          {scheduleNotice && (
            <div className="absolute top-14 inset-x-3 z-30 p-3 rounded-2xl bg-neutral-900/95 border border-emerald-500/80 backdrop-blur-md shadow-2xl flex items-center justify-between animate-in slide-in-from-top-3 duration-200">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 flex-shrink-0">
                  <Calendar className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Trip Status: Scheduled</span>
                  </div>
                  <div className="text-xs font-semibold text-neutral-100 truncate">{scheduleNotice}</div>
                </div>
              </div>
              <button
                onClick={() => {
                  setActiveTab('activity');
                  setScheduleNotice(null);
                }}
                className="px-2.5 py-1 rounded-lg bg-emerald-500 text-neutral-950 text-xs font-bold hover:bg-emerald-400 ml-2 flex-shrink-0 transition-all active:scale-95"
              >
                View
              </button>
            </div>
          )}

          {/* Idle Home Screen Bottom Sheet */}
          {tripStatus === 'idle' && (
            <div className="absolute inset-x-0 bottom-0 z-20 p-3 pb-4">
              <div className="p-4 rounded-3xl bg-neutral-950/95 backdrop-blur-xl border border-neutral-800/90 shadow-2xl space-y-3.5">
                {/* Greeting & Pickup badge */}
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-extrabold text-neutral-100 tracking-tight">
                      Where are you heading?
                    </h3>
                    <div className="text-[11px] text-neutral-400 flex items-center gap-1.5 mt-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span className="truncate max-w-[200px]">{pickup.name}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full">
                      {nearbyDrivers.length} Cars Nearby
                    </span>
                  </div>
                </div>

                {/* Primary Search Bar & Schedule a Ride Action Row */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleStartBooking}
                    className="flex-1 py-3.5 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-750 flex items-center justify-between shadow-inner group transition-all text-left"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform flex-shrink-0">
                        <Search className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-xs font-semibold text-neutral-300 group-hover:text-neutral-100 truncate">
                        Where to? Search...
                      </span>
                    </div>
                    <div className="px-1.5 py-0.5 rounded bg-neutral-800 text-[9px] font-bold text-neutral-400">
                      NOW
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setIsScheduleModalOpen(true);
                      sound.playTap();
                    }}
                    className="py-3 px-3.5 rounded-2xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-750 hover:border-emerald-500/60 text-emerald-400 flex items-center gap-1.5 shadow-inner transition-all flex-shrink-0 active:scale-95"
                    title="Schedule a Ride for Later"
                  >
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-neutral-200">Schedule</span>
                  </button>
                </div>

                {/* Quick Shortcuts to Popular Spots */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {NATIONWIDE_LOCATIONS.slice(0, 2).map((loc) => (
                    <button
                      key={loc.id}
                      onClick={() => {
                        setDropoff(loc);
                        setTripStatus('selecting_ride');
                        sound.playTap();
                      }}
                      className="p-2.5 rounded-xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 flex items-center gap-2.5 transition-colors text-left"
                    >
                      <div className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400">
                        <MapPin className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-neutral-200 truncate">{loc.name}</div>
                        <div className="text-[10px] text-neutral-500">Quick Ride</div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Bottom Wallet & Security Strip */}
                <div className="pt-2 border-t border-neutral-850 flex items-center justify-between text-[11px] text-neutral-400">
                  <button
                    onClick={() => setIsPaymentDrawerOpen(true)}
                    className="flex items-center gap-1.5 hover:text-neutral-200 transition-colors"
                  >
                    <span>Paying via:</span>
                    <span className="font-semibold text-emerald-400">{selectedPayment.title}</span>
                  </button>

                  <div className="flex items-center gap-1 text-[10px] text-neutral-500">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>Average pickup 3 mins</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Ride Category Selector Sheet */}
          {tripStatus === 'selecting_ride' && dropoff && (
            <RideCategorySelector
              pickup={pickup}
              dropoff={dropoff}
              categories={RIDE_CATEGORIES}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              selectedPayment={selectedPayment}
              allPaymentMethods={paymentMethods}
              onSelectPayment={setSelectedPayment}
              onOpenPaymentPicker={() => setIsPaymentDrawerOpen(true)}
              onConfirmRide={handleConfirmRide}
              onBack={() => {
                setTripStatus('idle');
                setDropoff(null);
                sound.playTap();
              }}
              currencySymbol="R"
              loyalty={loyalty}
              onRedeemFreeRide={() => {
                isFreeRideAppliedToTripRef.current = true;
              }}
            />
          )}

          {/* Subtle Visual Alert: Driver is exactly 1 minute away from pickup */}
          {activeTrip && tripStatus === 'driver_arriving' && isDriverOneMinuteAlertOpen && (
            <DriverApproachingAlert
              trip={activeTrip}
              onDismiss={() => setIsDriverOneMinuteAlertOpen(false)}
            />
          )}

          {/* Active Trip Live Driver Tracking Card */}
          {activeTrip && (tripStatus === 'searching_driver' ||
            tripStatus === 'driver_accepted' ||
            tripStatus === 'driver_arriving' ||
            tripStatus === 'driver_arrived' ||
            tripStatus === 'in_progress') && (
            <ActiveTripCard
              trip={activeTrip}
              onOpenChat={() => setIsChatOpen(true)}
              onOpenSafety={() => setIsSafetyOpen(true)}
              onOpenSos={() => setIsSosModalOpen(true)}
              onCancelTrip={handleCancelTrip}
              onSpeedUpSimulation={handleSpeedUpSimulation}
              simulationSpeed={simulationSpeed}
              currencySymbol="R"
            />
          )}

          {/* Trip Completed & Secure Receipt Modal */}
          {activeTrip && tripStatus === 'completed' && (
            <TripReceiptModal
              trip={activeTrip}
              currencySymbol="R"
              onFinish={handleFinishTrip}
            />
          )}
        </div>
      )}

      {/* Tab 2: Activity / Rides History */}
      {activeTab === 'activity' && (
        <ActivityView
          rides={pastRides}
          scheduledRides={scheduledRides}
          onRebook={handleRebook}
          onStartScheduledRide={handleStartScheduledRide}
          onCancelScheduledRide={handleCancelScheduledRide}
          onOpenScheduleModal={() => setIsScheduleModalOpen(true)}
          currencySymbol="R"
        />
      )}

      {/* Tab 3: In-App Wallet & Top-Up */}
      {activeTab === 'wallet' && (
        <WalletView
          balance={walletBalance}
          transactions={walletTransactions}
          onTopUp={handleTopUpWallet}
          onOpenManageCards={() => setIsPaymentDrawerOpen(true)}
          currencySymbol="R"
        />
      )}

      {/* Modals & Drawers */}
      <WhereToModal
        isOpen={isWhereToOpen}
        onClose={() => setIsWhereToOpen(false)}
        pickup={pickup}
        dropoff={dropoff}
        onSelectPickup={setPickup}
        onSelectDropoff={setDropoff}
        popularLocations={NATIONWIDE_LOCATIONS}
        onConfirmDestination={handleConfirmDestination}
      />

      <ScheduleRideModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        pickup={pickup}
        dropoff={dropoff}
        onSelectDropoff={() => {
          setIsScheduleModalOpen(false);
          setIsWhereToOpen(true);
        }}
        categories={RIDE_CATEGORIES}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        selectedPayment={selectedPayment}
        onScheduleConfirmed={handleScheduleConfirmed}
        currencySymbol="R"
      />

      <PaymentDrawer
        isOpen={isPaymentDrawerOpen}
        onClose={() => setIsPaymentDrawerOpen(false)}
        paymentMethods={paymentMethods}
        selectedPayment={selectedPayment}
        onSelectPayment={setSelectedPayment}
        onAddPaymentMethod={handleAddPaymentMethod}
        walletBalance={walletBalance}
        onTopUpWallet={handleTopUpWallet}
        currencySymbol="R"
      />

      {activeTrip && (
        <TripChatModal
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          driver={activeTrip.driver}
          messages={chatMessages}
          onSendMessage={handleSendMessage}
        />
      )}

      <SafetyModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
        safetyPin={activeTrip?.safetyPin}
        driverName={activeTrip?.driver.name}
        licensePlate={activeTrip?.driver.licensePlate}
      />

      {/* SOS Driver & Armed Response Modal */}
      <SosDriverModal
        isOpen={isSosModalOpen}
        onClose={() => setIsSosModalOpen(false)}
        driver={activeTrip?.driver}
        currentLocation={pickup}
      />

      {/* Picture-in-Picture / Floating Widget (Operate on top of other open apps) */}
      <FloatingPipWidget
        isOpen={isFloatingPipOpen}
        onClose={() => setIsFloatingPipOpen(false)}
        onExpand={() => setIsFloatingPipOpen(false)}
        onOpenSos={() => setIsSosModalOpen(true)}
        activeTrip={activeTrip}
        currencySymbol="R"
      />

      {/* Client Ride Rewards (10 rides = 1 Free Ride) Modal */}
      <ClientRideRewardsModal
        isOpen={isRewardsModalOpen}
        onClose={() => setIsRewardsModalOpen(false)}
        loyalty={loyalty}
        onUpdateLoyalty={setLoyalty}
        onStartBooking={handleStartBooking}
      />

      {/* Offline connectivity indicator */}
      <OfflineIndicator />
        </>
      )}
    </MobileFrame>
  );
}
