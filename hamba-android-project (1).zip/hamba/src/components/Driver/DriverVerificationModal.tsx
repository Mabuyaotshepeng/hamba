import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  CheckCircle2,
  FileText,
  Mail,
  Phone,
  RefreshCw,
  RotateCcw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Upload,
  User,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { DriverVerificationData } from '../../types/driver';

interface DriverVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerificationComplete: (data: DriverVerificationData, autoGoOnline?: boolean) => void;
  initialData?: Partial<DriverVerificationData>;
}

type VerificationStep = 'phone' | 'selfie' | 'otp' | 'success';

const DEMO_SELFIES = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
];

export const DriverVerificationModal: React.FC<DriverVerificationModalProps> = ({
  isOpen,
  onClose,
  onVerificationComplete,
  initialData,
}) => {
  const [step, setStep] = useState<VerificationStep>('phone');

  // Form fields
  const [driverName, setDriverName] = useState(initialData?.driverName || 'Sipho Dlamini');
  const [phoneNumber, setPhoneNumber] = useState(initialData?.phoneNumber || '+27 82 555 1928');
  const [email, setEmail] = useState(initialData?.email || '');
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);

  // Selfie states
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(initialData?.selfieUrl || null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // OTP states
  const [generatedOtp, setGeneratedOtp] = useState<string>('4829');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '']);
  const [otpError, setOtpError] = useState<string | null>(null);
  const [resendCountdown, setResendCountdown] = useState<number>(30);
  const [simulatedSmsToast, setSimulatedSmsToast] = useState<boolean>(false);
  const otpInputsRef = useRef<(HTMLInputElement | null)[]>([]);

  // Cleanup camera stream
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  // When step changes to selfie, try activating camera
  useEffect(() => {
    if (step === 'selfie' && !capturedPhoto) {
      startCamera();
    } else {
      stopCameraStream();
    }
  }, [step, capturedPhoto]);

  // Resend OTP countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'otp' && resendCountdown > 0) {
      timer = setInterval(() => {
        setResendCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, resendCountdown]);

  if (!isOpen) return null;

  // Start live webcam feed
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Webcam API is not supported in this browser.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 640 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.warn('Camera access unavailable:', err);
      setCameraError('Camera access unavailable. You can upload an image or choose a sample selfie.');
      setIsCameraActive(false);
    }
  };

  // Capture snapshot from webcam
  const handleSnapPhoto = () => {
    sound.playCameraShutter();
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 480;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedPhoto(dataUrl);
        stopCameraStream();
      }
    } else {
      // Fallback
      setCapturedPhoto(DEMO_SELFIES[0]);
      stopCameraStream();
    }
  };

  // Upload photo from device file system
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        sound.playCameraShutter();
        setCapturedPhoto(reader.result as string);
        stopCameraStream();
      };
      reader.readAsDataURL(file);
    }
  };

  // Step 1 Validation & Proceed
  const handlePhoneStepSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError(null);
    setEmailError(null);

    // Validate phone
    const cleanedPhone = phoneNumber.replace(/[\s-]/g, '');
    if (!cleanedPhone || cleanedPhone.length < 9) {
      setPhoneError('Please enter a valid South African phone number (e.g. 082 123 4567).');
      return;
    }

    // Validate email if provided
    if (email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) {
        setEmailError('Please enter a valid email address, or leave it blank.');
        return;
      }
    }

    sound.playTap();
    setStep('selfie');
  };

  // Step 2 Proceed to OTP
  const handleSelfieStepSubmit = () => {
    if (!capturedPhoto) {
      setCameraError('Please take or select a selfie photo to continue.');
      return;
    }

    sound.playTap();
    // Generate fresh 4-digit code
    const newCode = String(Math.floor(1000 + Math.random() * 9000));
    setGeneratedOtp(newCode);
    setOtpDigits(['', '', '', '']);
    setOtpError(null);
    setResendCountdown(30);
    setStep('otp');

    // Trigger in-app SMS toast simulation
    setSimulatedSmsToast(true);
    sound.playDriverArrived();
    setTimeout(() => {
      if (otpInputsRef.current[0]) {
        otpInputsRef.current[0]?.focus();
      }
    }, 150);
  };

  // OTP Digits input handler
  const handleOtpChange = (index: number, val: string) => {
    if (!/^\d*$/.test(val)) return;

    const newDigits = [...otpDigits];
    newDigits[index] = val.slice(-1);
    setOtpDigits(newDigits);
    setOtpError(null);

    // Auto advance
    if (val && index < 3) {
      otpInputsRef.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
    if (pasted.length === 4) {
      const arr = pasted.split('');
      setOtpDigits(arr);
      otpInputsRef.current[3]?.focus();
    }
  };

  // Auto fill OTP for fast testing
  const handleAutoFillOtp = () => {
    sound.playTap();
    setOtpDigits(generatedOtp.split(''));
    setOtpError(null);
  };

  // Step 3 Verify OTP
  const handleVerifyOtp = () => {
    const enteredCode = otpDigits.join('');
    if (enteredCode.length < 4) {
      setOtpError('Please enter all 4 digits of the OTP code.');
      return;
    }

    if (enteredCode !== generatedOtp && enteredCode !== '4829') {
      sound.playCancelPenalty();
      setOtpError(`Incorrect OTP code. Please enter ${generatedOtp} sent to ${phoneNumber}.`);
      return;
    }

    // Success!
    sound.playPinVerified();
    sound.playCashOutSuccess();
    setStep('success');

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#34d399', '#6ee7b7', '#f59e0b'],
      });
    } catch {
      // Ignore
    }
  };

  // Final confirmation
  const handleFinish = (autoGoOnline = true) => {
    sound.playTap();
    const verifiedData: DriverVerificationData = {
      isVerified: true,
      phoneNumber,
      selfieUrl: capturedPhoto || DEMO_SELFIES[0],
      email: email.trim() || undefined,
      verifiedAt: new Date().toLocaleDateString('en-ZA', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      driverName,
    };
    onVerificationComplete(verifiedData, autoGoOnline);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-neutral-900 border border-neutral-750 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Hidden Canvas for Camera Snapshots */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Modal Top Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-neutral-100 tracking-tight">
                {step === 'phone' && 'Driver Sign-Up & Phone'}
                {step === 'selfie' && 'Driver Selfie Verification'}
                {step === 'otp' && 'SMS OTP Phone Verification'}
                {step === 'success' && 'Identity Verified & Ready!'}
              </h3>
              <p className="text-[11px] text-neutral-400">
                Required security protocol before going online
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              stopCameraStream();
              onClose();
            }}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Dots */}
        <div className="px-5 py-2.5 bg-neutral-950/40 border-b border-neutral-800/80 flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                step === 'phone'
                  ? 'bg-emerald-500 text-neutral-950 font-black'
                  : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              }`}
            >
              1
            </span>
            <span className={step === 'phone' ? 'text-neutral-100 font-bold' : 'text-neutral-400'}>
              Phone & Email
            </span>
          </div>

          <span className="text-neutral-700">──</span>

          <div className="flex items-center gap-1.5">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                step === 'selfie'
                  ? 'bg-emerald-500 text-neutral-950 font-black'
                  : step === 'otp' || step === 'success'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-neutral-800 text-neutral-500'
              }`}
            >
              2
            </span>
            <span className={step === 'selfie' ? 'text-neutral-100 font-bold' : 'text-neutral-400'}>
              Live Selfie
            </span>
          </div>

          <span className="text-neutral-700">──</span>

          <div className="flex items-center gap-1.5">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                step === 'otp'
                  ? 'bg-emerald-500 text-neutral-950 font-black'
                  : step === 'success'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-neutral-800 text-neutral-500'
              }`}
            >
              3
            </span>
            <span className={step === 'otp' || step === 'success' ? 'text-neutral-100 font-bold' : 'text-neutral-400'}>
              OTP Code
            </span>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          
          {/* ================= STEP 1: PHONE NUMBER & OPTIONAL EMAIL ================= */}
          {step === 'phone' && (
            <form onSubmit={handlePhoneStepSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 text-neutral-300 text-xs flex items-start gap-2.5">
                <Shield className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="text-emerald-300 font-bold">Driver Identity Protection:</strong>{' '}
                  Hamba requires all drivers to verify their mobile phone number and selfie identity
                  prior to accepting passenger dispatch requests.
                </div>
              </div>

              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Driver Full Name</span>
                </label>
                <input
                  type="text"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  placeholder="e.g. Sipho Dlamini"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 focus:border-emerald-500 focus:outline-none text-neutral-100 text-xs font-medium"
                  required
                />
              </div>

              {/* Phone Number (Required) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Mobile Phone Number</span>
                    <span className="text-rose-400 font-black">*</span>
                  </label>
                  <span className="text-[10px] text-neutral-400">South Africa (🇿🇦 +27)</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="px-3 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-300 text-xs font-mono font-bold flex items-center gap-1.5 flex-shrink-0">
                    <span>🇿🇦</span>
                    <span>+27</span>
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => {
                      setPhoneNumber(e.target.value);
                      setPhoneError(null);
                    }}
                    placeholder="082 555 1928"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 focus:border-emerald-500 focus:outline-none text-neutral-100 text-xs font-mono font-semibold"
                    required
                  />
                </div>

                {phoneError ? (
                  <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{phoneError}</span>
                  </p>
                ) : (
                  <p className="text-[10px] text-neutral-400">
                    A 4-digit verification code will be sent via SMS to this number.
                  </p>
                )}
              </div>

              {/* Optional Email Address */}
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Email Address</span>
                  </label>
                  <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider">
                    Optional
                  </span>
                </div>

                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setEmailError(null);
                  }}
                  placeholder="e.g. sipho.dlamini@gmail.com (Optional)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 focus:border-emerald-500 focus:outline-none text-neutral-100 text-xs font-medium"
                />

                {emailError ? (
                  <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{emailError}</span>
                  </p>
                ) : (
                  <p className="text-[10px] text-neutral-500">
                    Optional: used for weekly tax statements and payout receipts.
                  </p>
                )}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2"
                >
                  <span>Continue to Selfie Verification</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* ================= STEP 2: SELFIE PHOTO CAPTURE ================= */}
          {step === 'selfie' && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h4 className="text-sm font-extrabold text-neutral-100">
                  {capturedPhoto ? 'Review Your Driver Selfie' : 'Take a Real-Time Facial Selfie'}
                </h4>
                <p className="text-[11px] text-neutral-400">
                  Position your face in good lighting. Passengers will use this photo to verify you.
                </p>
              </div>

              {/* Camera Preview or Captured Image Container */}
              <div className="relative w-full aspect-square max-w-[280px] mx-auto rounded-3xl bg-neutral-950 border-2 border-dashed border-neutral-800 overflow-hidden shadow-inner flex items-center justify-center">
                {capturedPhoto ? (
                  <div className="relative w-full h-full">
                    <img
                      src={capturedPhoto}
                      alt="Captured Driver Selfie"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2.5 right-2.5 bg-emerald-500 text-neutral-950 p-1.5 rounded-full shadow-lg">
                      <Check className="w-4 h-4 stroke-[3]" />
                    </div>
                  </div>
                ) : isCameraActive ? (
                  <div className="relative w-full h-full bg-black">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover mirror"
                    />
                    {/* Oval Face Guide Overlay */}
                    <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                      <div className="w-44 h-56 rounded-[50%] border-2 border-emerald-400/80 shadow-[0_0_15px_rgba(16,185,129,0.3)] animate-pulse" />
                    </div>
                    <span className="absolute bottom-2 inset-x-0 text-center text-[10px] text-emerald-400 font-bold bg-neutral-950/70 py-1">
                      Align face within oval frame
                    </span>
                  </div>
                ) : (
                  <div className="p-4 text-center space-y-2">
                    <Camera className="w-10 h-10 text-neutral-600 mx-auto" />
                    <p className="text-xs text-neutral-400">Camera not active or access denied</p>
                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold"
                    >
                      Retry Camera
                    </button>
                  </div>
                )}
              </div>

              {/* Action Buttons for Selfie */}
              <div className="space-y-2.5">
                {!capturedPhoto ? (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={handleSnapPhoto}
                      className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Snap Photo (Take Selfie)</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {/* Upload from device file input */}
                      <label className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 font-semibold cursor-pointer text-center flex items-center justify-center gap-1.5 transition-colors">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload File</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>

                      {/* Use Sample Photo for Quick Testing */}
                      <button
                        type="button"
                        onClick={() => {
                          sound.playCameraShutter();
                          setCapturedPhoto(DEMO_SELFIES[0]);
                          stopCameraStream();
                        }}
                        className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 font-semibold text-center flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Use Demo Photo</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={handleSelfieStepSubmit}
                      className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2"
                    >
                      <span>Confirm Selfie & Send OTP Code</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        sound.playTap();
                        setCapturedPhoto(null);
                        startCamera();
                      }}
                      className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Retake Photo</span>
                    </button>
                  </div>
                )}

                {/* Back button */}
                <button
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    stopCameraStream();
                    setStep('phone');
                  }}
                  className="w-full text-center text-xs text-neutral-500 hover:text-neutral-300 py-1 transition-colors flex items-center justify-center gap-1"
                >
                  <ArrowLeft className="w-3 h-3" />
                  <span>Back to Phone & Email</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP 3: OTP CODE VERIFICATION ================= */}
          {step === 'otp' && (
            <div className="space-y-4">
              {/* Simulated SMS Push Banner for Seamless UX */}
              {simulatedSmsToast && (
                <div className="p-3 rounded-2xl bg-gradient-to-r from-neutral-800 to-neutral-850 border border-neutral-700 shadow-xl space-y-1 animate-in slide-in-from-top-2">
                  <div className="flex items-center justify-between text-[11px] text-neutral-400">
                    <span className="font-bold text-neutral-200 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Incoming SMS · Hamba Auth</span>
                    </span>
                    <span className="text-[10px] text-neutral-500">Just now</span>
                  </div>
                  <p className="text-xs text-neutral-100 font-medium">
                    Your Hamba Driver dispatch verification code is:{' '}
                    <strong className="text-emerald-400 font-mono text-sm tracking-widest">
                      {generatedOtp}
                    </strong>
                  </p>
                  <div className="pt-1 flex items-center justify-between">
                    <span className="text-[10px] text-neutral-400">Valid for 5 minutes</span>
                    <button
                      type="button"
                      onClick={handleAutoFillOtp}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold hover:bg-emerald-500/30 transition-colors"
                    >
                      Auto-Fill Code ({generatedOtp})
                    </button>
                  </div>
                </div>
              )}

              <div className="text-center space-y-1">
                <h4 className="text-sm font-extrabold text-neutral-100">
                  Enter 4-Digit Verification Code
                </h4>
                <p className="text-xs text-neutral-400">
                  Code sent to <span className="font-mono text-neutral-200 font-bold">{phoneNumber}</span>
                </p>
              </div>

              {/* 4-Digit Input Boxes */}
              <div className="flex items-center justify-center gap-3 pt-2">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => {
                      otpInputsRef.current[idx] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(idx, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                    onPaste={handleOtpPaste}
                    className="w-14 h-16 rounded-2xl bg-neutral-950 border-2 border-neutral-800 focus:border-emerald-500 focus:bg-neutral-900 focus:outline-none text-2xl font-black font-mono text-center text-emerald-400 shadow-lg transition-all"
                  />
                ))}
              </div>

              {otpError && (
                <p className="text-xs text-rose-400 font-medium text-center flex items-center justify-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{otpError}</span>
                </p>
              )}

              <div className="text-center pt-1">
                {resendCountdown > 0 ? (
                  <span className="text-xs text-neutral-500 font-mono">
                    Resend SMS code in {resendCountdown}s
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      const newCode = String(Math.floor(1000 + Math.random() * 9000));
                      setGeneratedOtp(newCode);
                      setResendCountdown(30);
                      setSimulatedSmsToast(true);
                      setOtpError(null);
                    }}
                    className="text-xs text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
                  >
                    Resend Verification Code
                  </button>
                )}
              </div>

              {/* Verify Button */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Verify & Activate Account</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    setStep('selfie');
                  }}
                  className="w-full text-center text-xs text-neutral-500 hover:text-neutral-300 py-1 transition-colors flex items-center justify-center gap-1"
                >
                  <ArrowLeft className="w-3 h-3" />
                  <span>Back to Selfie</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP 4: VERIFICATION SUCCESS ================= */}
          {step === 'success' && (
            <div className="text-center space-y-4 py-2">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mx-auto flex items-center justify-center shadow-lg shadow-emerald-950/60">
                <CheckCircle2 className="w-9 h-9 stroke-[2.5]" />
              </div>

              <div className="space-y-1">
                <h4 className="text-lg font-black text-neutral-100">
                  Verification Complete!
                </h4>
                <p className="text-xs text-neutral-400">
                  Your phone number and selfie identity have been verified. You are now authorized to go online.
                </p>
              </div>

              {/* Verified Profile Card */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-left space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={capturedPhoto || DEMO_SELFIES[0]}
                    alt="Verified Driver Selfie"
                    className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-500"
                  />
                  <div>
                    <h5 className="text-xs font-bold text-neutral-100">{driverName}</h5>
                    <p className="text-[11px] text-neutral-400 font-mono">{phoneNumber}</p>
                    <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-800/80">
                      ✓ Identity & SMS Verified
                    </span>
                  </div>
                </div>

                {email && (
                  <div className="text-[11px] text-neutral-400 border-t border-neutral-850 pt-2 flex items-center justify-between">
                    <span>Email Statement:</span>
                    <span className="text-neutral-200 font-mono">{email}</span>
                  </div>
                )}
              </div>

              {/* Primary Action Button: Go Online Immediately */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => handleFinish(true)}
                  className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-sm uppercase tracking-wider transition-all shadow-xl active:scale-98 flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4 fill-current" />
                  <span>Go Online Now (Start Driving)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleFinish(false)}
                  className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 font-semibold text-xs transition-colors"
                >
                  Stay Offline (Review Dashboard)
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
