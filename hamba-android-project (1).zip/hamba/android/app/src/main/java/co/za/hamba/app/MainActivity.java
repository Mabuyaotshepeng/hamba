package co.za.hamba.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
