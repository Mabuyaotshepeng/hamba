import React, { useState } from 'react';
import {
  Check,
  CheckCircle,
  FileCheck,
  Shield,
  Truck,
  Wrench,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';

interface VehicleInspectionModalProps {
  onComplete: () => void;
  onClose: () => void;
}

export const VehicleInspectionModal: React.FC<VehicleInspectionModalProps> = ({
  onComplete,
  onClose,
}) => {
  const [items, setItems] = useState([
    { id: 'tyres', label: 'Tyres & Tread Depth (>1.6mm legal limit)', checked: true },
    { id: 'brakes', label: 'Brakes & Handbrake Response', checked: true },
    { id: 'lights', label: 'Headlights, Indicators & Brake Lights', checked: true },
    { id: 'seatbelts', label: 'All 5 Passenger Seatbelts & Door Latches', checked: true },
    { id: 'aircon', label: 'Air Conditioner & Clean Cabin Interior', checked: true },
    { id: 'spare', label: 'Spare Tyre, Warning Triangle & Car Jack', checked: true },
  ]);

  const toggleItem = (id: string) => {
    sound.playTap();
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const allChecked = items.every((i) => i.checked);

  const handleSubmit = () => {
    sound.playPinVerified();
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-750 sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100 animate-in slide-in-from-bottom-5 duration-300">
        
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-neutral-100">
                Daily Vehicle Pre-Trip Inspection
              </h3>
              <p className="text-[11px] text-neutral-400">
                Ensure passenger road safety before going online
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Checklist */}
        <div className="p-5 space-y-2.5">
          {items.map((item) => (
            <div
              key={item.id}
              onClick={() => toggleItem(item.id)}
              className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800 hover:bg-neutral-850 cursor-pointer transition-colors flex items-center justify-between"
            >
              <span className="text-xs font-medium text-neutral-200">
                {item.label}
              </span>
              <div
                className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                  item.checked
                    ? 'bg-emerald-500 border-emerald-400 text-neutral-950'
                    : 'border-neutral-600 bg-neutral-800'
                }`}
              >
                {item.checked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>
          ))}
        </div>

        {/* Action */}
        <div className="p-5 pt-0">
          <button
            disabled={!allChecked}
            onClick={handleSubmit}
            className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 active:scale-98 text-neutral-950 font-black text-sm tracking-wide transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-5 h-5 fill-current" />
            <span>SIGN OFF INSPECTION & CERTIFY</span>
          </button>
        </div>

      </div>
    </div>
  );
};
