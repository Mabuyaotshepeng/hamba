import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Banknote,
  Check,
  CheckCircle,
  Coins,
  CreditCard,
  DollarSign,
  Heart,
  Navigation,
  Receipt,
  Sparkles,
  Star,
  ThumbsUp,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { DriverActiveTrip } from '../../types/driver';

interface DriverTripCompletedModalProps {
  trip: DriverActiveTrip;
  onFinish: (rating: number, compliments: string[]) => void;
}

export const DriverTripCompletedModal: React.FC<DriverTripCompletedModalProps> = ({
  trip,
  onFinish,
}) => {
  const { request } = trip;
  const [rating, setRating] = useState<number>(5);
  const [selectedCompliments, setSelectedCompliments] = useState<string[]>([]);
  const [cashCollected, setCashCollected] = useState<boolean>(false);

  useEffect(() => {
    // Sound & Confetti
    sound.playPaymentSuccess();
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#34d399', '#f59e0b', '#ffffff'],
      });
    } catch {
      // Ignore
    }
  }, []);

  const grossFare = request.estimatedNetEarnings / 0.88; // Gross before 12% commission
  const commission = grossFare * 0.12;
  const netPayout = request.estimatedNetEarnings;

  const complimentsList = [
    'Polite & Respectful',
    'Ready on Time',
    'Pleasant Conversation',
    'Clear Instructions',
    'Tipped in Cash',
  ];

  const toggleCompliment = (comp: string) => {
    sound.playTap();
    if (selectedCompliments.includes(comp)) {
      setSelectedCompliments(selectedCompliments.filter((c) => c !== comp));
    } else {
      setSelectedCompliments([...selectedCompliments, comp]);
    }
  };

  const handleFinish = () => {
    sound.playTap();
    onFinish(rating, selectedCompliments);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-750 sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100 animate-in slide-in-from-bottom-5 duration-300 max-h-[92vh] overflow-y-auto">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-neutral-900 to-emerald-950 px-5 py-4 border-b border-emerald-900/40 text-center">
          <div className="inline-flex p-2.5 rounded-full bg-emerald-500/20 text-emerald-400 mb-2 border border-emerald-500/30">
            <CheckCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-black text-neutral-100 tracking-tight">
            Trip Completed Successfully!
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            Passenger safely dropped off at {request.dropoff.name}
          </p>
        </div>

        {/* Earnings Card */}
        <div className="p-5 space-y-4">
          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-center space-y-1">
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
              Your Net Driver Payout
            </span>
            <div className="text-4xl font-black text-emerald-400 font-mono tracking-tight">
              R{netPayout.toFixed(2)}
            </div>
            <div className="text-xs text-neutral-400 flex items-center justify-center gap-2 pt-1">
              <span>Gross: R{grossFare.toFixed(2)}</span>
              <span>•</span>
              <span className="text-neutral-400">Commission (12%): -R{commission.toFixed(2)}</span>
            </div>
            {request.surgeBonus > 0 && (
              <div className="pt-2 flex items-center justify-center gap-1.5 text-xs font-bold text-amber-400">
                <Zap className="w-3.5 h-3.5 fill-amber-400" />
                <span>Includes +R{request.surgeBonus.toFixed(2)} High Demand Surge</span>
              </div>
            )}
          </div>

          {/* Payment Method Notice */}
          {request.paymentMethod === 'cash' ? (
            <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-800/60 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <Banknote className="w-4 h-4 text-amber-400" />
                <span>Cash Payment: Collect from Passenger</span>
              </div>
              <p className="text-[11px] text-amber-200/80">
                Please collect exactly <strong className="text-white">R{grossFare.toFixed(2)}</strong> from the rider. The platform commission will be deducted from your driver wallet.
              </p>
              <label className="flex items-center gap-2 pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={cashCollected}
                  onChange={(e) => setCashCollected(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-500 accent-emerald-500"
                />
                <span className="text-xs font-bold text-neutral-200">
                  I have collected the cash payment
                </span>
              </label>
            </div>
          ) : (
            <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-800/50 flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <CreditCard className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-emerald-300">
                  In-App Electronic Payment
                </div>
                <div className="text-[11px] text-neutral-400">
                  R{netPayout.toFixed(2)} has been credited to your Driver Wallet.
                </div>
              </div>
            </div>
          )}

          {/* Rate Passenger */}
          <div className="p-4 rounded-2xl bg-neutral-850/70 border border-neutral-750 text-center space-y-3">
            <span className="text-xs font-bold text-neutral-300">
              How was your trip with {request.passengerName}?
            </span>

            {/* Stars */}
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => {
                    setRating(star);
                    sound.playTap();
                  }}
                  className="p-1 text-2xl transition-transform hover:scale-110 active:scale-95"
                >
                  <Star
                    className={`w-7 h-7 ${
                      star <= rating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-neutral-600'
                    }`}
                  />
                </button>
              ))}
            </div>

            {/* Compliment Chips */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
              {complimentsList.map((comp) => {
                const active = selectedCompliments.includes(comp);
                return (
                  <button
                    key={comp}
                    onClick={() => toggleCompliment(comp)}
                    className={`text-[11px] font-medium px-2.5 py-1 rounded-full border transition-colors ${
                      active
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                        : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {comp}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Finish Button */}
        <div className="p-5 pt-2 bg-neutral-900 border-t border-neutral-800">
          <button
            onClick={handleFinish}
            className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-black text-sm tracking-wide transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2"
          >
            <Navigation className="w-5 h-5 fill-current" />
            <span>BACK TO ONLINE RADAR</span>
          </button>
        </div>

      </div>
    </div>
  );
};
