export interface LocationPoint {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  type?: 'recent' | 'saved' | 'airport' | 'station' | 'popular' | 'custom';
}

export type VehicleTier = 'go' | 'comfort' | 'xl' | 'boda' | 'black';

export interface RideCategory {
  id: string;
  name: string;
  tier: VehicleTier;
  subtitle: string;
  description: string;
  baseFare: number;
  perKmRate: number;
  perMinuteRate: number;
  etaMinutes: number;
  capacity: number;
  popularCarModels: string;
  surgeMultiplier: number;
}

export interface Driver {
  id: string;
  name: string;
  photo: string;
  rating: number;
  totalTrips: number;
  carModel: string;
  carColor: string;
  licensePlate: string;
  phoneNumber: string;
  currentLat: number;
  currentLng: number;
  heading: number;
  badges: string[];
}

export type PaymentType = 'card' | 'wallet' | 'apple_pay' | 'google_pay' | 'cash';

export interface PaymentMethod {
  id: string;
  type: PaymentType;
  title: string;
  subtitle: string;
  last4?: string;
  expiry?: string;
  brand?: 'visa' | 'mastercard' | 'amex';
  isDefault: boolean;
  tokenizedId?: string;
}

export type TripStatus =
  | 'idle'
  | 'selecting_destination'
  | 'selecting_ride'
  | 'searching_driver'
  | 'driver_accepted'
  | 'driver_arriving'
  | 'driver_arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'scheduled';

export interface ScheduledRideRecord {
  id: string;
  scheduledDate: string;
  scheduledTime: string;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  category: RideCategory;
  estimatedFare: number;
  paymentMethod: PaymentMethod;
  status: 'scheduled' | 'dispatched' | 'cancelled';
  createdAt: number;
}

export interface ActiveTrip {
  id: string;
  category: RideCategory;
  pickup: LocationPoint;
  dropoff: LocationPoint;
  driver: Driver;
  status: TripStatus;
  safetyPin: string;
  etaMinutes: number;
  distanceKm: number;
  estimatedFare: number;
  finalFare: number;
  paymentMethod: PaymentMethod;
  requestTime: number;
  routeCoordinates: [number, number][];
  driverCoordinates: [number, number];
  driverHeading: number;
  driverStepIndex: number;
  tripStepIndex: number;
  tipAmount: number;
  discountAmount: number;
}

export interface ChatMessage {
  id: string;
  sender: 'rider' | 'driver' | 'system';
  text: string;
  time: string;
}

export interface PastRideRecord {
  id: string;
  date: string;
  pickupName: string;
  dropoffName: string;
  fare: number;
  categoryName: string;
  driverName: string;
  driverRating: number;
  status: 'completed' | 'cancelled';
  paymentMethodLabel: string;
}

export interface WalletTransaction {
  id: string;
  type: 'ride_payment' | 'top_up' | 'refund' | 'tip';
  title: string;
  date: string;
  amount: number;
  isCredit: boolean;
  reference: string;
  status: 'successful' | 'pending';
}

export interface ClientLoyaltyData {
  completedRidesCount: number; // Counter counting up to 10
  freeRidesAvailable: number; // 1 free ride unlocked when count reaches 10
  freeRideUnlockedAt: number | null; // Timestamp when unlocked
  freeRideExpiresAt: number | null; // Expiration timestamp (7 days after unlock)
  maxDiscount: number; // Maximum discount amount: R50
  totalFreeRidesRedeemed: number;
}
