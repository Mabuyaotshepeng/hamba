import React from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  CreditCard,
  Lock,
  Plus,
  ShieldCheck,
  Wallet,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { WalletTransaction } from '../../types';
import { formatCurrency } from '../../utils/geo';

interface WalletViewProps {
  balance: number;
  transactions: WalletTransaction[];
  onTopUp: (amount: number) => void;
  onOpenManageCards: () => void;
  currencySymbol: string;
}

export const WalletView: React.FC<WalletViewProps> = ({
  balance,
  transactions,
  onTopUp,
  onOpenManageCards,
  currencySymbol,
}) => {
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
      <div className="pt-2">
        <h2 className="text-xl font-extrabold text-neutral-100">Hamba Wallet</h2>
        <p className="text-xs text-neutral-400 mt-0.5">Secure, 1-tap in-app balance & transactions</p>
      </div>

      {/* Main Wallet Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-900/40 via-neutral-900 to-neutral-900 border border-emerald-500/30 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Available Balance
            </span>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-neutral-400 bg-neutral-900/80 px-2 py-0.5 rounded-full border border-neutral-800">
            <Lock className="w-3 h-3 text-emerald-400" />
            <span>Encrypted Vault</span>
          </div>
        </div>

        <div>
          <div className="text-3xl font-black text-neutral-100 tracking-tight">
            {formatCurrency(balance, currencySymbol)}
          </div>
          <p className="text-[11px] text-neutral-400 mt-1">
            Zero fees on rides. Instant automatic debits upon destination arrival.
          </p>
        </div>

        {/* Quick Top-Up Bar */}
        <div className="pt-3 border-t border-neutral-800/80 space-y-2">
          <div className="text-[11px] font-semibold text-neutral-300">Quick Top-Up Options:</div>
          <div className="grid grid-cols-3 gap-2">
            {[100, 250, 500].map((amt) => (
              <button
                key={amt}
                onClick={() => {
                  onTopUp(amt);
                  sound.playTap();
                }}
                className="py-2 px-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-xs font-bold text-emerald-300 transition-all flex items-center justify-center gap-1 active:scale-95"
              >
                <Plus className="w-3 h-3" />
                <span>+{currencySymbol}{amt}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <button
        onClick={onOpenManageCards}
        className="w-full p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 flex items-center justify-between transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-neutral-800 text-neutral-300">
            <CreditCard className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-left">
            <div className="text-xs font-bold text-neutral-200">Payment Methods & Cards</div>
            <div className="text-[10px] text-neutral-400">Tokenized Visa, Mastercard, Apple Pay</div>
          </div>
        </div>
        <span className="text-xs font-semibold text-emerald-400">Manage</span>
      </button>

      {/* Transactions Ledger */}
      <div className="space-y-2 pt-1">
        <div className="text-xs font-bold uppercase tracking-wider text-neutral-500 px-1">
          Recent In-App Transactions
        </div>

        <div className="space-y-2">
          {transactions.map((tx) => (
            <div
              key={tx.id}
              className="p-3 rounded-xl bg-neutral-900 border border-neutral-850 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    tx.isCredit ? 'bg-emerald-500/10 text-emerald-400' : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {tx.isCredit ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-semibold text-neutral-200">{tx.title}</div>
                  <div className="text-[10px] text-neutral-500 font-mono">
                    {tx.date} · {tx.reference}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div
                  className={`text-xs font-bold ${
                    tx.isCredit ? 'text-emerald-400' : 'text-neutral-200'
                  }`}
                >
                  {tx.isCredit ? '+' : '-'}
                  {formatCurrency(tx.amount, currencySymbol)}
                </div>
                <div className="text-[9px] text-emerald-500 capitalize">{tx.status}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security notice */}
      <div className="p-3 rounded-2xl bg-neutral-900/40 border border-neutral-850 flex items-center gap-2.5 text-xs text-neutral-400">
        <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
        <span className="text-[11px]">
          Wallet funds protected by South African Banking Regulation & PCI-DSS token storage.
        </span>
      </div>
    </div>
  );
};
