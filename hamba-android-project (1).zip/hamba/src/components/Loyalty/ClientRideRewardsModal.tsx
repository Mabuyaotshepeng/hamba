import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  Calendar,
  Car,
  CheckCircle2,
  ChevronRight,
  Clock,
  Gift,
  HelpCircle,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Tag,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { ClientLoyaltyData } from '../../types';

interface ClientRideRewardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  loyalty: ClientLoyaltyData;
  onUpdateLoyalty: (updated: ClientLoyaltyData) => void;
  onStartBooking?: () => void;
}

export const ClientRideRewardsModal: React.FC<ClientRideRewardsModalProps> = ({
  isOpen,
  onClose,
  loyalty,
  onUpdateLoyalty,
  onStartBooking,
}) => {
  if (!isOpen) return null;

  const isExpired =
    loyalty.freeRideExpiresAt !== null && Date.now() > loyalty.freeRideExpiresAt;
  const isFreeRideUnlocked = loyalty.freeRidesAvailable > 0 && !isExpired;

  // Calculate remaining days & hours
  let daysRemaining = 7;
  let hoursRemaining = 0;
  let minutesRemaining = 0;
  let formattedExpiryDate = '';

  if (loyalty.freeRideExpiresAt) {
    const msLeft = Math.max(0, loyalty.freeRideExpiresAt - Date.now());
    daysRemaining = Math.floor(msLeft / (1000 * 60 * 60 * 24));
    hoursRemaining = Math.floor((msLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    minutesRemaining = Math.floor((msLeft % (1000 * 60 * 60)) / (1000 * 60));
    formattedExpiryDate = new Date(loyalty.freeRideExpiresAt).toLocaleDateString('en-ZA', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }

  // Simulation handler: +1 completed ride
  const handleSimulateAddRide = () => {
    sound.playTap();
    const newCount = loyalty.completedRidesCount + 1;
    if (newCount >= 10) {
      // Unlocked 10 rides!
      const now = Date.now();
      const updated: ClientLoyaltyData = {
        ...loyalty,
        completedRidesCount: 10,
        freeRidesAvailable: 1,
        freeRideUnlockedAt: now,
        freeRideExpiresAt: now + 7 * 24 * 60 * 60 * 1000,
      };
      onUpdateLoyalty(updated);
      sound.playFreeRideUnlocked();
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#f59e0b', '#3b82f6', '#ec4899'],
      });
    } else {
      onUpdateLoyalty({
        ...loyalty,
        completedRidesCount: newCount,
      });
    }
  };

  // Simulation handler: Set instantly to 10 completed rides
  const handleSimulateUnlock10Rides = () => {
    sound.playFreeRideUnlocked();
    const now = Date.now();
    const updated: ClientLoyaltyData = {
      ...loyalty,
      completedRidesCount: 10,
      freeRidesAvailable: 1,
      freeRideUnlockedAt: now,
      freeRideExpiresAt: now + 7 * 24 * 60 * 60 * 1000,
    };
    onUpdateLoyalty(updated);
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 },
      colors: ['#10b981', '#f59e0b', '#6366f1', '#e11d48'],
    });
  };

  // Simulation handler: Reset streak
  const handleResetStreak = () => {
    sound.playTap();
    onUpdateLoyalty({
      completedRidesCount: 0,
      freeRidesAvailable: 0,
      freeRideUnlockedAt: null,
      freeRideExpiresAt: null,
      maxDiscount: 50,
      totalFreeRidesRedeemed: loyalty.totalFreeRidesRedeemed,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-750 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500/20 to-emerald-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-neutral-100 flex items-center gap-1.5">
                <span>Client Rewards</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/80 font-bold">
                  Hamba Club
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400">
                10 Completed Rides = 1 Free Ride (Max R50)
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Main Status Showcase */}
          {isFreeRideUnlocked ? (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 via-neutral-850 to-emerald-950/40 border border-amber-400/50 relative overflow-hidden shadow-lg">
              <div className="flex items-start justify-between">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-black mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>STATUS: 1 FREE RIDE UNLOCKED</span>
                  </div>
                  <h3 className="text-xl font-black text-white tracking-tight">
                    Your Next Ride is Free!
                  </h3>
                  <p className="text-xs text-neutral-300 mt-1">
                    Value up to <span className="font-extrabold text-amber-300">R50.00</span>.
                    Fares of R50 or less are 100% free; rides above R50 get R50 deducted!
                  </p>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 flex-shrink-0 animate-bounce">
                  <Gift className="w-6 h-6" />
                </div>
              </div>

              {/* 7-Day Expiry Countdown Box */}
              <div className="mt-3.5 pt-3 border-t border-neutral-750 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-neutral-400">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Time to use:</span>
                </div>
                <div className="font-mono font-bold text-amber-300 flex items-center gap-1 bg-neutral-900/80 px-2 py-1 rounded-lg border border-amber-500/30">
                  <span>{daysRemaining}d</span>
                  <span>{hoursRemaining}h</span>
                  <span>{minutesRemaining}m remaining</span>
                </div>
              </div>

              <div className="mt-2 text-[10px] text-neutral-400 text-right">
                Valid for 7 days from unlock · Expires on {formattedExpiryDate}
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-neutral-850 border border-neutral-750 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                    Progress to Free Ride
                  </span>
                  <div className="text-xl font-black text-white flex items-baseline gap-1 mt-0.5">
                    <span>{loyalty.completedRidesCount}</span>
                    <span className="text-neutral-500 text-sm font-semibold">/ 10 Rides</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-block text-[11px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/70 px-2 py-1 rounded-full">
                    {Math.max(0, 10 - loyalty.completedRidesCount)} more to unlock
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-neutral-800 rounded-full h-2.5 overflow-hidden p-0.5 border border-neutral-700">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-amber-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (loyalty.completedRidesCount / 10) * 100)}%` }}
                />
              </div>

              {/* 10-Step Visual Nodes */}
              <div className="grid grid-cols-5 gap-2 pt-1">
                {Array.from({ length: 10 }, (_, i) => {
                  const stepNumber = i + 1;
                  const isCompleted = stepNumber <= loyalty.completedRidesCount;
                  const isTenth = stepNumber === 10;

                  return (
                    <div
                      key={stepNumber}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition-all ${
                        isTenth
                          ? isCompleted
                            ? 'bg-amber-950/50 border-amber-400 text-amber-300'
                            : 'bg-neutral-800/80 border-dashed border-amber-500/50 text-amber-400'
                          : isCompleted
                          ? 'bg-emerald-950/40 border-emerald-600/70 text-emerald-400'
                          : 'bg-neutral-900 border-neutral-750 text-neutral-500'
                      }`}
                    >
                      {isTenth ? (
                        <Gift className="w-3.5 h-3.5 mb-1 text-amber-400" />
                      ) : isCompleted ? (
                        <CheckCircle2 className="w-3.5 h-3.5 mb-1 text-emerald-400" />
                      ) : (
                        <Car className="w-3.5 h-3.5 mb-1 text-neutral-500" />
                      )}
                      <span className="text-[10px] font-black leading-none">
                        {isTenth ? 'FREE' : `#${stepNumber}`}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Program Rules Card */}
          <div className="p-4 rounded-2xl bg-neutral-850/60 border border-neutral-800 space-y-2.5">
            <h4 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>How Free Rides Work</span>
            </h4>

            <ul className="space-y-2 text-xs text-neutral-300">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                <span>
                  <strong className="text-white">Count to 10 Rides:</strong> Complete 10 rides in the client app.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                <span>
                  <strong className="text-white">Status Changes to 1 Free Ride:</strong> Upon reaching 10 completed rides, you instantly unlock 1 Free Ride.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                <span>
                  <strong className="text-white">Maximum Amount R50:</strong> The free ride covers up to R50. Rides of R50 or less are 100% free (R0); rides above R50 get R50 deducted from total fare.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                <span>
                  <strong className="text-white">7-Day Maximum Validity:</strong> You have up to 7 days from unlocking to redeem your free ride before it expires.
                </span>
              </li>
            </ul>
          </div>

          {/* Test & Simulation Controls */}
          <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-750/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Tester Controls (Simulate Activity)</span>
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleSimulateAddRide}
                className="py-2 px-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-200 text-xs font-semibold flex flex-col items-center justify-center gap-0.5 active:scale-95 transition-all"
              >
                <span className="text-[10px] text-emerald-400 font-bold">+1 Ride</span>
                <span>Count up</span>
              </button>

              <button
                onClick={handleSimulateUnlock10Rides}
                className="py-2 px-2 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-600/70 text-amber-200 text-xs font-bold flex flex-col items-center justify-center gap-0.5 active:scale-95 transition-all"
              >
                <span className="text-[10px] text-amber-400 font-extrabold">Set to 10</span>
                <span>Unlock Free Ride</span>
              </button>

              <button
                onClick={handleResetStreak}
                className="py-2 px-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-400 hover:text-neutral-200 text-xs font-semibold flex flex-col items-center justify-center gap-0.5 active:scale-95 transition-all"
              >
                <RotateCcw className="w-3 h-3 text-neutral-400" />
                <span className="text-[10px]">Reset (0/10)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer CTA */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-900/95 flex items-center gap-3">
          {onStartBooking && (
            <button
              onClick={() => {
                sound.playTap();
                onClose();
                onStartBooking();
              }}
              className="flex-1 py-3 px-4 rounded-xl font-bold text-sm bg-emerald-500 hover:bg-emerald-400 text-neutral-950 transition-all active:scale-98 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <Car className="w-4 h-4" />
              <span>{isFreeRideUnlocked ? 'Book Ride with Voucher' : 'Book a Ride'}</span>
            </button>
          )}

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="py-3 px-4 rounded-xl font-semibold text-sm bg-neutral-800 hover:bg-neutral-750 text-neutral-300 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
