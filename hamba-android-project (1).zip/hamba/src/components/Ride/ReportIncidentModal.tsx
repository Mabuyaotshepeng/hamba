import React, { useState } from 'react';
import {
  AlertTriangle,
  Car,
  CheckCircle,
  Clock,
  EyeOff,
  FileText,
  Lock,
  Radio,
  Send,
  Shield,
  ShieldAlert,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import { ActiveTrip } from '../../types';
import { sound } from '../../services/audio';

export type IncidentCategory =
  | 'unsafe_driving'
  | 'vehicle_condition'
  | 'route_deviation'
  | 'verbal_harassment'
  | 'suspected_intoxication'
  | 'other';

interface IncidentOption {
  id: IncidentCategory;
  label: string;
  description: string;
  icon: React.ReactNode;
  severity: 'high' | 'medium';
}

const INCIDENT_CATEGORIES: IncidentOption[] = [
  {
    id: 'unsafe_driving',
    label: 'Unsafe Driving',
    description: 'Speeding, aggressive braking, phone usage, or ignoring traffic signals',
    icon: <AlertTriangle className="w-5 h-5 text-amber-400" />,
    severity: 'high',
  },
  {
    id: 'vehicle_condition',
    label: 'Vehicle Condition',
    description: 'Broken seatbelts, strong odor, mechanical fault, or lack of roadworthiness',
    icon: <Car className="w-5 h-5 text-sky-400" />,
    severity: 'medium',
  },
  {
    id: 'route_deviation',
    label: 'Route Deviation / Unexpected Stop',
    description: 'Driver took an unauthorized detour without passenger consent',
    icon: <Radio className="w-5 h-5 text-purple-400" />,
    severity: 'high',
  },
  {
    id: 'suspected_intoxication',
    label: 'Suspected Intoxication / Fatigue',
    description: 'Signs of driving under influence or falling asleep at the wheel',
    icon: <ShieldAlert className="w-5 h-5 text-rose-400" />,
    severity: 'high',
  },
  {
    id: 'verbal_harassment',
    label: 'Inappropriate Conversation / Conduct',
    description: 'Unprofessional, discriminatory remarks, or personal questioning',
    icon: <EyeOff className="w-5 h-5 text-amber-300" />,
    severity: 'medium',
  },
  {
    id: 'other',
    label: 'Other Safety Concern',
    description: 'Any other discreet issue requiring HAMBA Safety Team intervention',
    icon: <FileText className="w-5 h-5 text-neutral-300" />,
    severity: 'medium',
  },
];

interface ReportIncidentModalProps {
  isOpen: boolean;
  trip: ActiveTrip;
  onClose: () => void;
  onOpenSos?: () => void;
}

export const ReportIncidentModal: React.FC<ReportIncidentModalProps> = ({
  isOpen,
  trip,
  onClose,
  onOpenSos,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<IncidentCategory>('unsafe_driving');
  const [details, setDetails] = useState('');
  const [discreetMode, setDiscreetMode] = useState(true);
  const [requestSilentSupport, setRequestSilentSupport] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [reportId, setReportId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playTap();

    const generatedId = `INC-${Math.floor(100000 + Math.random() * 900000)}`;
    setReportId(generatedId);
    setSubmitted(true);
  };

  const handleResetAndClose = () => {
    sound.playTap();
    setSubmitted(false);
    setDetails('');
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="incident-modal-title"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
    >
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl w-full max-w-md max-h-[92vh] flex flex-col overflow-hidden shadow-2xl relative text-neutral-100">
        {/* Discreet Top Banner */}
        <div className="bg-amber-950/60 border-b border-amber-800/40 px-4 py-2 flex items-center justify-between text-xs text-amber-300">
          <div className="flex items-center gap-1.5 font-medium">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>Discreet & 100% Confidential · Not shared with driver</span>
          </div>
          <button
            onClick={handleResetAndClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Header */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-850 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 id="incident-modal-title" className="text-sm font-black text-white flex items-center gap-1.5">
                <span>Report Live Incident</span>
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/60 px-1.5 py-0.2 rounded-full font-mono">
                  TRIP IN PROGRESS
                </span>
              </h2>
              <div className="text-[11px] text-neutral-400">
                Driver: <span className="text-neutral-200 font-medium">{trip.driver.name}</span> ({trip.driver.carModel} · {trip.driver.licensePlate})
              </div>
            </div>
          </div>
        </div>

        {/* Main Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {submitted ? (
            <div className="py-6 px-3 text-center space-y-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-500/15 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.25)]">
                <CheckCircle className="w-8 h-8" />
              </div>

              <div>
                <div className="text-base font-black text-white">Incident Logged Securely</div>
                <div className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
                  Our 24/7 South African Safety Operations Center is reviewing telematics and GPS logs for this ride.
                </div>
              </div>

              <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-3.5 text-left text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Incident Reference:</span>
                  <span className="font-mono font-bold text-amber-400">{reportId}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Issue Category:</span>
                  <span className="text-neutral-200 font-medium">
                    {INCIDENT_CATEGORIES.find((c) => c.id === selectedCategory)?.label}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Driver Notification:</span>
                  <span className="text-emerald-400 font-medium">None (Silent Review)</span>
                </div>
                {requestSilentSupport && (
                  <div className="flex items-center justify-between text-rose-300">
                    <span>Silent Agent Follow-Up:</span>
                    <span className="font-bold">Active in Chat</span>
                  </div>
                )}
              </div>

              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-400 text-[11px] leading-relaxed">
                If you feel in immediate danger at any point, press the red <strong>SOS Armed Response</strong> button on the active trip card to dispatch emergency responders to your real-time GPS coordinates.
              </div>

              <div className="pt-2 flex flex-col gap-2">
                {onOpenSos && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenSos();
                    }}
                    className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/40"
                  >
                    <ShieldAlert className="w-4 h-4" />
                    <span>Open SOS Armed Response</span>
                  </button>
                )}
                <button
                  onClick={handleResetAndClose}
                  className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-white font-bold text-xs transition-colors"
                >
                  Return to Live Trip
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Category Picker */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                  Select Issue Type
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {INCIDENT_CATEGORIES.map((category) => {
                    const isSelected = selectedCategory === category.id;
                    return (
                      <button
                        type="button"
                        key={category.id}
                        onClick={() => {
                          setSelectedCategory(category.id);
                          sound.playTap();
                        }}
                        className={`p-3 rounded-2xl border text-left transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-amber-500/10 border-amber-500/70 shadow-[0_0_15px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/40'
                            : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-850'
                        }`}
                      >
                        <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 flex-shrink-0 mt-0.5">
                          {category.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-neutral-100">{category.label}</span>
                            {isSelected && (
                              <span className="w-2 h-2 rounded-full bg-amber-400" />
                            )}
                          </div>
                          <p className="text-[11px] text-neutral-400 mt-0.5 leading-snug">
                            {category.description}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Additional Context Field */}
              <div className="space-y-1.5">
                <label htmlFor="incident-details" className="text-xs font-bold text-neutral-300 block">
                  Additional Details (Optional)
                </label>
                <textarea
                  id="incident-details"
                  rows={3}
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="e.g. Driver was looking at video on phone while taking sharp turn, or passenger seatbelt is jammed..."
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl p-3 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition-colors resize-none"
                />
              </div>

              {/* Discreet Protection Options */}
              <div className="space-y-2 pt-1 border-t border-neutral-800/80">
                <label
                  onClick={() => setDiscreetMode(!discreetMode)}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer hover:bg-neutral-850 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <EyeOff className="w-4 h-4 text-neutral-400" />
                    <div>
                      <div className="text-xs font-bold text-neutral-200">Silent / Discreet Filing</div>
                      <div className="text-[10px] text-neutral-400">Driver receives zero audio or app alerts</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={discreetMode}
                    onChange={(e) => setDiscreetMode(e.target.checked)}
                    className="w-4 h-4 accent-amber-500 rounded"
                  />
                </label>

                <label
                  onClick={() => setRequestSilentSupport(!requestSilentSupport)}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer hover:bg-neutral-850 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Radio className="w-4 h-4 text-emerald-400" />
                    <div>
                      <div className="text-xs font-bold text-neutral-200">Request Silent Operator Check-in</div>
                      <div className="text-[10px] text-neutral-400">HAMBA Safety Team will monitor live telemetry</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={requestSilentSupport}
                    onChange={(e) => setRequestSilentSupport(e.target.checked)}
                    className="w-4 h-4 accent-emerald-500 rounded"
                  />
                </label>
              </div>

              {/* Submit / Cancel Actions */}
              <div className="pt-2 flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="w-1/3 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 font-bold text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-amber-950/40 active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Discreet Report</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
