import React, { useEffect, useState } from 'react';
import {
  Battery,
  Bell,
  Car,
  Maximize2,
  Minimize2,
  Smartphone,
  User,
  Volume2,
  VolumeX,
  Wifi,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { requestNotificationPermission } from '../../utils/notifications';

interface MobileFrameProps {
  children: React.ReactNode;
  activeTab: 'rides' | 'activity' | 'wallet';
  onChangeTab: (tab: 'rides' | 'activity' | 'wallet') => void;
  hasActiveTrip: boolean;
  appMode?: 'rider' | 'driver';
  onToggleAppMode?: (mode: 'rider' | 'driver') => void;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  children,
  activeTab,
  onChangeTab,
  hasActiveTrip,
  appMode = 'driver',
  onToggleAppMode,
}) => {
  const [isPhoneMockup, setIsPhoneMockup] = useState(true);
  const [currentTime, setCurrentTime] = useState('09:41');
  const [soundOn, setSoundOn] = useState(true);
  const [notifPermission, setNotifPermission] = useState<string>('default');

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotifPermission(Notification.permission);
    }
  }, []);

  const handleToggleNotifications = async () => {
    sound.playTap();
    const res = await requestNotificationPermission();
    setNotifPermission(res);
  };

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    sound.setSoundEnabled(next);
  };

  return (
    <div className="min-h-screen w-full bg-neutral-950 flex flex-col items-center justify-center relative p-0 sm:p-4 select-none">
      {/* Top Floating Controls for Desktop Viewers */}
      <header className="hidden sm:flex items-center justify-between w-full max-w-5xl mb-3 px-4 py-2 rounded-2xl bg-neutral-900/80 border border-neutral-800 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-500 flex items-center justify-center font-black text-neutral-950 text-base tracking-tighter">
            H
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-neutral-100 tracking-wide">HAMBA</span>
              <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full">
                E-Hailing Platform
              </span>
            </div>
            <div className="text-[11px] text-neutral-400">
              Real-time driver tracking · 3D-Secure in-app payments · Joburg & Cape Town
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Mode Switcher: Passenger vs Driver */}
          {onToggleAppMode && (
            <div className="flex items-center bg-neutral-950 p-1 rounded-xl border border-neutral-800">
              <button
                onClick={() => onToggleAppMode('rider')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  appMode === 'rider'
                    ? 'bg-neutral-800 text-neutral-100 shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span>Passenger</span>
              </button>
              <button
                onClick={() => onToggleAppMode('driver')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  appMode === 'driver'
                    ? 'bg-emerald-500 text-neutral-950 shadow font-black'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Car className="w-3.5 h-3.5" />
                <span>Hamba Driver</span>
              </button>
            </div>
          )}

          {/* Push Notifications permission trigger */}
          <button
            onClick={handleToggleNotifications}
            className={`p-2 rounded-xl transition-colors flex items-center gap-1.5 text-xs font-medium border ${
              notifPermission === 'granted'
                ? 'bg-emerald-950/70 border-emerald-800/80 text-emerald-300'
                : 'bg-neutral-800 border-neutral-750 text-neutral-300 hover:bg-neutral-750'
            }`}
            title={
              notifPermission === 'granted'
                ? 'Browser Push Notifications Active'
                : 'Enable Browser Push Notifications'
            }
          >
            <Bell className={`w-4 h-4 ${notifPermission === 'granted' ? 'text-emerald-400' : 'text-neutral-400'}`} />
            <span className="hidden md:inline">
              {notifPermission === 'granted' ? 'Push Alerts Active' : 'Enable Push Alerts'}
            </span>
          </button>

          {/* Sound toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 transition-colors flex items-center gap-1.5 text-xs font-medium"
            title={soundOn ? 'Mute Audio' : 'Unmute Audio'}
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-neutral-500" />}
            <span className="hidden md:inline">{soundOn ? 'Sound On' : 'Muted'}</span>
          </button>

          {/* Toggle Phone Frame vs Responsive */}
          <button
            onClick={() => setIsPhoneMockup(!isPhoneMockup)}
            className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 transition-colors flex items-center gap-1.5 text-xs font-semibold"
          >
            {isPhoneMockup ? (
              <>
                <Maximize2 className="w-4 h-4 text-emerald-400" />
                <span>Full Screen</span>
              </>
            ) : (
              <>
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Phone Frame</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Container - Phone Shell or Fullscreen */}
      <main
        className={`relative transition-all duration-300 overflow-hidden flex flex-col bg-neutral-950 ${
          isPhoneMockup
            ? 'w-full max-w-[410px] h-[100dvh] sm:h-[840px] sm:rounded-[48px] sm:border-[10px] sm:border-neutral-850 sm:shadow-[0_25px_70px_rgba(0,0,0,0.8),0_0_0_1px_rgba(255,255,255,0.1)]'
            : 'w-full max-w-4xl h-[100dvh] sm:h-[840px] sm:rounded-3xl sm:border border-neutral-800 shadow-2xl'
        }`}
      >
        {/* Dynamic Island & Status Bar (in Phone Shell Mode) */}
        <div className="h-11 w-full bg-neutral-950/80 backdrop-blur-md flex items-center justify-between px-6 z-40 select-none flex-shrink-0 border-b border-white/5">
          <span className="text-xs font-bold text-neutral-200 tracking-tight font-mono">
            {currentTime}
          </span>

          {/* Dynamic Island Pill */}
          <div className="h-6 px-3 bg-black rounded-full flex items-center justify-center gap-2 shadow-inner border border-white/10">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
              {appMode === 'driver' ? 'HAMBA DRIVER' : 'HAMBA RIDER'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-neutral-300">
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
        </div>

        {/* Dynamic Main App Workspace */}
        <div className="relative flex-1 w-full overflow-hidden flex flex-col">
          {children}
        </div>

        {/* Bottom Tab Bar (shown when not in an active fullscreen booking step and in rider mode) */}
        {!hasActiveTrip && appMode === 'rider' && (
          <nav className="h-16 w-full bg-neutral-950/95 backdrop-blur-xl border-t border-neutral-850/80 grid grid-cols-3 items-center px-4 z-40 flex-shrink-0">
            <button
              onClick={() => {
                onChangeTab('rides');
                sound.playTap();
              }}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                activeTab === 'rides' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
              }`}
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z" />
              </svg>
              <span className="text-[10px] font-bold tracking-tight">Rides</span>
            </button>

            <button
              onClick={() => {
                onChangeTab('activity');
                sound.playTap();
              }}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                activeTab === 'activity' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
              }`}
            >
              <svg className="w-5 h-5 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              <span className="text-[10px] font-bold tracking-tight">Activity</span>
            </button>

            <button
              onClick={() => {
                onChangeTab('wallet');
                sound.playTap();
              }}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                activeTab === 'wallet' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
              }`}
            >
              <svg className="w-5 h-5 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <path d="M7 15h0" />
                <path d="M2 10h20" />
              </svg>
              <span className="text-[10px] font-bold tracking-tight">Wallet</span>
            </button>
          </nav>
        )}

        {/* iPhone Home Indicator bar */}
        <div className="h-4 w-full bg-neutral-950 flex items-center justify-center flex-shrink-0">
          <div className="w-32 h-1 bg-neutral-600 rounded-full" />
        </div>
      </main>
    </div>
  );
};
