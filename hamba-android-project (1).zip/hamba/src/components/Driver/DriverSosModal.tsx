import React, { useEffect, useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle,
  Phone,
  Radio,
  Shield,
  ShieldAlert,
  Volume2,
  X,
} from 'lucide-react';
import { CURRENT_DRIVER } from '../../data/driverMockData';
import { sound } from '../../services/audio';

interface DriverSosModalProps {
  onClose: () => void;
}

export const DriverSosModal: React.FC<DriverSosModalProps> = ({ onClose }) => {
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isArmedDispatched, setIsArmedDispatched] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (countdown !== null && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
    } else if (countdown === 0) {
      setIsArmedDispatched(true);
      sound.playEmergencySiren();
    }
    return () => clearTimeout(timer);
  }, [countdown]);

  const handleStartCountdown = () => {
    setCountdown(5);
  };

  const handleCancelCountdown = () => {
    setCountdown(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border-2 border-rose-500/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100">
        
        {/* Header */}
        <div className="bg-rose-950/70 p-4 border-b border-rose-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-600 text-white animate-pulse">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Driver Armed Response & SOS
              </h3>
              <p className="text-[11px] text-rose-200">
                SAPS 10111 & Private Tactical Security
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        {!isArmedDispatched ? (
          <div className="p-5 space-y-4">
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs">
              <div className="font-bold text-neutral-200 flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                <span>Live Telemetry & GPS Beacon Active</span>
              </div>
              <p className="text-neutral-400 text-[11px]">
                Driver: <strong>{CURRENT_DRIVER.name}</strong> • Vehicle: <strong>{CURRENT_DRIVER.carModel} ({CURRENT_DRIVER.licensePlate})</strong>
              </p>
            </div>

            {/* Countdown or Trigger Button */}
            {countdown === null ? (
              <button
                onClick={handleStartCountdown}
                className="w-full py-5 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-98 text-white font-black text-base tracking-wider shadow-2xl shadow-rose-950 flex flex-col items-center justify-center gap-1 border-2 border-rose-400"
              >
                <div className="flex items-center gap-2">
                  <AlertOctagon className="w-6 h-6 animate-bounce" />
                  <span>DISPATCH ARMED RESPONSE</span>
                </div>
                <span className="text-[11px] font-medium text-rose-100">
                  Transmits coordinates to Tactical Security Units
                </span>
              </button>
            ) : (
              <div className="p-4 rounded-2xl bg-rose-950/60 border border-rose-600 text-center space-y-3">
                <div className="text-3xl font-black text-white font-mono animate-pulse">
                  Dispatching in {countdown}s...
                </div>
                <p className="text-xs text-rose-200">
                  Stand by. Security operations room is receiving your live location.
                </p>
                <button
                  onClick={handleCancelCountdown}
                  className="px-6 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold text-xs"
                >
                  Cancel (False Alarm)
                </button>
              </div>
            )}

            {/* Direct Dial Options */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <a
                href="tel:10111"
                className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-center text-xs font-bold text-neutral-200 flex items-center justify-center gap-1.5"
              >
                <Phone className="w-4 h-4 text-rose-400" />
                <span>SAPS Flying Squad (10111)</span>
              </a>

              <a
                href="tel:112"
                className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-center text-xs font-bold text-neutral-200 flex items-center justify-center gap-1.5"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Emergency 112 (Cell)</span>
              </a>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-rose-600/20 text-rose-400 flex items-center justify-center border-2 border-rose-500 animate-pulse">
              <ShieldAlert className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <h4 className="text-lg font-black text-white">
                ARMED RESPONSE DISPATCHED
              </h4>
              <p className="text-xs text-neutral-300">
                Security operators and SAPS Flying Squad have been dispatched to your exact GPS coordinates. Keep your phone secure and cabin doors locked.
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3.5 rounded-2xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 font-bold text-xs"
            >
              Close Alert
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
