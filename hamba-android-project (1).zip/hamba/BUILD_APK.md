# Build the HAMBA APK

## Option A - GitHub (no installs, works from a phone/laptop browser)
1. Create a free GitHub account and a new repository.
2. Upload ALL files in this folder to it (keep the folder structure, including the hidden `.github` folder).
3. Open the repo -> Actions -> "Build HAMBA APK" -> Run workflow.
4. After ~5-8 minutes, open the finished run and download the `HAMBA-apk` artifact. Unzip it: `app-debug.apk` is the file to send to people.

## Option B - Android Studio (laptop)
1. `npm install --legacy-peer-deps`
2. `npm run build:android`
3. `npx cap open android` -> Build > Build APK(s). 

## Installing on a phone
Send the .apk (WhatsApp, Drive, etc.). The person opens it and allows "Install unknown apps" for that app when Android asks.
