import React, { useState } from 'react';
import { ArrowLeft, Clock, MapPin, Navigation, Search, Star, X } from 'lucide-react';
import { LocationPoint } from '../../types';

interface WhereToModalProps {
  isOpen: boolean;
  onClose: () => void;
  pickup: LocationPoint | null;
  dropoff: LocationPoint | null;
  onSelectPickup: (loc: LocationPoint) => void;
  onSelectDropoff: (loc: LocationPoint) => void;
  popularLocations: LocationPoint[];
  onConfirmDestination: () => void;
}

export const WhereToModal: React.FC<WhereToModalProps> = ({
  isOpen,
  onClose,
  pickup,
  dropoff,
  onSelectPickup,
  onSelectDropoff,
  popularLocations,
  onConfirmDestination,
}) => {
  const [activeField, setActiveField] = useState<'pickup' | 'dropoff'>('dropoff');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredLocations = popularLocations.filter(
    (loc) =>
      loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handlePickLocation = (loc: LocationPoint) => {
    if (activeField === 'dropoff') {
      onSelectDropoff(loc);
      onConfirmDestination();
    } else {
      onSelectPickup(loc);
      setActiveField('dropoff');
    }
  };

  const handleSwap = () => {
    if (pickup && dropoff) {
      const temp = pickup;
      onSelectPickup(dropoff);
      onSelectDropoff(temp);
    }
  };

  return (
    <div className="absolute inset-0 z-40 bg-neutral-950 flex flex-col animate-in fade-in duration-200">
      {/* Top Navigation */}
      <div className="p-4 border-b border-neutral-800/80 bg-neutral-900/90 backdrop-blur-md flex items-center justify-between">
        <button
          onClick={onClose}
          className="p-2 -ml-2 rounded-full hover:bg-neutral-800 text-neutral-300 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="font-semibold text-neutral-100 text-sm tracking-wide">Plan Your Trip</span>
        <button
          onClick={handleSwap}
          className="text-xs text-emerald-400 hover:text-emerald-300 font-medium px-2 py-1 rounded bg-emerald-950/40 border border-emerald-800/50"
        >
          Swap
        </button>
      </div>

      {/* Input Fields Container */}
      <div className="p-4 space-y-3 bg-neutral-900/40 border-b border-neutral-800/60">
        {/* Pickup Field */}
        <div
          onClick={() => setActiveField('pickup')}
          className={`flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
            activeField === 'pickup'
              ? 'bg-neutral-800 border-emerald-500 shadow-sm'
              : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
          }`}
        >
          <div className="w-3 h-3 rounded-full bg-emerald-500 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] text-neutral-400 font-medium">Pickup point</div>
            <div className="text-sm font-semibold text-neutral-100 truncate">
              {pickup?.name || 'Set pickup location'}
            </div>
          </div>
          {activeField === 'pickup' && (
            <Navigation className="w-4 h-4 text-emerald-400 animate-pulse" />
          )}
        </div>

        {/* Dropoff Field */}
        <div
          onClick={() => setActiveField('dropoff')}
          className={`flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
            activeField === 'dropoff'
              ? 'bg-neutral-800 border-rose-500 shadow-sm'
              : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
          }`}
        >
          <div className="w-3 h-3 rounded-sm bg-rose-500 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] text-neutral-400 font-medium">Where to?</div>
            <input
              type="text"
              placeholder="Search destination, mall, or address..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus={activeField === 'dropoff'}
              className="w-full bg-transparent text-sm font-semibold text-neutral-100 placeholder:text-neutral-500 focus:outline-none"
            />
          </div>
          {searchQuery ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setSearchQuery('');
              }}
              className="p-1 rounded-full text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <Search className="w-4 h-4 text-neutral-400" />
          )}
        </div>
      </div>

      {/* Preset & Saved Quick Access */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Saved Shortcuts */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              const home = popularLocations[0];
              if (home) handlePickLocation(home);
            }}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 hover:border-neutral-700 transition-colors text-left"
          >
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Star className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-neutral-200">Sandton Hub</div>
              <div className="text-[10px] text-neutral-400">Saved Landmark</div>
            </div>
          </button>

          <button
            onClick={() => {
              const airport = popularLocations.find((l) => l.type === 'airport') || popularLocations[1];
              if (airport) handlePickLocation(airport);
            }}
            className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 hover:border-neutral-700 transition-colors text-left"
          >
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-neutral-200">Airport</div>
              <div className="text-[10px] text-neutral-400">O.R. Tambo Intl</div>
            </div>
          </button>
        </div>

        {/* Suggested Locations Header */}
        <div className="pt-2">
          <div className="text-xs font-bold uppercase tracking-wider text-neutral-500 px-1 mb-2">
            {searchQuery ? 'Search Results' : 'Popular Destinations Across South Africa'}
          </div>

          <div className="divide-y divide-neutral-850">
            {filteredLocations.map((loc) => (
              <button
                key={loc.id}
                onClick={() => handlePickLocation(loc)}
                className="w-full py-3 px-2 flex items-center gap-3.5 hover:bg-neutral-900/60 rounded-xl transition-colors text-left group"
              >
                <div className="w-9 h-9 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-400 group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-colors flex-shrink-0">
                  {loc.type === 'airport' ? (
                    <Navigation className="w-4 h-4" />
                  ) : loc.type === 'saved' ? (
                    <Clock className="w-4 h-4" />
                  ) : (
                    <MapPin className="w-4 h-4" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-neutral-100 group-hover:text-emerald-300 transition-colors truncate">
                    {loc.name}
                  </div>
                  <div className="text-xs text-neutral-400 truncate">{loc.address}</div>
                </div>
              </button>
            ))}

            {filteredLocations.length === 0 && (
              <div className="text-center py-10 text-neutral-400 text-sm">
                No matching destinations found. Try searching another landmark or street.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
