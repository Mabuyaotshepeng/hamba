export function registerSW(_opts?: unknown) { return () => {}; }
