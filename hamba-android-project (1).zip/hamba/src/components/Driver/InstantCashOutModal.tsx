import React, { useState } from 'react';
import {
  ArrowRight,
  Banknote,
  Building,
  CheckCircle,
  CreditCard,
  Lock,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
} from 'lucide-react';
import { DRIVER_BANK_ACCOUNTS } from '../../data/driverMockData';
import { sound } from '../../services/audio';

interface InstantCashOutModalProps {
  balance: number;
  onCashOutSuccess: (amount: number) => void;
  onClose: () => void;
}

export const InstantCashOutModal: React.FC<InstantCashOutModalProps> = ({
  balance,
  onCashOutSuccess,
  onClose,
}) => {
  const [selectedBankId, setSelectedBankId] = useState(DRIVER_BANK_ACCOUNTS[0].id);
  const [cashoutAmount, setCashoutAmount] = useState(balance);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const fee = 5.0; // R5.00 instant EFT fee standard in South Africa
  const netTransfer = Math.max(0, cashoutAmount - fee);

  const handleCashOut = () => {
    if (cashoutAmount <= 0 || cashoutAmount > balance) return;
    setIsProcessing(true);
    sound.playTap();

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      sound.playCashOutSuccess();
    }, 1500);
  };

  const handleDone = () => {
    onCashOutSuccess(cashoutAmount);
    onClose();
  };

  const selectedBank = DRIVER_BANK_ACCOUNTS.find((b) => b.id === selectedBankId);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-750 sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100 animate-in slide-in-from-bottom-5 duration-300">
        
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Zap className="w-4 h-4 fill-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-neutral-100">
                Instant Driver Cash-Out
              </h3>
              <p className="text-[11px] text-neutral-400">
                Direct EFT clearance into your South African bank
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        {!isSuccess ? (
          <div className="p-5 space-y-4">
            {/* Balance Card */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-center">
              <span className="text-[11px] text-neutral-400 uppercase font-semibold">
                Available Wallet Balance
              </span>
              <div className="text-3xl font-black text-emerald-400 font-mono mt-0.5">
                R{balance.toFixed(2)}
              </div>
            </div>

            {/* Select Bank Account */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-neutral-300">
                Destination Bank Account
              </label>
              <div className="space-y-1.5">
                {DRIVER_BANK_ACCOUNTS.map((bank) => (
                  <div
                    key={bank.id}
                    onClick={() => {
                      setSelectedBankId(bank.id);
                      sound.playTap();
                    }}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      selectedBankId === bank.id
                        ? 'bg-neutral-800/90 border-emerald-500 text-neutral-100'
                        : 'bg-neutral-950/70 border-neutral-800 text-neutral-400 hover:bg-neutral-850'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-emerald-400 font-bold text-xs">
                        <Building className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-neutral-200">
                          {bank.bankName}
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono">
                          {bank.accountNumber} • {bank.accountType}
                        </div>
                      </div>
                    </div>

                    <div className="w-4 h-4 rounded-full border-2 flex items-center justify-center border-emerald-500">
                      {selectedBankId === bank.id && (
                        <div className="w-2 h-2 rounded-full bg-emerald-400" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary */}
            <div className="p-3.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-2 text-xs">
              <div className="flex justify-between text-neutral-400">
                <span>Requested Cash-Out</span>
                <span className="font-mono text-neutral-200">R{cashoutAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Instant EFT Processing Fee</span>
                <span className="font-mono text-neutral-200">R{fee.toFixed(2)}</span>
              </div>
              <div className="pt-2 border-t border-neutral-800 flex justify-between font-bold text-neutral-100">
                <span>Net Credited to Account</span>
                <span className="font-mono text-emerald-400 text-sm">R{netTransfer.toFixed(2)}</span>
              </div>
            </div>

            {/* Security Notice */}
            <div className="flex items-center gap-2 text-[11px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span>SARB BankservAfrica Instant Pay certified • Clears in &lt; 60 seconds</span>
            </div>

            {/* Submit Button */}
            <button
              disabled={isProcessing || cashoutAmount <= 0}
              onClick={handleCashOut}
              className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 disabled:opacity-50 text-neutral-950 font-black text-sm tracking-wide transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <span>Processing Bank Transfer...</span>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-current" />
                  <span>CASH OUT R{netTransfer.toFixed(2)} NOW</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border-2 border-emerald-500/40">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h4 className="text-base font-extrabold text-neutral-100">
                R{netTransfer.toFixed(2)} Sent Successfully!
              </h4>
              <p className="text-xs text-neutral-400">
                Funds have been dispatched to your {selectedBank?.bankName} ({selectedBank?.accountNumber}). Reference: <strong>HAMBA-PAY-{Math.floor(100000 + Math.random() * 900000)}</strong>
              </p>
            </div>

            <button
              onClick={handleDone}
              className="w-full py-3.5 rounded-2xl bg-neutral-800 hover:bg-neutral-750 text-neutral-100 font-bold text-xs"
            >
              Done
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
