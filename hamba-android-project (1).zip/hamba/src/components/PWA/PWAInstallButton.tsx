import React, { useState } from 'react';
import { ArrowDownToLine, Smartphone } from 'lucide-react';
import { sound } from '../../services/audio';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { DownloadAppModal } from './DownloadAppModal';

interface PWAInstallButtonProps {
  className?: string;
  variant?: 'compact' | 'prominent';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  className = '',
  variant = 'compact',
}) => {
  const { isInstalled } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);

  // If already running in standalone installed app mode, we can show a minimal badge or hide
  if (isInstalled) {
    return null;
  }

  return (
    <>
      <button
        onClick={() => {
          sound.playTap();
          setIsModalOpen(true);
        }}
        type="button"
        title="Download & Install HAMBA App (Android APK / PWA)"
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-emerald-950/90 to-teal-950/90 hover:from-emerald-900/90 hover:to-teal-900/90 border border-emerald-500/80 text-emerald-300 backdrop-blur-md shadow-lg transition-all active:scale-95 text-xs font-bold cursor-pointer ${className}`}
      >
        <ArrowDownToLine className="w-3.5 h-3.5 text-emerald-400 animate-pulse flex-shrink-0" />
        <span className="font-extrabold tracking-tight">Install APK</span>
      </button>

      <DownloadAppModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
