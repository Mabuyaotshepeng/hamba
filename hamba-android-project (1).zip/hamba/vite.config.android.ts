import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

// Used only for the Android (Capacitor) build: no service worker needed,
// because the web files are bundled inside the APK.
export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      'virtual:pwa-register': path.resolve(__dirname, 'src/android-stubs/pwa-register.ts'),
    },
  },
  build: { outDir: 'dist', chunkSizeWarningLimit: 2000 },
});
