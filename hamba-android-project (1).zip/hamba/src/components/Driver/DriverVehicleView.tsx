import React, { useEffect, useState } from 'react';
import {
  Bell,
  BellOff,
  BellRing,
  Car,
  CheckCircle,
  FileCheck,
  FileText,
  Flame,
  HelpCircle,
  MapPin,
  Phone,
  PhoneCall,
  Radio,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Smartphone,
  Sparkles,
  User,
  Wrench,
  Zap,
} from 'lucide-react';
import { CURRENT_DRIVER, VEHICLE_DOCUMENTS } from '../../data/driverMockData';
import { sound } from '../../services/audio';
import { DriverVerificationData } from '../../types/driver';
import { requestNotificationPermission } from '../../utils/notifications';
import { VehicleInspectionModal } from './VehicleInspectionModal';

interface DriverVehicleViewProps {
  surgeAlertsEnabled?: boolean;
  onToggleSurgeAlerts?: (enabled: boolean) => void;
  onSimulateSurgeZone?: () => { zoneName: string; distKm: number; bonus: number; alerted: boolean } | void;
  activeSurgeZonesCount?: number;
  driverCoords?: [number, number];
  verificationData?: DriverVerificationData;
  onOpenVerification?: () => void;
}

export const DriverVehicleView: React.FC<DriverVehicleViewProps> = ({
  surgeAlertsEnabled = true,
  onToggleSurgeAlerts,
  onSimulateSurgeZone,
  activeSurgeZonesCount = 5,
  driverCoords = [-26.115, 28.059],
  verificationData,
  onOpenVerification,
}) => {
  const [isInspectionModalOpen, setIsInspectionModalOpen] = useState(false);
  const [lastInspected, setLastInspected] = useState('Today at 07:15 AM');
  const [notifPermission, setNotifPermission] = useState<string>('default');
  const [testResult, setTestResult] = useState<string | null>(null);

  // Sync notification permission on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotifPermission(Notification.permission);
    }
  }, []);

  const handleRequestPermission = async () => {
    sound.playTap();
    const res = await requestNotificationPermission();
    setNotifPermission(res);
  };

  const handleTestSurgeAlert = () => {
    sound.playTap();
    if (onSimulateSurgeZone) {
      const res = onSimulateSurgeZone();
      if (res) {
        if (res.alerted) {
          setTestResult(
            `🔥 Alert Dispatched! New Surge at ${res.zoneName} (${res.distKm.toFixed(1)} km away, +R${res.bonus}). Push notification sent!`
          );
        } else {
          setTestResult(
            `Surge Zone created at ${res.zoneName} (${res.distKm.toFixed(1)} km), but push notifications are currently toggled OFF.`
          );
        }
      } else {
        setTestResult('⚡ New vicinity surge zone generated!');
      }
    } else {
      setTestResult('⚡ Test alert triggered.');
    }

    setTimeout(() => {
      setTestResult(null);
    }, 6000);
  };

  return (
    <div className="w-full h-full overflow-y-auto bg-neutral-950 text-neutral-100 p-4 pb-20 space-y-4">
      
      {/* Driver Profile Header Card */}
      <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3.5 min-w-0">
            <img
              src={verificationData?.selfieUrl || CURRENT_DRIVER.photo}
              alt={verificationData?.driverName || CURRENT_DRIVER.name}
              className={`w-14 h-14 rounded-2xl object-cover border-2 shadow-md ${
                verificationData?.isVerified ? 'border-emerald-500' : 'border-amber-500'
              }`}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-base font-extrabold text-neutral-100 truncate">
                  {verificationData?.driverName || CURRENT_DRIVER.name}
                </h3>
                {verificationData?.isVerified ? (
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle className="w-3 h-3 text-emerald-400" />
                    <span>Verified</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 border border-amber-800/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3 text-amber-400" />
                    <span>Unverified</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-neutral-400 font-mono mt-0.5">
                {verificationData?.phoneNumber || CURRENT_DRIVER.phoneNumber}
              </p>
              {verificationData?.email && (
                <p className="text-[11px] text-neutral-500 truncate">
                  {verificationData.email}
                </p>
              )}
            </div>
          </div>

          {onOpenVerification && (
            <button
              onClick={() => {
                sound.playTap();
                onOpenVerification();
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 flex-shrink-0 ${
                verificationData?.isVerified
                  ? 'bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-md animate-pulse'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{verificationData?.isVerified ? 'Re-Verify' : 'Verify Now'}</span>
            </button>
          )}
        </div>

        <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="text-amber-300 font-bold">★ {CURRENT_DRIVER.rating}</span>
            <span>•</span>
            <span>{CURRENT_DRIVER.totalTrips} Trips</span>
            <span>•</span>
            <span className="text-emerald-400 font-semibold">{CURRENT_DRIVER.tier}</span>
          </div>
          <span className="font-mono text-[10px] text-neutral-500">
            {verificationData?.isVerified ? 'Ready for Dispatch' : 'Verification Required'}
          </span>
        </div>
      </div>

      {/* Driver Settings: Notifications & Dispatch Preferences */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3.5 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">
                Driver Settings & Alerts
              </h4>
              <p className="text-[11px] text-neutral-400">
                Dispatch notifications and real-time radar preferences
              </p>
            </div>
          </div>
          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
              surgeAlertsEnabled
                ? 'text-emerald-400 bg-emerald-950/80 border-emerald-800/80'
                : 'text-neutral-400 bg-neutral-800 border-neutral-700'
            }`}
          >
            {surgeAlertsEnabled ? 'Alerts ON' : 'Alerts Muted'}
          </span>
        </div>

        {/* Surge Zone Proximity Notification Toggle */}
        <div className="p-3.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`p-2 rounded-xl mt-0.5 transition-colors ${
                  surgeAlertsEnabled
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-neutral-800 text-neutral-500 border border-neutral-700'
                }`}
              >
                <Flame className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-extrabold text-neutral-100">
                    High-Demand Surge Zone Alerts
                  </span>
                  {surgeAlertsEnabled && (
                    <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-400 bg-amber-950/80 border border-amber-800/80 px-1.5 py-0.2 rounded-full">
                      <Zap className="w-2.5 h-2.5 fill-amber-400" />
                      5 km Vicinity
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Send a push notification when a new high-demand <strong className="text-neutral-300">Surge Zone</strong> is created in your immediate vicinity (within 5 km).
                </p>
              </div>
            </div>

            {/* Toggle Switch */}
            <button
              type="button"
              role="switch"
              aria-checked={surgeAlertsEnabled}
              onClick={() => {
                if (onToggleSurgeAlerts) {
                  onToggleSurgeAlerts(!surgeAlertsEnabled);
                }
              }}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-neutral-900 ${
                surgeAlertsEnabled ? 'bg-emerald-500' : 'bg-neutral-700'
              }`}
            >
              <span className="sr-only">Toggle Surge Zone Push Notifications</span>
              <span
                aria-hidden="true"
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                  surgeAlertsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Vicinity Specs & Permission Status */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-850/80 text-[11px]">
            <div className="p-2 rounded-xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between">
              <span className="text-neutral-400">Proximity Radius:</span>
              <span className="font-mono font-bold text-neutral-200">5.0 km</span>
            </div>
            <div className="p-2 rounded-xl bg-neutral-900/80 border border-neutral-800 flex items-center justify-between">
              <span className="text-neutral-400">Browser Push:</span>
              <span
                className={`font-bold ${
                  notifPermission === 'granted'
                    ? 'text-emerald-400'
                    : notifPermission === 'denied'
                    ? 'text-rose-400'
                    : 'text-amber-400'
                }`}
              >
                {notifPermission === 'granted' ? 'Allowed' : notifPermission === 'denied' ? 'Blocked' : 'Default'}
              </span>
            </div>
          </div>

          {/* Request Permission Button if not granted */}
          {notifPermission !== 'granted' && (
            <div className="pt-1">
              <button
                onClick={handleRequestPermission}
                className="w-full py-2 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30 flex items-center justify-center gap-1.5 transition-colors"
              >
                <BellRing className="w-3.5 h-3.5" />
                <span>Enable Browser Push Notifications Permission</span>
              </button>
            </div>
          )}

          {/* Test Action Button to simulate creating a surge zone nearby */}
          <div className="pt-1">
            <button
              onClick={handleTestSurgeAlert}
              className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-850 text-neutral-200 hover:text-white text-xs font-bold border border-neutral-750 flex items-center justify-center gap-2 transition-all active:scale-98 shadow-sm"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Test Vicinity Surge Alert (Create New Surge Zone)</span>
            </button>
          </div>

          {/* Feedback banner after testing */}
          {testResult && (
            <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
              <Sparkles className="w-4 h-4 flex-shrink-0 text-emerald-400" />
              <span className="leading-tight">{testResult}</span>
            </div>
          )}
        </div>
      </div>

      {/* Vehicle Specification Card */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="w-5 h-5 text-emerald-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">
              Registered Vehicle
            </h4>
          </div>
          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-full">
            Active
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 flex items-center justify-between">
          <div>
            <div className="text-sm font-extrabold text-neutral-100">
              {CURRENT_DRIVER.carModel}
            </div>
            <div className="text-xs text-neutral-400 mt-0.5">
              {CURRENT_DRIVER.carColor} • Year {CURRENT_DRIVER.vehicleYear}
            </div>
            <div className="mt-1 flex items-center gap-1.5">
              <span className="text-[10px] font-bold text-neutral-300 bg-neutral-800 border border-neutral-700 px-2 py-0.5 rounded">
                Hamba Go
              </span>
              <span className="text-[10px] font-bold text-neutral-300 bg-neutral-800 border border-neutral-700 px-2 py-0.5 rounded">
                Hamba Comfort
              </span>
            </div>
          </div>

          <div className="text-right">
            <div className="px-3 py-1.5 rounded-xl bg-neutral-900 border-2 border-neutral-700 text-neutral-100 font-mono font-black text-sm tracking-widest shadow-inner">
              {CURRENT_DRIVER.licensePlate}
            </div>
            <span className="text-[10px] text-neutral-500 mt-0.5 block">Gauteng Plate</span>
          </div>
        </div>

        {/* Daily Pre-Trip Inspection Trigger */}
        <div className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <CheckCircle className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-neutral-200">
                Daily Inspection Signed
              </div>
              <div className="text-[10px] text-neutral-400">
                {lastInspected}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              setIsInspectionModalOpen(true);
            }}
            className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-semibold border border-neutral-700"
          >
            Review
          </button>
        </div>
      </div>

      {/* Verified Regulatory Documents */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Driver & Vehicle Compliance</span>
          </h4>
          <span className="text-[10px] text-emerald-400 font-bold">4 of 4 Verified</span>
        </div>

        <div className="space-y-2">
          {VEHICLE_DOCUMENTS.map((doc) => (
            <div
              key={doc.id}
              className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between"
            >
              <div className="min-w-0 pr-2">
                <div className="text-xs font-bold text-neutral-200 truncate">
                  {doc.title}
                </div>
                <div className="text-[10px] text-neutral-400 font-mono mt-0.5 truncate">
                  {doc.reference} • Expires: {doc.expiry}
                </div>
              </div>

              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-full flex-shrink-0">
                {doc.badge}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 24/7 Driver Support & Partner Hotline */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center gap-2">
          <PhoneCall className="w-4 h-4 text-emerald-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">
            24/7 Driver Partner Support
          </h4>
        </div>

        <p className="text-xs text-neutral-400">
          Need assistance with toll disputes, vehicle maintenance, or passenger queries?
        </p>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <a
            href="https://wa.me/27825550192"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 hover:bg-emerald-900/50 transition-colors flex items-center justify-center gap-2 text-xs font-bold text-emerald-300"
          >
            <span>WhatsApp Support</span>
          </a>

          <a
            href="tel:+27800004262"
            className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-750 transition-colors flex items-center justify-center gap-2 text-xs font-bold text-neutral-200 border border-neutral-700"
          >
            <Phone className="w-3.5 h-3.5 text-neutral-400" />
            <span>Toll-Free Call</span>
          </a>
        </div>
      </div>

      {/* Inspection Modal */}
      {isInspectionModalOpen && (
        <VehicleInspectionModal
          onComplete={() => {
            const now = new Date();
            const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
            setLastInspected(`Today at ${timeStr}`);
            setIsInspectionModalOpen(false);
          }}
          onClose={() => setIsInspectionModalOpen(false)}
        />
      )}

    </div>
  );
};
