import React, { useState } from 'react';
import {
  AlertOctagon,
  Check,
  Copy,
  Lock,
  Mic,
  PhoneCall,
  Share2,
  Shield,
  X,
} from 'lucide-react';

interface SafetyModalProps {
  isOpen: boolean;
  onClose: () => void;
  safetyPin?: string;
  driverName?: string;
  licensePlate?: string;
}

export const SafetyModal: React.FC<SafetyModalProps> = ({
  isOpen,
  onClose,
  safetyPin = '7492',
  driverName = 'Sipho Dlamini',
  licensePlate = 'GP 492 KL',
}) => {
  const [copied, setCopied] = useState(false);
  const [audioRecording, setAudioRecording] = useState(false);

  if (!isOpen) return null;

  const handleShareTrip = () => {
    const text = `Tracking my HAMBA ride with driver ${driverName} (${licensePlate}). Safety PIN: ${safetyPin}. Live map link: https://hamba.app/track/hb-${Math.floor(100000 + Math.random() * 900000)}`;
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleEmergencyCall = () => {
    if (confirm('Initiate Emergency Police / Armed Response Dispatch (10111)? Your live GPS coordinates will be relayed immediately.')) {
      alert('Emergency Dispatch notified with current GPS coordinates and driver details.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-850 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-neutral-100">Safety Toolkit</div>
              <div className="text-[10px] text-neutral-400">24/7 Rider Protection Services</div>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          {/* Safety PIN */}
          <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase font-bold text-neutral-400">Verified Ride PIN</div>
              <div className="text-xs text-neutral-300">Always check with driver before entering</div>
            </div>
            <div className="text-lg font-black font-mono text-emerald-400 tracking-widest px-3 py-1 bg-neutral-900 rounded-xl border border-neutral-750">
              {safetyPin}
            </div>
          </div>

          {/* Share Live Trip */}
          <button
            onClick={handleShareTrip}
            className="w-full p-3 rounded-2xl bg-neutral-850 hover:bg-neutral-800 border border-neutral-750 flex items-center justify-between text-left transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <Share2 className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-neutral-200">Share Trip with Loved Ones</div>
                <div className="text-[10px] text-neutral-400">Real-time GPS tracker link</div>
              </div>
            </div>
            <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </span>
          </button>

          {/* Audio Safety Recording Toggle */}
          <div className="p-3 rounded-2xl bg-neutral-850 border border-neutral-750 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl transition-colors ${
                  audioRecording ? 'bg-rose-500/20 text-rose-400' : 'bg-neutral-800 text-neutral-400'
                }`}
              >
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-neutral-200">Encrypted Audio Recording</div>
                <div className="text-[10px] text-neutral-400">
                  {audioRecording ? 'Recording active for this ride' : 'Record in-trip audio for safety'}
                </div>
              </div>
            </div>

            <button
              onClick={() => setAudioRecording(!audioRecording)}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                audioRecording ? 'bg-emerald-500' : 'bg-neutral-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  audioRecording ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Emergency SOS Button */}
          <button
            onClick={handleEmergencyCall}
            className="w-full py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 transition-colors"
          >
            <AlertOctagon className="w-4 h-4" />
            <span>Emergency Police & Armed Dispatch (10111)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
