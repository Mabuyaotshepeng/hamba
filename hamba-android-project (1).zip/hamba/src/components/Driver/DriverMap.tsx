import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { SurgeZone } from '../../types/driver';

interface DriverMapProps {
  center: [number, number];
  zoom: number;
  driverCoords: [number, number];
  driverHeading: number;
  routeCoordinates?: [number, number][];
  pickupCoords?: [number, number] | null;
  dropoffCoords?: [number, number] | null;
  surgeZones: SurgeZone[];
  showSurgeZones?: boolean;
  isNightMode?: boolean;
  className?: string;
  onMapClick?: (lat: number, lng: number) => void;
}

export const DriverMap: React.FC<DriverMapProps> = ({
  center,
  zoom,
  driverCoords,
  driverHeading,
  routeCoordinates,
  pickupCoords,
  dropoffCoords,
  surgeZones,
  showSurgeZones = true,
  isNightMode = true,
  className = '',
  onMapClick,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Layer & Marker refs
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropoffMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const surgeLayersRef = useRef<L.LayerGroup | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center,
        zoom,
        zoomControl: false,
        attributionControl: false,
      });

      const tileUrl = isNightMode
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';

      const tileLayer = L.tileLayer(tileUrl, {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      tileLayerRef.current = tileLayer;

      // Layer group for surge circles
      const surgeGroup = L.layerGroup().addTo(map);
      surgeLayersRef.current = surgeGroup;

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (onMapClick) {
          onMapClick(e.latlng.lat, e.latlng.lng);
        }
      });

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update Tile Theme
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;
    const tileUrl = isNightMode
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    tileLayerRef.current.setUrl(tileUrl);
  }, [isNightMode]);

  // Render Surge Zones
  useEffect(() => {
    const map = mapInstanceRef.current;
    const surgeGroup = surgeLayersRef.current;
    if (!map || !surgeGroup) return;

    surgeGroup.clearLayers();

    if (showSurgeZones && surgeZones.length > 0) {
      surgeZones.forEach((zone) => {
        const color =
          zone.demandLevel === 'extreme'
            ? '#ef4444' // red
            : zone.demandLevel === 'very_high'
            ? '#f59e0b' // amber
            : '#10b981'; // emerald

        // Surge Circle
        const circle = L.circle([zone.lat, zone.lng], {
          radius: zone.radiusMeters,
          color,
          weight: 1.5,
          opacity: 0.8,
          fillColor: color,
          fillOpacity: 0.18,
        });

        // Surge Badge Marker
        const surgeIcon = L.divIcon({
          className: 'custom-surge-pin',
          html: `
            <div style="
              display: flex;
              align-items: center;
              gap: 4px;
              background: rgba(17, 24, 39, 0.92);
              border: 1.5px solid ${color};
              box-shadow: 0 4px 12px rgba(0,0,0,0.5);
              padding: 3px 8px;
              border-radius: 9999px;
              white-space: nowrap;
              transform: translate(-50%, -50%);
              font-family: system-ui, sans-serif;
            ">
              <span style="display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: ${color}; box-shadow: 0 0 6px ${color};"></span>
              <span style="font-size: 11px; font-weight: 800; color: #fff;">+R${zone.bonusAmount}</span>
              <span style="font-size: 9px; font-weight: 700; color: ${color};">${zone.surgeMultiplier}x</span>
            </div>
          `,
          iconSize: [0, 0],
          iconAnchor: [0, 0],
        });

        const badgeMarker = L.marker([zone.lat, zone.lng], {
          icon: surgeIcon,
          interactive: false,
        });

        surgeGroup.addLayer(circle);
        surgeGroup.addLayer(badgeMarker);
      });
    }
  }, [surgeZones, showSurgeZones]);

  // Update Driver Marker & Heading
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const [lat, lng] = driverCoords;

    const driverIcon = L.divIcon({
      className: 'driver-car-marker',
      html: `
        <div style="
          position: relative;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          transform: translate(-50%, -50%);
        ">
          <!-- Pulse halo -->
          <div style="
            position: absolute;
            inset: 2px;
            border-radius: 50%;
            background: rgba(16, 185, 129, 0.25);
            animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;
          "></div>
          
          <!-- Outer Circle with GPS pointer -->
          <div style="
            position: relative;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #0f172a;
            border: 2.5px solid #10b981;
            box-shadow: 0 4px 14px rgba(0,0,0,0.6), 0 0 10px rgba(16, 185, 129, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            transform: rotate(${driverHeading}deg);
            transition: transform 0.3s ease;
          ">
            <!-- Heading needle arrow -->
            <div style="
              position: absolute;
              top: -6px;
              width: 0;
              height: 0;
              border-left: 5px solid transparent;
              border-right: 5px solid transparent;
              border-bottom: 7px solid #10b981;
            "></div>

            <!-- Car silhouette -->
            <svg style="width: 20px; height: 20px; fill: #ffffff;" viewBox="0 0 24 24">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z" />
            </svg>
          </div>
        </div>
      `,
      iconSize: [0, 0],
      iconAnchor: [0, 0],
    });

    if (!driverMarkerRef.current) {
      driverMarkerRef.current = L.marker([lat, lng], {
        icon: driverIcon,
        zIndexOffset: 1000,
      }).addTo(map);
    } else {
      driverMarkerRef.current.setLatLng([lat, lng]);
      driverMarkerRef.current.setIcon(driverIcon);
    }
  }, [driverCoords, driverHeading]);

  // Update Pickup & Dropoff Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Pickup marker
    if (pickupCoords) {
      const pickupIcon = L.divIcon({
        className: 'pickup-nav-marker',
        html: `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            transform: translate(-50%, -100%);
          ">
            <div style="
              background: #10b981;
              color: #000;
              font-size: 10px;
              font-weight: 800;
              padding: 2px 8px;
              border-radius: 9999px;
              box-shadow: 0 4px 10px rgba(0,0,0,0.5);
              white-space: nowrap;
              margin-bottom: 2px;
            ">
              PICKUP
            </div>
            <div style="
              width: 16px;
              height: 16px;
              border-radius: 50%;
              background: #10b981;
              border: 3px solid #ffffff;
              box-shadow: 0 2px 6px rgba(0,0,0,0.5);
            "></div>
          </div>
        `,
        iconSize: [0, 0],
        iconAnchor: [0, 0],
      });

      if (!pickupMarkerRef.current) {
        pickupMarkerRef.current = L.marker(pickupCoords, { icon: pickupIcon }).addTo(map);
      } else {
        pickupMarkerRef.current.setLatLng(pickupCoords);
      }
    } else if (pickupMarkerRef.current) {
      pickupMarkerRef.current.remove();
      pickupMarkerRef.current = null;
    }

    // Dropoff marker
    if (dropoffCoords) {
      const dropoffIcon = L.divIcon({
        className: 'dropoff-nav-marker',
        html: `
          <div style="
            display: flex;
            flex-direction: column;
            align-items: center;
            transform: translate(-50%, -100%);
          ">
            <div style="
              background: #f43f5e;
              color: #fff;
              font-size: 10px;
              font-weight: 800;
              padding: 2px 8px;
              border-radius: 9999px;
              box-shadow: 0 4px 10px rgba(0,0,0,0.5);
              white-space: nowrap;
              margin-bottom: 2px;
            ">
              DROPOFF
            </div>
            <div style="
              width: 16px;
              height: 16px;
              border-radius: 50%;
              background: #f43f5e;
              border: 3px solid #ffffff;
              box-shadow: 0 2px 6px rgba(0,0,0,0.5);
            "></div>
          </div>
        `,
        iconSize: [0, 0],
        iconAnchor: [0, 0],
      });

      if (!dropoffMarkerRef.current) {
        dropoffMarkerRef.current = L.marker(dropoffCoords, { icon: dropoffIcon }).addTo(map);
      } else {
        dropoffMarkerRef.current.setLatLng(dropoffCoords);
      }
    } else if (dropoffMarkerRef.current) {
      dropoffMarkerRef.current.remove();
      dropoffMarkerRef.current = null;
    }
  }, [pickupCoords, dropoffCoords]);

  // Route Polyline
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (routeCoordinates && routeCoordinates.length > 1) {
      if (!routePolylineRef.current) {
        routePolylineRef.current = L.polyline(routeCoordinates, {
          color: '#10b981',
          weight: 5,
          opacity: 0.9,
          lineJoin: 'round',
          lineCap: 'round',
        }).addTo(map);
      } else {
        routePolylineRef.current.setLatLngs(routeCoordinates);
      }

      // Smoothly fit bounds
      const bounds = L.latLngBounds(routeCoordinates);
      map.fitBounds(bounds, { padding: [60, 60], maxZoom: 16 });
    } else if (routePolylineRef.current) {
      routePolylineRef.current.remove();
      routePolylineRef.current = null;
    }
  }, [routeCoordinates]);

  // Center on driver when no route
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || (routeCoordinates && routeCoordinates.length > 1)) return;
    map.panTo(driverCoords, { animate: true });
  }, [driverCoords, routeCoordinates]);

  return (
    <div className={`w-full h-full relative overflow-hidden ${className}`}>
      <div ref={mapContainerRef} className="w-full h-full" />
    </div>
  );
};
