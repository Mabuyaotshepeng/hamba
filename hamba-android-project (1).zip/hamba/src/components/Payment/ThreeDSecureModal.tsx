import React, { useEffect, useState } from 'react';
import { CheckCircle2, Lock, Shield, X } from 'lucide-react';
import { sound } from '../../services/audio';

interface ThreeDSecureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  amount: number;
  currencySymbol: string;
  cardLast4: string;
}

export const ThreeDSecureModal: React.FC<ThreeDSecureModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  amount,
  currencySymbol,
  cardLast4,
}) => {
  const [otp, setOtp] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);

  useEffect(() => {
    if (isOpen) {
      setOtp('');
      setIsProcessing(false);
      setIsSuccess(false);
      setTimeLeft(120);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || isSuccess) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen, isSuccess]);

  if (!isOpen) return null;

  const handleVerify = () => {
    if (otp.length < 4) return;
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      sound.playPaymentSuccess();
      setTimeout(() => {
        onSuccess();
      }, 1200);
    }, 1500);
  };

  const handleAutoFill = () => {
    setOtp('584920');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
        {/* Bank Header */}
        <div className="bg-gradient-to-r from-neutral-850 to-neutral-900 p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-neutral-100">3D Secure 2.2 Verification</div>
              <div className="text-[10px] text-neutral-400">Verified by Visa / Mastercard ID Check</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {isSuccess ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-base font-bold text-neutral-100">Card Verified Successfully!</h4>
              <p className="text-xs text-neutral-400">
                Your payment token is authorized and encrypted.
              </p>
            </div>
          ) : (
            <>
              <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Merchant:</span>
                  <span className="font-semibold text-neutral-200">HAMBA E-Hailing Ltd</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Card:</span>
                  <span className="font-mono text-neutral-200">•••• •••• •••• {cardLast4}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Authorized Amount:</span>
                  <span className="font-bold text-emerald-400">
                    {currencySymbol} {amount.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-300 font-medium">Enter One-Time PIN (OTP):</span>
                  <button
                    onClick={handleAutoFill}
                    className="text-[11px] text-emerald-400 hover:underline font-semibold"
                  >
                    Simulate Auto-Fill (584920)
                  </button>
                </div>

                <input
                  type="text"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="6-digit code"
                  className="w-full text-center tracking-[0.4em] font-mono text-lg font-bold bg-neutral-950 border border-neutral-800 rounded-xl py-3 text-white focus:outline-none focus:border-emerald-500"
                />

                <div className="flex justify-between text-[11px] text-neutral-500">
                  <span>Code expires in: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
                  <span className="flex items-center gap-1 text-emerald-500">
                    <Lock className="w-3 h-3" /> 256-bit TLS
                  </span>
                </div>
              </div>

              <button
                onClick={handleVerify}
                disabled={otp.length < 4 || isProcessing}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-neutral-950 font-bold text-sm transition-all flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                    <span>Authorizing with Bank...</span>
                  </>
                ) : (
                  <span>Authenticate & Confirm</span>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
