import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  Play,
  Plus,
  RotateCcw,
  ShieldCheck,
  Star,
  Trash2,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { PastRideRecord, ScheduledRideRecord } from '../../types';
import { formatCurrency } from '../../utils/geo';

interface ActivityViewProps {
  rides: PastRideRecord[];
  scheduledRides: ScheduledRideRecord[];
  onRebook: (ride: PastRideRecord) => void;
  onStartScheduledRide: (ride: ScheduledRideRecord) => void;
  onCancelScheduledRide: (rideId: string) => void;
  onOpenScheduleModal: () => void;
  currencySymbol: string;
}

export const ActivityView: React.FC<ActivityViewProps> = ({
  rides,
  scheduledRides,
  onRebook,
  onStartScheduledRide,
  onCancelScheduledRide,
  onOpenScheduleModal,
  currencySymbol,
}) => {
  const [activityTab, setActivityTab] = useState<'past' | 'scheduled'>('past');

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
      {/* View Header */}
      <div className="pt-2 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-neutral-100">Your Activity</h2>
          <p className="text-xs text-neutral-400 mt-0.5">Trips history & upcoming reservations</p>
        </div>

        {activityTab === 'scheduled' && (
          <button
            onClick={() => {
              onOpenScheduleModal();
              sound.playTap();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule</span>
          </button>
        )}
      </div>

      {/* Segmented Tab Switcher (Past vs Scheduled) */}
      <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-2xl">
        <button
          onClick={() => {
            setActivityTab('past');
            sound.playTap();
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activityTab === 'past'
              ? 'bg-neutral-800 text-neutral-100 shadow-sm border border-neutral-700/60'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <span>Past Trips</span>
          <span className="text-[10px] text-neutral-500 font-normal">({rides.length})</span>
        </button>

        <button
          onClick={() => {
            setActivityTab('scheduled');
            sound.playTap();
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activityTab === 'scheduled'
              ? 'bg-neutral-800 text-neutral-100 shadow-sm border border-neutral-700/60'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <span>Scheduled</span>
          {scheduledRides.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
              {scheduledRides.length}
            </span>
          )}
        </button>
      </div>

      {/* Tab 1: Past Trips */}
      {activityTab === 'past' && (
        <div className="space-y-3">
          {rides.map((ride) => (
            <div
              key={ride.id}
              className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 hover:border-neutral-750 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-neutral-100">{ride.categoryName}</span>
                    <span className="text-[10px] text-neutral-500 font-mono">#{ride.id}</span>
                  </div>
                  <div className="text-[11px] text-neutral-400 mt-0.5 flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-neutral-500" />
                    <span>{ride.date}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-extrabold text-neutral-100">
                    {formatCurrency(ride.fare, currencySymbol)}
                  </div>
                  <div className="text-[10px] text-emerald-400 flex items-center justify-end gap-1 mt-0.5">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Paid · {ride.paymentMethodLabel}</span>
                  </div>
                </div>
              </div>

              {/* Route details */}
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-850 space-y-1.5 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-neutral-300 font-medium truncate">{ride.pickupName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-sm bg-rose-500" />
                  <span className="text-neutral-300 font-medium truncate">{ride.dropoffName}</span>
                </div>
              </div>

              {/* Driver & Rebook button */}
              <div className="pt-1 flex items-center justify-between border-t border-neutral-850 text-xs">
                <div className="flex items-center gap-1.5 text-neutral-400">
                  <span>Driver:</span>
                  <span className="text-neutral-200 font-medium">{ride.driverName}</span>
                  <span className="flex items-center gap-0.5 text-amber-400 text-[11px]">
                    <Star className="w-3 h-3 fill-current" />
                    {ride.driverRating}
                  </span>
                </div>

                <button
                  onClick={() => onRebook(ride)}
                  className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-neutral-200 hover:text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Rebook</span>
                </button>
              </div>
            </div>
          ))}

          {rides.length === 0 && (
            <div className="text-center py-12 text-neutral-400 text-xs">
              No previous rides yet. Book your first HAMBA trip!
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Scheduled Rides */}
      {activityTab === 'scheduled' && (
        <div className="space-y-3">
          {scheduledRides.map((sch) => (
            <div
              key={sch.id}
              className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 hover:border-neutral-750 transition-colors shadow-lg"
            >
              {/* Header with Date & Status */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Scheduled</span>
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono">#{sch.id}</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-sm font-extrabold text-neutral-100 mt-1.5">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    <span>{sch.scheduledDate}</span>
                    <span className="text-neutral-500">·</span>
                    <Clock className="w-3.5 h-3.5 text-neutral-400" />
                    <span className="font-mono text-emerald-300">{sch.scheduledTime}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-extrabold text-neutral-100">
                    {formatCurrency(sch.estimatedFare, currencySymbol)}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-medium">Locked Rate</div>
                </div>
              </div>

              {/* Vehicle category info */}
              <div className="flex items-center justify-between text-xs text-neutral-400 border-t border-neutral-850 pt-2">
                <span className="font-semibold text-neutral-200">{sch.category.name}</span>
                <span>Payment: {sch.paymentMethod.title}</span>
              </div>

              {/* Route */}
              <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-850 space-y-1.5 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-neutral-300 font-medium truncate">{sch.pickup.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-sm bg-rose-500" />
                  <span className="text-neutral-300 font-medium truncate">{sch.dropoff.name}</span>
                </div>
              </div>

              {/* Guarantee text */}
              <div className="flex items-center gap-1.5 text-[10px] text-neutral-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Driver guaranteed 10 mins prior · Free cancellation</span>
              </div>

              {/* Actions: Start Ride Now OR Cancel */}
              <div className="pt-2 border-t border-neutral-850 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    if (confirm('Cancel this scheduled ride reservation?')) {
                      onCancelScheduledRide(sch.id);
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-400 hover:text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Cancel</span>
                </button>

                <button
                  onClick={() => {
                    onStartScheduledRide(sch);
                    sound.playTap();
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-md transition-all active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Ride Now</span>
                </button>
              </div>
            </div>
          ))}

          {scheduledRides.length === 0 && (
            <div className="p-8 rounded-3xl bg-neutral-900 border border-neutral-800 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-100">No Scheduled Rides</h4>
                <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
                  Need to be at the airport or an early meeting? Reserve a HAMBA ride up to 30 days in advance.
                </p>
              </div>
              <button
                onClick={() => {
                  onOpenScheduleModal();
                  sound.playTap();
                }}
                className="py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs transition-colors inline-flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule a Ride Now</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
