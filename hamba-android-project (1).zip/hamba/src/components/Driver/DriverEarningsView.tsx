import React, { useState } from 'react';
import {
  ArrowUpRight,
  Calendar,
  ChevronRight,
  Clock,
  CreditCard,
  DollarSign,
  Flame,
  HelpCircle,
  History,
  Sparkles,
  TrendingUp,
  Wallet,
  Zap,
  BarChart3,
  CalendarDays,
  CheckCircle2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { sound } from '../../services/audio';
import { DriverEarningsData } from '../../types/driver';
import { InstantCashOutModal } from './InstantCashOutModal';

interface DriverEarningsViewProps {
  earnings: DriverEarningsData;
  onCashOut: (amount: number) => void;
}

const DEFAULT_MONTHLY_BREAKDOWN = [
  { month: 'Apr 2026', shortMonth: 'Apr', year: 2026, amount: 17850.0, trips: 172, hoursOnline: 154 },
  { month: 'May 2026', shortMonth: 'May', year: 2026, amount: 19420.0, trips: 188, hoursOnline: 168 },
  { month: 'Jun 2026', shortMonth: 'Jun', year: 2026, amount: 20850.0, trips: 202, hoursOnline: 176 },
  { month: 'Jul 2026', shortMonth: 'Jul', year: 2026, amount: 22400.0, trips: 218, hoursOnline: 184 },
  { month: 'Aug 2026', shortMonth: 'Aug', year: 2026, amount: 21750.0, trips: 210, hoursOnline: 180 },
  { month: 'Sep 2026', shortMonth: 'Sep', year: 2026, amount: 24320.0, trips: 234, hoursOnline: 192 },
  { month: 'Oct 2026', shortMonth: 'Oct', year: 2026, amount: 25980.0, trips: 248, hoursOnline: 204 },
];

export const DriverEarningsView: React.FC<DriverEarningsViewProps> = ({
  earnings,
  onCashOut,
}) => {
  const [isCashOutOpen, setIsCashOutOpen] = useState(false);
  const [timeframe, setTimeframe] = useState<'7days' | 'months'>('7days');
  const [showAverageLine, setShowAverageLine] = useState(true);

  const goalPercent = Math.min(100, Math.round((earnings.weeklyEarnings / earnings.weeklyGoal) * 100));

  const formatHours = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m}m`;
  };

  // Prepare 7-day daily data for recharts
  const dailyData = earnings.dailyBreakdown.map((item) => {
    const isToday = item.day.includes('Today');
    const cleanLabel = item.day.replace(' (Today)', '');
    return {
      label: cleanLabel,
      fullLabel: item.day,
      amount: item.amount,
      trips: item.trips,
      avgPerTrip: item.trips > 0 ? Math.round(item.amount / item.trips) : 0,
      isToday,
    };
  });

  // Prepare monthly data for recharts
  const monthlyData = (earnings.monthlyBreakdown || DEFAULT_MONTHLY_BREAKDOWN).map((item) => ({
    label: item.shortMonth,
    fullLabel: item.month,
    amount: item.amount,
    trips: item.trips,
    hoursOnline: item.hoursOnline,
    avgPerTrip: item.trips > 0 ? Math.round(item.amount / item.trips) : 0,
    hourlyRate: item.hoursOnline > 0 ? Math.round(item.amount / item.hoursOnline) : 0,
    isToday: item.month.includes('Oct 2026'),
  }));

  const chartData = timeframe === '7days' ? dailyData : monthlyData;

  // Trend analysis metrics
  const totalPeriodAmount = chartData.reduce((sum, d) => sum + d.amount, 0);
  const averageAmount = Math.round(totalPeriodAmount / (chartData.length || 1));
  const peakItem = chartData.reduce(
    (max, d) => (d.amount > max.amount ? d : max),
    chartData[0] || { label: '', fullLabel: '', amount: 0, trips: 0 }
  );
  const totalTrips = chartData.reduce((sum, d) => sum + d.trips, 0);

  // Growth percentage
  const growthRate =
    timeframe === '7days'
      ? '+18.4%' // Weekend surge & daily ramp
      : '+45.5%'; // Growth since April

  // Custom Dark Tooltip Component
  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload || !payload.length) return null;
    const data = payload[0].payload;
    if (!data) return null;

    return (
      <div className="bg-neutral-900/95 border border-neutral-750 backdrop-blur-md rounded-2xl p-3 shadow-2xl min-w-[170px] text-xs space-y-2 pointer-events-none">
        <div className="flex items-center justify-between text-[11px] text-neutral-400 border-b border-neutral-800 pb-1.5">
          <span className="font-bold text-neutral-100">{data.fullLabel}</span>
          {data.isToday && (
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-1.5 py-0.5 rounded">
              Current
            </span>
          )}
        </div>

        <div>
          <div className="text-[10px] text-neutral-400 uppercase font-semibold">Net Earnings</div>
          <div className="text-lg font-black text-emerald-400 font-mono">
            R{data.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        <div className="pt-1 border-t border-neutral-800/80 space-y-1 text-[11px]">
          <div className="flex items-center justify-between text-neutral-300">
            <span className="text-neutral-400">Completed Trips:</span>
            <span className="font-mono font-bold text-neutral-100">{data.trips}</span>
          </div>

          <div className="flex items-center justify-between text-neutral-300">
            <span className="text-neutral-400">Avg / Trip:</span>
            <span className="font-mono font-bold text-neutral-100">R{data.avgPerTrip}</span>
          </div>

          {data.hoursOnline && (
            <div className="flex items-center justify-between text-neutral-300">
              <span className="text-neutral-400">Hours Online:</span>
              <span className="font-mono font-bold text-neutral-100">{data.hoursOnline}h</span>
            </div>
          )}

          {data.hourlyRate && (
            <div className="flex items-center justify-between text-neutral-300">
              <span className="text-neutral-400">Effective Rate:</span>
              <span className="font-mono font-bold text-emerald-400">R{data.hourlyRate}/h</span>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-full overflow-y-auto bg-neutral-950 text-neutral-100 p-4 pb-20 space-y-4">
      
      {/* Top Banner: Today's Earnings & Balance */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-neutral-900 via-neutral-900 to-emerald-950/60 border border-neutral-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Today's Take-Home
            </span>
          </div>

          <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2.5 py-0.5 rounded-full">
            Platinum 12% Rate
          </span>
        </div>

        <div>
          <div className="text-4xl font-black text-neutral-100 font-mono tracking-tight">
            R{earnings.todayEarnings.toFixed(2)}
          </div>
          <div className="flex items-center gap-3 text-xs text-neutral-400 mt-1">
            <span>{earnings.todayTrips} trips completed</span>
            <span>•</span>
            <span>{formatHours(earnings.todayOnlineMinutes)} online</span>
          </div>
        </div>

        {/* Quick Driver Balance & Instant Cash-Out */}
        <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-neutral-400 uppercase font-bold">
              Available to Cash Out
            </div>
            <div className="text-lg font-black text-emerald-400 font-mono">
              R{earnings.driverBalance.toFixed(2)}
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              setIsCashOutOpen(true);
            }}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-bold text-xs tracking-tight transition-all shadow-md flex items-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Cash Out Now</span>
          </button>
        </div>
      </div>

      {/* Recharts Trend Analysis Line Chart Card */}
      <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-lg space-y-4">
        {/* Header & View Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-extrabold text-neutral-100 tracking-tight">
                Earnings Trend Analysis
              </h3>
            </div>
            <p className="text-[11px] text-neutral-400 mt-0.5">
              {timeframe === '7days'
                ? 'Daily performance and trajectory over the last 7 days'
                : 'Cumulative monthly revenue and performance over the past months'}
            </p>
          </div>

          {/* Interactive Period Switcher (Zero-pill segmented buttons) */}
          <div className="flex items-center p-1 bg-neutral-950 rounded-xl border border-neutral-800 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => {
                sound.playTap();
                setTimeframe('7days');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                timeframe === '7days'
                  ? 'bg-neutral-800 text-emerald-400 shadow-sm border border-neutral-700/60'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Last 7 Days</span>
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playTap();
                setTimeframe('months');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
                timeframe === 'months'
                  ? 'bg-neutral-800 text-emerald-400 shadow-sm border border-neutral-700/60'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Past Months</span>
            </button>
          </div>
        </div>

        {/* Quick Trend KPI Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800/80">
          <div>
            <div className="text-[10px] text-neutral-500 font-semibold uppercase">
              {timeframe === '7days' ? '7-Day Total' : 'Period Total'}
            </div>
            <div className="text-base font-black text-neutral-100 font-mono mt-0.5">
              R{totalPeriodAmount.toLocaleString('en-ZA', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-emerald-400 flex items-center gap-0.5 font-semibold mt-0.5">
              <ArrowUpRight className="w-3 h-3" />
              <span>{growthRate} trend</span>
            </div>
          </div>

          <div>
            <div className="text-[10px] text-neutral-500 font-semibold uppercase">
              {timeframe === '7days' ? 'Daily Average' : 'Monthly Average'}
            </div>
            <div className="text-base font-black text-emerald-400 font-mono mt-0.5">
              R{averageAmount.toLocaleString('en-ZA', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">
              {timeframe === '7days' ? 'across 7 days' : `across ${chartData.length} months`}
            </div>
          </div>

          <div>
            <div className="text-[10px] text-neutral-500 font-semibold uppercase">
              {timeframe === '7days' ? 'Peak Day' : 'Best Month'}
            </div>
            <div className="text-base font-black text-neutral-100 font-mono mt-0.5">
              R{peakItem.amount.toLocaleString('en-ZA', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-neutral-400 truncate mt-0.5">
              {peakItem.fullLabel}
            </div>
          </div>

          <div>
            <div className="text-[10px] text-neutral-500 font-semibold uppercase">
              Total Trips
            </div>
            <div className="text-base font-black text-neutral-100 font-mono mt-0.5">
              {totalTrips}
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">
              R{Math.round(totalPeriodAmount / Math.max(1, totalTrips))}/trip avg
            </div>
          </div>
        </div>

        {/* Recharts Line Chart Visualization */}
        <div className="relative pt-2">
          {/* Chart Controls (Average Line toggle) */}
          <div className="flex items-center justify-between text-[11px] text-neutral-400 pb-2 px-1">
            <span className="font-mono text-[10px]">
              Tap/hover data points for detailed breakdown
            </span>

            <button
              type="button"
              onClick={() => {
                sound.playTap();
                setShowAverageLine(!showAverageLine);
              }}
              className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-semibold transition-colors ${
                showAverageLine
                  ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/60'
                  : 'text-neutral-500 bg-neutral-950 border border-neutral-800'
              }`}
              title="Toggle Average Baseline"
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  showAverageLine ? 'bg-emerald-400' : 'bg-neutral-600'
                }`}
              />
              <span>Avg Baseline (R{averageAmount})</span>
            </button>
          </div>

          <div className="w-full h-56 sm:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 12, right: 12, left: -16, bottom: 4 }}
              >
                <CartesianGrid
                  stroke="#262626"
                  strokeDasharray="3 3"
                  vertical={false}
                />

                <XAxis
                  dataKey="label"
                  stroke="#525252"
                  tick={{ fill: '#a3a3a3', fontSize: 11, fontWeight: 500 }}
                  axisLine={{ stroke: '#333333' }}
                  tickLine={false}
                />

                <YAxis
                  stroke="#525252"
                  tick={{ fill: '#737373', fontSize: 10, fontFamily: 'monospace' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(val: number) =>
                    val >= 1000
                      ? `R${(val / 1000).toFixed(val % 1000 === 0 ? 0 : 1)}k`
                      : `R${val}`
                  }
                />

                <Tooltip content={<CustomTooltip />} />

                {showAverageLine && (
                  <ReferenceLine
                    y={averageAmount}
                    stroke="#059669"
                    strokeDasharray="4 4"
                    strokeWidth={1.5}
                    label={{
                      value: `Avg R${averageAmount}`,
                      fill: '#10b981',
                      fontSize: 10,
                      position: 'insideTopLeft',
                      offset: 6,
                    }}
                  />
                )}

                <Line
                  type="monotone"
                  dataKey="amount"
                  name="Earnings (R)"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{
                    r: 4,
                    fill: '#064e3b',
                    stroke: '#34d399',
                    strokeWidth: 2,
                  }}
                  activeDot={{
                    r: 7,
                    fill: '#10b981',
                    stroke: '#ffffff',
                    strokeWidth: 2,
                  }}
                  animationDuration={800}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Period Context Footer */}
          <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
            <span>
              {timeframe === '7days' ? (
                <span>
                  Showing daily take-home earnings · <strong className="text-neutral-200">Sun (Today)</strong> is live
                </span>
              ) : (
                <span>
                  Showing monthly net payouts · <strong className="text-neutral-200">7 Months of History</strong>
                </span>
              )}
            </span>
            <span className="font-mono text-emerald-400 font-bold">
              ZAR (R) Net Payouts
            </span>
          </div>
        </div>
      </div>

      {/* Weekly Goal Progress Bar */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-neutral-300">Weekly Target</span>
          <span className="font-mono text-emerald-400 font-bold">
            R{earnings.weeklyEarnings.toFixed(0)} / R{earnings.weeklyGoal.toFixed(0)} ({goalPercent}%)
          </span>
        </div>

        <div className="w-full h-2.5 rounded-full bg-neutral-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
            style={{ width: `${goalPercent}%` }}
          />
        </div>

        <p className="text-[11px] text-neutral-400">
          R{(earnings.weeklyGoal - earnings.weeklyEarnings).toFixed(0)} remaining to unlock the R350 Sunday bonus.
        </p>
      </div>

      {/* Today's Extra Rewards & Breakdown */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center gap-1.5 text-xs text-neutral-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Tips Earned Today</span>
          </div>
          <div className="text-lg font-black text-amber-400 font-mono mt-1">
            R{earnings.tipsToday.toFixed(2)}
          </div>
          <div className="text-[10px] text-neutral-500">100% kept by driver</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center gap-1.5 text-xs text-neutral-400">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Surge Bonuses</span>
          </div>
          <div className="text-lg font-black text-rose-400 font-mono mt-1">
            R{earnings.surgeBonusToday.toFixed(2)}
          </div>
          <div className="text-[10px] text-neutral-500">High demand hours</div>
        </div>
      </div>

      {/* Recent Completed Trips */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-neutral-400 px-1">
          <span>Recent Completed Trips</span>
          <span>{earnings.recentTrips.length} Trips</span>
        </div>

        <div className="space-y-2">
          {earnings.recentTrips.map((trip) => (
            <div
              key={trip.id}
              className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between hover:bg-neutral-850 transition-colors"
            >
              <div className="min-w-0 pr-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-neutral-100 truncate">
                    {trip.passengerName}
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">{trip.time}</span>
                </div>
                <div className="text-[11px] text-neutral-400 truncate mt-0.5">
                  {trip.pickup} → {trip.dropoff}
                </div>
                <div className="text-[10px] text-neutral-500 flex items-center gap-2 mt-0.5">
                  <span>{trip.distanceKm} km</span>
                  <span>•</span>
                  <span>{trip.paymentType}</span>
                  {trip.tip > 0 && (
                    <span className="text-amber-400 font-bold">+R{trip.tip} Tip</span>
                  )}
                </div>
              </div>

              <div className="text-right flex-shrink-0">
                <div className="text-sm font-black text-emerald-400 font-mono">
                  +R{trip.netPayout.toFixed(2)}
                </div>
                <span className="text-[10px] text-neutral-500">Net payout</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cash Out Modal */}
      {isCashOutOpen && (
        <InstantCashOutModal
          balance={earnings.driverBalance}
          onCashOutSuccess={(amt) => {
            onCashOut(amt);
            setIsCashOutOpen(false);
          }}
          onClose={() => setIsCashOutOpen(false)}
        />
      )}

    </div>
  );
};
