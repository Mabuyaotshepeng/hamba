import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  Car,
  Check,
  CheckCircle,
  ChevronDown,
  Copy,
  FastForward,
  Flag,
  MessageCircle,
  Navigation,
  Phone,
  Receipt,
  Share2,
  Shield,
  ShieldAlert,
  Star,
  X,
} from 'lucide-react';
import { ActiveTrip } from '../../types';
import { formatCurrency } from '../../utils/geo';
import { ReportIncidentModal } from './ReportIncidentModal';

interface ActiveTripCardProps {
  trip: ActiveTrip;
  onOpenChat: () => void;
  onOpenSafety: () => void;
  onOpenSos?: () => void;
  onCancelTrip: () => void;
  onSpeedUpSimulation: () => void;
  simulationSpeed: number;
  currencySymbol: string;
}

export const ActiveTripCard: React.FC<ActiveTripCardProps> = ({
  trip,
  onOpenChat,
  onOpenSafety,
  onOpenSos,
  onCancelTrip,
  onSpeedUpSimulation,
  simulationSpeed,
  currencySymbol,
}) => {
  const [showFareBreakdown, setShowFareBreakdown] = useState(false);
  const [isReportIncidentOpen, setIsReportIncidentOpen] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const isSearching = trip.status === 'searching_driver';
  const isArriving = trip.status === 'driver_accepted' || trip.status === 'driver_arriving';
  const isArrived = trip.status === 'driver_arrived';
  const isInTrip = trip.status === 'in_progress';

  // Share Live Trip handler
  const handleShareTrip = () => {
    const trackingUrl = `https://hamba.app/track/hb-${Math.floor(100000 + Math.random() * 900000)}`;
    const text = `Tracking my live HAMBA ride!\nDriver: ${trip.driver.name} (${trip.driver.carColor} ${trip.driver.carModel}, ${trip.driver.licensePlate})\nSafety PIN: ${trip.safetyPin}\nPickup: ${trip.pickup.name}\nDropoff: ${trip.dropoff.name}\nLive Tracker: ${trackingUrl}`;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  // Itemized Fare Components
  const baseFare = trip.category.baseFare;
  const distanceFee = Math.round(trip.distanceKm * trip.category.perKmRate);
  const timeFee = Math.max(5, Math.round(trip.etaMinutes * trip.category.perMinuteRate));

  // Percentage of journey completed from pickup to dropoff
  const totalJourneySteps = Math.max(1, (trip.routeCoordinates?.length || 1) - 1);
  const journeyPercent =
    trip.status === 'completed'
      ? 100
      : isInTrip
      ? Math.min(100, Math.max(0, Math.round((trip.tripStepIndex / totalJourneySteps) * 100)))
      : 0;

  if (isSearching) {
    return (
      <div className="absolute inset-x-0 bottom-0 z-30 bg-neutral-950/95 backdrop-blur-xl rounded-t-3xl border-t border-neutral-800 p-5 shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="flex flex-col items-center text-center space-y-3.5">
          <div className="relative flex items-center justify-center my-1">
            <div className="w-20 h-20 rounded-full border-2 border-emerald-500/20 animate-ping absolute" />
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Navigation className="w-8 h-8 animate-spin" style={{ animationDuration: '3s' }} />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-neutral-100">Finding your {trip.category.name}...</h3>
            <p className="text-xs text-neutral-400 mt-1 max-w-xs">
              Matching you with the nearest top-rated driver in Sandton with secure verified vehicle checks.
            </p>
          </div>

          {/* Detailed Upfront Fare Breakdown */}
          <div className="w-full p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2 text-xs text-left">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div className="flex items-center gap-1.5 font-bold text-neutral-200">
                <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                <span>Upfront Fare Transparency</span>
              </div>
              <span className="font-mono font-black text-emerald-400 text-sm">
                {formatCurrency(trip.finalFare, currencySymbol)}
              </span>
            </div>

            <div className="space-y-1 text-[11px] text-neutral-400">
              <div className="flex justify-between">
                <span>Base Fare:</span>
                <span className="font-mono text-neutral-200">{formatCurrency(baseFare, currencySymbol)}</span>
              </div>
              <div className="flex justify-between">
                <span>Distance Fee ({trip.distanceKm} km @ {formatCurrency(trip.category.perKmRate, currencySymbol)}/km):</span>
                <span className="font-mono text-neutral-200">{formatCurrency(distanceFee, currencySymbol)}</span>
              </div>
              <div className="flex justify-between">
                <span>Time Fee (~{trip.etaMinutes} mins @ {formatCurrency(trip.category.perMinuteRate, currencySymbol)}/min):</span>
                <span className="font-mono text-neutral-200">{formatCurrency(timeFee, currencySymbol)}</span>
              </div>
              {trip.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Promo Discount:</span>
                  <span className="font-mono">-{formatCurrency(trip.discountAmount, currencySymbol)}</span>
                </div>
              )}
            </div>
          </div>

          <button
            onClick={onCancelTrip}
            className="w-full py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-rose-400 hover:bg-rose-950/30 text-xs font-semibold transition-colors"
          >
            Cancel Request
          </button>
        </div>
      </div>
    );
  }

  // Active driver tracking card
  return (
    <div className="absolute inset-x-0 bottom-0 z-30 bg-neutral-950/95 backdrop-blur-xl rounded-t-3xl border-t border-neutral-800 shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-300">
      {/* Top drag bar & Status Banner */}
      <div className="px-4 pt-3 pb-2 border-b border-neutral-850">
        <div className="w-10 h-1 rounded-full bg-neutral-700 mx-auto mb-2.5" />
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <h3 className="text-sm font-bold text-neutral-100">
                {isArrived
                  ? 'Driver has arrived!'
                  : isInTrip
                  ? 'On trip to destination'
                  : 'Driver is on the way'}
              </h3>
            </div>
            <div className="text-xs text-neutral-400 mt-0.5">
              {isArrived
                ? `${trip.driver.carModel} is waiting outside`
                : isInTrip
                ? `Arriving in ~${Math.max(1, trip.etaMinutes)} mins`
                : `${Math.max(1, trip.etaMinutes)} min away · ${(trip.distanceKm * 0.4).toFixed(1)} km`}
            </div>
          </div>

          {/* Safety PIN Badge */}
          <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-750 text-center shadow-inner">
            <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-bold">Safety PIN</div>
            <div className="text-base font-black text-emerald-400 font-mono tracking-widest">
              {trip.safetyPin}
            </div>
          </div>
        </div>
      </div>

      {/* Driver & Car Details Container */}
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={trip.driver.photo}
                alt={trip.driver.name}
                className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500 shadow-md"
              />
              <div className="absolute -bottom-1 -right-1 bg-neutral-900 border border-neutral-700 px-1 rounded text-[9px] font-bold text-amber-400 flex items-center gap-0.5">
                <Star className="w-2.5 h-2.5 fill-current" />
                {trip.driver.rating}
              </div>
            </div>

            <div>
              <div className="font-bold text-neutral-100 text-sm flex items-center gap-1.5">
                <span>{trip.driver.name}</span>
                <span className="text-[10px] text-neutral-400 font-normal">
                  ({trip.driver.totalTrips.toLocaleString()} rides)
                </span>
              </div>
              <div className="text-xs text-neutral-300 font-medium">{trip.driver.carModel}</div>
              <div className="text-[11px] text-neutral-400">
                <span>{trip.driver.carColor}</span> ·{' '}
                <span className="font-mono font-bold text-neutral-200 bg-neutral-800 px-1 py-0.5 rounded text-[10px]">
                  {trip.driver.licensePlate}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Action Buttons (Call, Chat, Safety) */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenChat}
              className="p-2.5 rounded-xl bg-neutral-850 hover:bg-neutral-800 border border-neutral-750 text-neutral-200 transition-colors relative"
              aria-label="Chat with driver"
              title="Chat with driver"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
            </button>

            <button
              onClick={() => {
                const phone = trip.driver.phoneNumber;
                alert(`Calling driver ${trip.driver.name} at ${phone}`);
              }}
              className="p-2.5 rounded-xl bg-neutral-850 hover:bg-neutral-800 border border-neutral-750 text-neutral-200 transition-colors"
              aria-label="Call driver"
              title="Call driver"
            >
              <Phone className="w-4 h-4 text-sky-400" />
            </button>

            <button
              onClick={onOpenSafety}
              className="p-2.5 rounded-xl bg-neutral-850 hover:bg-neutral-800 border border-neutral-750 text-neutral-200 transition-colors"
              aria-label="Safety Toolkit"
              title="Safety Shield"
            >
              <Shield className="w-4 h-4 text-emerald-400" />
            </button>

            {/* Dedicated Discreet Report Incident Button (In-Progress Protection) */}
            <button
              onClick={() => setIsReportIncidentOpen(true)}
              className="p-2.5 rounded-xl bg-amber-950/70 hover:bg-amber-900/80 border border-amber-600/60 text-amber-300 transition-colors"
              aria-label="Report Incident Discreetly"
              title="Report Incident (Discreet & Confidential)"
            >
              <Flag className="w-4 h-4 text-amber-400" />
            </button>

            {onOpenSos && (
              <button
                onClick={onOpenSos}
                className="px-2.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs transition-colors flex items-center gap-1 shadow-md shadow-rose-950/40 animate-pulse"
                aria-label="SOS Armed Response"
                title="SOS Armed Response Dispatch"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>SOS</span>
              </button>
            )}
          </div>
        </div>

        {/* Safety & Action Quick Bar (Report Incident & Share Live Trip) */}
        <div className="grid grid-cols-2 gap-2">
          {/* Dedicated 'Report Incident' Button */}
          <button
            type="button"
            onClick={() => setIsReportIncidentOpen(true)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all hover:border-amber-500 active:scale-[0.98] shadow-sm"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
            <span className="truncate">Report Incident</span>
          </button>

          {/* Share Live Trip Deep Link Button */}
          <button
            type="button"
            onClick={handleShareTrip}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-750 text-neutral-200 text-xs font-bold transition-all hover:border-neutral-600 active:scale-[0.98] shadow-sm"
          >
            {copiedShare ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span className="text-emerald-400 truncate">Link Copied!</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                <span className="truncate">Share Live Trip</span>
              </>
            )}
          </button>
        </div>

        {/* Payment mode indicator banner */}
        <div className="flex items-center justify-between p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
          <div className="flex items-center gap-1.5 text-neutral-300">
            {trip.paymentMethod.type === 'cash' ? (
              <>
                <span className="text-amber-400 font-bold">💵 Cash Payment:</span>
                <span className="text-neutral-300">Pay driver at destination</span>
              </>
            ) : (
              <>
                <span className="text-emerald-400 font-bold">💳 In-App Payment:</span>
                <span className="text-neutral-300 truncate max-w-[140px]">{trip.paymentMethod.title}</span>
              </>
            )}
          </div>
          <div className="font-extrabold text-neutral-100 font-mono">
            {formatCurrency(trip.finalFare, currencySymbol)}
          </div>
        </div>

        {/* Detailed Fare Breakdown (Base, Distance & Time) */}
        <div className="rounded-xl bg-neutral-900 border border-neutral-800 overflow-hidden text-xs">
          <button
            type="button"
            onClick={() => setShowFareBreakdown(!showFareBreakdown)}
            className="w-full px-3 py-2 flex items-center justify-between text-neutral-300 hover:text-white transition-colors text-left"
          >
            <div className="flex items-center gap-1.5">
              <Receipt className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span className="font-semibold text-[11px]">Fare Breakdown (Base, Distance & Time)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-mono font-bold text-neutral-100">{formatCurrency(trip.finalFare, currencySymbol)}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${showFareBreakdown ? 'rotate-180' : ''}`} />
            </div>
          </button>

          {showFareBreakdown && (
            <div className="px-3 pb-2.5 pt-1 border-t border-neutral-850 space-y-1 text-[11px] text-neutral-400 animate-in fade-in duration-150">
              <div className="flex justify-between items-center">
                <span>Base Fare:</span>
                <span className="font-mono text-neutral-200">{formatCurrency(baseFare, currencySymbol)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Distance Fee ({trip.distanceKm} km @ {formatCurrency(trip.category.perKmRate, currencySymbol)}/km):</span>
                <span className="font-mono text-neutral-200">{formatCurrency(distanceFee, currencySymbol)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Time Fee (~{Math.max(1, trip.etaMinutes)} mins @ {formatCurrency(trip.category.perMinuteRate, currencySymbol)}/min):</span>
                <span className="font-mono text-neutral-200">{formatCurrency(timeFee, currencySymbol)}</span>
              </div>
              {trip.discountAmount > 0 && (
                <div className="flex justify-between items-center text-emerald-400 font-medium">
                  <span>Promo Discount:</span>
                  <span className="font-mono">-{formatCurrency(trip.discountAmount, currencySymbol)}</span>
                </div>
              )}
              <div className="flex justify-between items-center pt-1 border-t border-neutral-800 text-neutral-200 font-bold">
                <span>Total Locked Upfront:</span>
                <span className="font-mono text-emerald-400">{formatCurrency(trip.finalFare, currencySymbol)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Visual Progress Bar (Pickup to Dropoff Journey Completion) */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs font-bold text-neutral-200">Journey Progress</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-neutral-400">
                {isInTrip
                  ? `${Math.min(trip.distanceKm, Number(((trip.distanceKm * journeyPercent) / 100).toFixed(1)))} / ${trip.distanceKm} km`
                  : isArrived
                  ? 'At Pickup point'
                  : 'Approaching pickup'}
              </span>
              <span
                className={`px-2 py-0.5 rounded-full text-xs font-black font-mono tracking-tight ${
                  journeyPercent === 100
                    ? 'bg-emerald-500 text-neutral-950'
                    : journeyPercent > 0
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                    : 'bg-neutral-800 text-neutral-300'
                }`}
              >
                {journeyPercent}%
              </span>
            </div>
          </div>

          {/* Progress Track & Animated Bar */}
          <div className="relative pt-0.5 pb-0.5">
            <div className="w-full bg-neutral-800 rounded-full h-2.5 overflow-hidden shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-teal-300 transition-all duration-500 ease-out rounded-full shadow-[0_0_12px_rgba(52,211,153,0.5)]"
                style={{
                  width: `${
                    trip.status === 'completed'
                      ? 100
                      : isInTrip
                      ? Math.max(3, journeyPercent)
                      : isArrived
                      ? 0
                      : 0
                  }%`,
                }}
              />
            </div>
          </div>

          {/* Pickup and Dropoff Waypoints */}
          <div className="flex items-center justify-between text-[11px] text-neutral-300">
            <div className="flex items-center gap-1.5 min-w-0 max-w-[48%]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" />
              <span className="truncate text-neutral-300 font-medium" title={trip.pickup.name}>
                {trip.pickup.name}
              </span>
            </div>
            <div className="flex items-center gap-1.5 min-w-0 max-w-[48%] justify-end text-right">
              <span className="truncate text-neutral-400 font-medium" title={trip.dropoff.name}>
                {trip.dropoff.name}
              </span>
              <span className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0" />
            </div>
          </div>
        </div>

        {/* Real-time simulation speed up toggle for testing */}
        <div className="pt-1 flex items-center justify-between text-xs border-t border-neutral-850 text-neutral-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Tracking GPS Live</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onSpeedUpSimulation}
              className="px-2 py-1 rounded bg-neutral-900 border border-neutral-750 text-[11px] font-medium text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <FastForward className="w-3 h-3" />
              <span>Speed: {simulationSpeed}x</span>
            </button>

            {!isInTrip && (
              <button
                onClick={onCancelTrip}
                className="text-neutral-500 hover:text-rose-400 text-[11px] font-medium"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        {/* Discreet In-Trip Incident Reporting Modal */}
        <ReportIncidentModal
          isOpen={isReportIncidentOpen}
          trip={trip}
          onClose={() => setIsReportIncidentOpen(false)}
          onOpenSos={onOpenSos}
        />
      </div>
    </div>
  );
};
