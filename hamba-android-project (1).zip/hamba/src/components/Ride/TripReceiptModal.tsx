import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  ArrowRight,
  Award,
  Banknote,
  CheckCircle2,
  ChevronDown,
  Clock,
  Heart,
  Lock,
  Receipt,
  ShieldCheck,
  Star,
  User,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { ActiveTrip } from '../../types';
import { formatCurrency } from '../../utils/geo';

interface TripReceiptModalProps {
  trip: ActiveTrip;
  currencySymbol: string;
  onFinish: (tip: number, driverRating: number, passengerRatingReceived: number) => void;
}

export const TripReceiptModal: React.FC<TripReceiptModalProps> = ({
  trip,
  currencySymbol,
  onFinish,
}) => {
  // Step 1: Driver rates passenger first. Step 2: Passenger rates driver.
  const [ratingStep, setRatingStep] = useState<'driver_rates_rider' | 'rider_rates_driver'>('driver_rates_rider');

  // Driver rating of passenger state
  const [driverGivenRating, setDriverGivenRating] = useState(5);
  const [driverBadges] = useState(['Polite & Respectful', 'Ready at Pickup', 'Great Communication']);
  const [driverReviewSubmitted, setDriverReviewSubmitted] = useState(true);

  // Client rating of driver state
  const [riderGivenRating, setRiderGivenRating] = useState(5);
  const [selectedTip, setSelectedTip] = useState(trip.paymentMethod.type === 'cash' ? 0 : 15);
  const [selectedCompliments, setSelectedCompliments] = useState<string[]>(['Clean car', 'Smooth driver']);
  const [isReceiptDetailsOpen, setIsReceiptDetailsOpen] = useState(false);

  const isCash = trip.paymentMethod.type === 'cash';

  useEffect(() => {
    sound.playPaymentSuccess();
  }, []);

  const complimentsList = [
    'Clean car',
    'Smooth driver',
    'Great route',
    'Friendly conversation',
    'Comfortable ride',
    'Arrived on time',
  ];

  const toggleCompliment = (comp: string) => {
    if (selectedCompliments.includes(comp)) {
      setSelectedCompliments(selectedCompliments.filter((c) => c !== comp));
    } else {
      setSelectedCompliments([...selectedCompliments, comp]);
    }
  };

  const handleDriverRatedNext = () => {
    sound.playTap();
    setRatingStep('rider_rates_driver');
    try {
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {
      // safe fallback
    }
  };

  const totalCharged = trip.finalFare + (isCash ? 0 : selectedTip);

  return (
    <div className="absolute inset-0 z-50 bg-neutral-950 flex flex-col justify-between overflow-y-auto p-4 animate-in fade-in duration-300">
      {/* ============================================================== */}
      {/* STEP 1: DRIVER RATES THE CLIENT FIRST                          */}
      {/* ============================================================== */}
      {ratingStep === 'driver_rates_rider' && (
        <div className="space-y-4 max-w-md mx-auto w-full pt-4 animate-in slide-in-from-right duration-300">
          {/* Header */}
          <div className="text-center space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-3 py-1 rounded-full">
              Step 1 of 2 · Driver Review
            </span>
            <h2 className="text-xl font-black text-neutral-100 mt-2">
              Driver is Rating You
            </h2>
            <p className="text-xs text-neutral-400 max-w-xs mx-auto">
              Per HAMBA community guidelines, the driver rates the passenger first before you submit your review.
            </p>
          </div>

          {/* Driver Terminal Screen Mockup */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-2xl">
            {/* Driver Profile Tag */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-3">
                <img
                  src={trip.driver.photo}
                  alt={trip.driver.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
                />
                <div>
                  <div className="text-xs font-bold text-neutral-100">{trip.driver.name}</div>
                  <div className="text-[11px] text-neutral-400">
                    {trip.driver.carModel} · {trip.driver.licensePlate}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800">
                  Driver Terminal
                </span>
              </div>
            </div>

            {/* Passenger Rating Assessment Card */}
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-850 space-y-3 text-center">
              <div className="text-xs font-semibold text-neutral-300">
                Evaluating Passenger: <span className="text-emerald-400 font-bold">You (Rider)</span>
              </div>

              {/* Stars given by driver */}
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className="w-8 h-8 fill-amber-400 text-amber-400 animate-in zoom-in duration-200"
                  />
                ))}
              </div>

              <div className="text-sm font-black text-neutral-100">
                5.0 Stars · Excellent Passenger!
              </div>

              {/* Driver Badges Given */}
              <div className="flex flex-wrap gap-1.5 justify-center pt-1">
                {driverBadges.map((badge) => (
                  <span
                    key={badge}
                    className="text-[10px] font-semibold text-emerald-300 bg-emerald-950/70 border border-emerald-800/60 px-2.5 py-1 rounded-full"
                  >
                    ✓ {badge}
                  </span>
                ))}
              </div>

              {/* Driver Comment Quote */}
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 italic">
                "{trip.driver.name}: Wonderful passenger! Ready at the pickup point, polite, and great trip."
              </div>
            </div>

            {/* Status confirmation */}
            <div className="flex items-center justify-between text-xs text-neutral-400 pt-1">
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <CheckCircle2 className="w-4 h-4" />
                <span>Driver rating submitted & recorded</span>
              </span>
              <span className="text-[11px] text-neutral-500">Your rating: 4.98 ★</span>
            </div>
          </div>

          {/* Proceed to Client Rating Button */}
          <button
            onClick={handleDriverRatedNext}
            className="w-full py-4 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-extrabold text-sm shadow-xl shadow-emerald-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <span>Proceed: Rate Driver {trip.driver.name}</span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      )}

      {/* ============================================================== */}
      {/* STEP 2: CLIENT RATES THE DRIVER & REVIEWS PAYMENT RECEIPT      */}
      {/* ============================================================== */}
      {ratingStep === 'rider_rates_driver' && (
        <div className="space-y-4 max-w-md mx-auto w-full pt-4 animate-in slide-in-from-right duration-300">
          {/* Header */}
          <div className="text-center space-y-1">
            <span className="text-[10px] uppercase font-bold text-sky-400 bg-sky-950/70 border border-sky-800/60 px-3 py-1 rounded-full">
              Step 2 of 2 · Rider Review
            </span>
            <h2 className="text-xl font-black text-neutral-100 mt-2">
              Rate Your Experience
            </h2>
            <p className="text-xs text-neutral-400">
              Trip completed with {trip.driver.name} at {trip.dropoff.name}
            </p>
          </div>

          {/* Payment Method Notice (Cash vs In-App Card) */}
          <div
            className={`p-4 rounded-2xl border space-y-3 shadow-lg ${
              isCash
                ? 'bg-amber-950/30 border-amber-800/60'
                : 'bg-neutral-900 border-neutral-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-bold">
                  {isCash ? '💵 Cash Paid to Driver' : '💳 Total Paid In-App'}
                </div>
                <div className="text-2xl font-black text-neutral-100 tracking-tight">
                  {formatCurrency(totalCharged, currencySymbol)}
                </div>
              </div>

              <div className="text-right">
                {isCash ? (
                  <div className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-950 border border-amber-800 px-2 py-0.5 rounded-full">
                    <Banknote className="w-3.5 h-3.5" />
                    <span>Cash Paid</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>In-App Card</span>
                  </div>
                )}
                <div className="text-[11px] text-neutral-400 mt-1">
                  {isCash ? 'Paid directly to driver' : trip.paymentMethod.title}
                </div>
              </div>
            </div>

            {/* Collapsible itemized fare breakdown */}
            <button
              onClick={() => setIsReceiptDetailsOpen(!isReceiptDetailsOpen)}
              className="w-full pt-2 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400 hover:text-neutral-200"
            >
              <span className="flex items-center gap-1.5 font-semibold text-neutral-300">
                <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                <span>View Detailed Fare Breakdown</span>
              </span>
              <ChevronDown
                className={`w-4 h-4 transition-transform duration-200 ${isReceiptDetailsOpen ? 'rotate-180' : ''}`}
              />
            </button>

            {isReceiptDetailsOpen && (
              <div className="pt-2.5 space-y-2 text-xs text-neutral-400 border-t border-neutral-800/60 animate-in fade-in duration-150">
                <div className="flex justify-between items-center">
                  <span>Base Fare:</span>
                  <span className="font-mono text-neutral-200">{formatCurrency(trip.category.baseFare, currencySymbol)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Distance Fee ({trip.distanceKm} km @ {formatCurrency(trip.category.perKmRate, currencySymbol)}/km):</span>
                  <span className="font-mono text-neutral-200">{formatCurrency(Math.round(trip.distanceKm * trip.category.perKmRate), currencySymbol)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Time Fee (~{Math.max(1, trip.etaMinutes)} mins @ {formatCurrency(trip.category.perMinuteRate, currencySymbol)}/min):</span>
                  <span className="font-mono text-neutral-200">{formatCurrency(Math.max(5, Math.round(trip.etaMinutes * trip.category.perMinuteRate)), currencySymbol)}</span>
                </div>
                {trip.discountAmount > 0 && (
                  <div className="flex justify-between items-center text-emerald-400 font-medium">
                    <span>Promotional Discount:</span>
                    <span className="font-mono">-{formatCurrency(trip.discountAmount, currencySymbol)}</span>
                  </div>
                )}
                {!isCash && selectedTip > 0 && (
                  <div className="flex justify-between items-center text-neutral-200 font-medium">
                    <span>Driver Tip (100% to Driver):</span>
                    <span className="font-mono">+{formatCurrency(selectedTip, currencySymbol)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-1.5 border-t border-neutral-800/80 text-neutral-100 font-bold">
                  <span>Total Amount Paid:</span>
                  <span className="font-mono text-emerald-400 text-sm">{formatCurrency(totalCharged, currencySymbol)}</span>
                </div>
                <div className="flex justify-between text-neutral-500 text-[11px] pt-1">
                  <span>Payment Settlement:</span>
                  <span className="font-semibold text-neutral-300">
                    {isCash ? 'Direct Cash to Driver' : 'Tokenized In-App Card'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Rate Driver Section */}
          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 text-center">
            <div className="text-xs font-semibold text-neutral-300">
              How was your trip with {trip.driver.name}?
            </div>

            <div className="flex justify-center items-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => {
                    setRiderGivenRating(star);
                    sound.playTap();
                  }}
                  className="p-1 text-amber-400 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`w-7 h-7 ${star <= riderGivenRating ? 'fill-amber-400 text-amber-400' : 'text-neutral-700'}`}
                  />
                </button>
              ))}
            </div>

            {/* Compliment badges */}
            <div className="flex flex-wrap gap-1.5 justify-center pt-1">
              {complimentsList.map((comp) => {
                const isSelected = selectedCompliments.includes(comp);
                return (
                  <button
                    key={comp}
                    onClick={() => toggleCompliment(comp)}
                    className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors ${
                      isSelected
                        ? 'bg-emerald-950/60 border-emerald-500/80 text-emerald-300'
                        : 'bg-neutral-850 border-neutral-750 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {comp}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tip Driver Section (Only if paying in-app card) */}
          {!isCash && (
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-neutral-300 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  <span>Add a tip for {trip.driver.name}</span>
                </span>
              </div>

              <div className="grid grid-cols-4 gap-2 pt-1">
                {[0, 10, 15, 30].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => {
                      setSelectedTip(amount);
                      sound.playTap();
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      selectedTip === amount
                        ? 'bg-emerald-500 text-neutral-950 border-emerald-400 shadow-md'
                        : 'bg-neutral-850 text-neutral-300 border-neutral-750 hover:bg-neutral-800'
                    }`}
                  >
                    {amount === 0 ? 'No tip' : `${currencySymbol}${amount}`}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Submit Rating & Complete CTA */}
          <div className="pt-2">
            <button
              onClick={() => onFinish(selectedTip, riderGivenRating, driverGivenRating)}
              className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-base shadow-xl shadow-emerald-500/20 active:scale-[0.98] transition-all"
            >
              Submit Rating & Return to Map
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
