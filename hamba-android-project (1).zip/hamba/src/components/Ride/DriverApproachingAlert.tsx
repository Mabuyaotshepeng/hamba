import React, { useEffect, useState } from 'react';
import {
  Bell,
  Car,
  CheckCircle2,
  Clock,
  MapPin,
  Navigation,
  Shield,
  Star,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { ActiveTrip } from '../../types';

interface DriverApproachingAlertProps {
  trip: ActiveTrip;
  onDismiss: () => void;
  onFocusMap?: () => void;
}

export const DriverApproachingAlert: React.FC<DriverApproachingAlertProps> = ({
  trip,
  onDismiss,
  onFocusMap,
}) => {
  const [progress, setProgress] = useState(100);

  // Auto-dismiss countdown bar over 8 seconds
  useEffect(() => {
    const duration = 8000;
    const intervalTime = 100;
    const step = (intervalTime / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev <= step) {
          clearInterval(timer);
          onDismiss();
          return 0;
        }
        return prev - step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [onDismiss]);

  return (
    <aside
      role="status"
      aria-live="polite"
      aria-label={`Driver ${trip.driver.name} is 1 minute away from pickup`}
      className="absolute top-14 inset-x-3 sm:inset-x-4 z-45 animate-in slide-in-from-top-4 fade-in duration-300"
    >
      <div className="bg-neutral-900/95 backdrop-blur-xl border border-emerald-500/70 rounded-2xl p-3.5 shadow-[0_15px_40px_rgba(0,0,0,0.8),0_0_25px_rgba(16,185,129,0.25)] flex flex-col gap-2.5 overflow-hidden relative">
        {/* Subtle glowing animated accent top line */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-300 to-emerald-500 animate-pulse" />

        {/* Header row: Status beacon & Dismiss */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="text-[10px] font-black tracking-wider uppercase text-emerald-400 font-mono">
              DRIVER 1 MINUTE AWAY
            </span>
            <span className="text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/80 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
              <Clock className="w-3 h-3 text-emerald-400" />
              <span>Arriving Soon</span>
            </span>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onDismiss();
            }}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            title="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Driver & Vehicle Details */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative flex-shrink-0">
              <img
                src={trip.driver.photo}
                alt={trip.driver.name}
                className="w-11 h-11 rounded-full object-cover border-2 border-emerald-400 shadow-md"
              />
              <div className="absolute -bottom-1 -right-1 bg-neutral-950 border border-neutral-700 px-1 rounded text-[9px] font-bold text-amber-400 flex items-center gap-0.5">
                <Star className="w-2.5 h-2.5 fill-current" />
                {trip.driver.rating}
              </div>
            </div>

            <div className="min-w-0">
              <div className="text-xs font-black text-neutral-100 truncate flex items-center gap-1.5">
                <span>{trip.driver.name}</span>
                <span className="text-[10px] font-normal text-neutral-400">is turning onto your street</span>
              </div>
              <div className="text-[11px] text-neutral-300 font-medium truncate">
                {trip.driver.carColor} {trip.driver.carModel}
              </div>
              <div className="flex items-center gap-1.5 text-[10px] text-neutral-400">
                <span className="font-mono font-bold text-neutral-200 bg-neutral-800 px-1.5 py-0.5 rounded">
                  {trip.driver.licensePlate}
                </span>
                <span>·</span>
                <span className="truncate">Pickup: {trip.pickup.name}</span>
              </div>
            </div>
          </div>

          {/* Safety PIN */}
          <div className="flex-shrink-0 text-center bg-neutral-950 px-2.5 py-1.5 rounded-xl border border-neutral-800">
            <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-bold">
              Safety PIN
            </div>
            <div className="text-sm font-black text-emerald-400 font-mono tracking-wider">
              {trip.safetyPin}
            </div>
          </div>
        </div>

        {/* Action Buttons & Quick Cue */}
        <div className="flex items-center justify-between gap-2 pt-1 border-t border-neutral-800/80">
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-400">
            <MapPin className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
            <span className="truncate">Please proceed to pickup point outside</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playTap();
                if (onFocusMap) onFocusMap();
                onDismiss();
              }}
              className="px-3 py-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-xs font-extrabold shadow-md active:scale-95 transition-all flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>I'm Ready</span>
            </button>
          </div>
        </div>

        {/* Auto dismiss countdown bar */}
        <div className="w-full bg-neutral-800/80 rounded-full h-1 overflow-hidden">
          <div
            className="bg-emerald-500 h-full transition-all duration-100 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </aside>
  );
};
