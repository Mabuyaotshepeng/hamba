import React from 'react';
import {
  AlertTriangle,
  Award,
  CheckCircle,
  Clock,
  Heart,
  Info,
  Medal,
  Shield,
  ShieldCheck,
  Sparkles,
  Star,
  ThumbsUp,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { DriverPerformanceData } from '../../types/driver';

interface DriverPerformanceViewProps {
  performance: DriverPerformanceData;
}

export const DriverPerformanceView: React.FC<DriverPerformanceViewProps> = ({
  performance,
}) => {
  return (
    <div className="w-full h-full overflow-y-auto bg-neutral-950 text-neutral-100 p-4 pb-20 space-y-4">
      
      {/* Driver Tier Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-neutral-900 via-neutral-900 to-indigo-950/70 border border-neutral-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Medal className="w-5 h-5 text-amber-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Driver Partner Status
            </span>
          </div>

          <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
            {performance.tier}
          </span>
        </div>

        <div>
          <h3 className="text-xl font-black text-neutral-100 tracking-tight">
            Platinum Driver Partner
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            You enjoy our lowest commission rate of only <strong>12%</strong> (saving 6% per trip).
          </p>
        </div>

        {/* Tier Benefits */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-800 text-xs">
          <div className="flex items-center gap-1.5 text-neutral-300">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Priority Airport Dispatch</span>
          </div>
          <div className="flex items-center gap-1.5 text-neutral-300">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>12% Reduced Commission</span>
          </div>
          <div className="flex items-center gap-1.5 text-neutral-300">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Free 24/7 Roadside Assist</span>
          </div>
          <div className="flex items-center gap-1.5 text-neutral-300">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Dedicated WhatsApp Support</span>
          </div>
        </div>
      </div>

      {/* Core Ratings Grid */}
      <div className="grid grid-cols-3 gap-2.5">
        {/* Rating */}
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
          <span className="text-[10px] text-neutral-400 uppercase font-bold">
            Rating
          </span>
          <div className="text-xl font-black text-amber-400 flex items-center justify-center gap-1 mt-0.5">
            <Star className="w-4 h-4 fill-amber-400" />
            <span>{performance.driverRating.toFixed(2)}</span>
          </div>
          <div className="text-[10px] text-neutral-500 mt-0.5">
            {performance.totalTrips} reviews
          </div>
        </div>

        {/* Acceptance Rate */}
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
          <span className="text-[10px] text-neutral-400 uppercase font-bold">
            Acceptance
          </span>
          <div className="text-xl font-black text-emerald-400 mt-0.5">
            {performance.acceptanceRate}%
          </div>
          <div className="text-[10px] text-emerald-500 font-semibold mt-0.5">
            Target &gt; 85%
          </div>
        </div>

        {/* Cancellation */}
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
          <span className="text-[10px] text-neutral-400 uppercase font-bold">
            Cancel Rate
          </span>
          <div className="text-xl font-black text-neutral-200 mt-0.5">
            {performance.cancellationRate}%
          </div>
          <div className="text-[10px] text-emerald-500 font-semibold mt-0.5">
            Target &lt; 4%
          </div>
        </div>
      </div>

      {/* Rider Compliments Badges */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-rose-400" />
            <span>Passenger Compliments</span>
          </h4>
          <span className="text-[11px] text-neutral-400">Total: 4,177</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {performance.compliments.map((comp, idx) => (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-neutral-850/80 border border-neutral-800 flex items-center justify-between"
            >
              <div className="min-w-0 pr-2">
                <div className="text-xs font-bold text-neutral-200 truncate">
                  {comp.label}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5">
                  Verified riders
                </div>
              </div>
              <span className="text-xs font-black text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded-lg flex-shrink-0">
                {comp.count}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Safety Compliance & Background Checks */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2.5">
        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
          <Shield className="w-4 h-4" />
          <span>Safety & Regulatory Compliance</span>
        </div>
        <p className="text-[11px] text-neutral-400">
          Your criminal background check, AFIS biometric fingerprint verification, and South African PrDP license are up to date. Next annual review due November 2027.
        </p>
      </div>

      {/* 3-Minute Cancellation & Driver Rating Policy */}
      <div className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Clock className="w-4 h-4" />
            <span>3-Minute Passenger Arrival Policy</span>
          </div>
          <span className="text-[10px] font-bold text-neutral-400 bg-neutral-800 px-2 py-0.5 rounded-full">
            Standard Rules
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <div className="p-3 rounded-2xl bg-neutral-950/80 border border-emerald-900/50 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>After 3 Minutes Wait</span>
            </div>
            <p className="text-[11px] text-neutral-400">
              If client does not arrive in 3 minutes, you can cancel as a <strong>Rider No-Show</strong>. Your rating is 100% protected and you earn a <strong>+R25 fee</strong>.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-neutral-950/80 border border-rose-900/50 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-rose-400">
              <TrendingDown className="w-4 h-4" />
              <span>Within 3 Minutes Wait</span>
            </div>
            <p className="text-[11px] text-neutral-400">
              You may cancel before 3 minutes if necessary, but you must provide a reason. Early cancellations reduce your rating by <strong>0.05</strong>.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
