import React, { useEffect, useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowRight,
  Car,
  Check,
  CheckCircle,
  ChevronRight,
  Clock,
  Compass,
  CornerUpLeft,
  CornerUpRight,
  FastForward,
  Lock,
  MessageCircle,
  Navigation,
  Phone,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  UserX,
  Volume2,
  VolumeX,
  XCircle,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { DriverActiveTrip } from '../../types/driver';
import { DriverCancelParams, DriverCancelTripModal } from './DriverCancelTripModal';

interface DriverActiveTripViewProps {
  activeTrip: DriverActiveTrip;
  onUpdatePhase: (nextPhase: DriverActiveTrip['currentPhase']) => void;
  onVerifyPin: (pin: string) => boolean;
  onCompleteTrip: () => void;
  onCancelTrip: (params: DriverCancelParams) => void;
  onOpenSos: () => void;
  onSpeedUp: () => void;
  simulationSpeed: number;
  driverRating: number;
}

export const DriverActiveTripView: React.FC<DriverActiveTripViewProps> = ({
  activeTrip,
  onUpdatePhase,
  onVerifyPin,
  onCompleteTrip,
  onCancelTrip,
  onOpenSos,
  onSpeedUp,
  simulationSpeed,
  driverRating,
}) => {
  const { request, currentPhase, pinVerified, remainingEtaMin, remainingDistanceKm, speedKmh } = activeTrip;
  
  // Waiting timer state for 'at_pickup' phase
  const [waitSeconds, setWaitSeconds] = useState(0);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [voiceNavMuted, setVoiceNavMuted] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<string[]>([
    "I'm at the designated pickup entrance.",
  ]);
  const [newMessage, setNewMessage] = useState('');

  // Waiting timer effect (accelerated by simulationSpeed)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (currentPhase === 'at_pickup') {
      interval = setInterval(() => {
        setWaitSeconds((prev) => prev + 1);
      }, 1000 / Math.max(1, simulationSpeed));
    }
    return () => clearInterval(interval);
  }, [currentPhase, simulationSpeed]);

  // Handle entering PIN
  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pinInput.trim() === request.safetyPin || pinInput.length === 4) {
      const ok = onVerifyPin(pinInput);
      if (ok) {
        sound.playPinVerified();
        setPinError(false);
      } else {
        setPinError(true);
      }
    } else {
      setPinError(true);
    }
  };

  const handleQuickVerifyPin = () => {
    setPinInput(request.safetyPin);
    onVerifyPin(request.safetyPin);
    sound.playPinVerified();
    setPinError(false);
  };

  const formatWaitTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const freeWaitLimit = 180; // 3 minutes free wait
  const isOvertime = waitSeconds > freeWaitLimit;
  const overtimeFee = isOvertime ? ((waitSeconds - freeWaitLimit) / 60) * 2.5 : 0;

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 pointer-events-auto flex flex-col justify-end p-2 sm:p-4 animate-in slide-in-from-bottom-6 duration-300">
      
      {/* Top Turn-by-Turn Navigation HUD (Floating Banner) */}
      <div className="mb-2 bg-neutral-900/95 backdrop-blur-xl border border-neutral-750 p-3.5 rounded-2xl shadow-2xl flex items-center justify-between text-neutral-100">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-emerald-500 text-neutral-950 flex items-center justify-center font-bold flex-shrink-0 shadow-md">
            {currentPhase === 'to_pickup' ? (
              <CornerUpRight className="w-6 h-6 stroke-[2.5]" />
            ) : currentPhase === 'at_pickup' ? (
              <Clock className="w-6 h-6 stroke-[2.5]" />
            ) : (
              <Navigation className="w-6 h-6 stroke-[2.5] fill-current" />
            )}
          </div>
          <div className="min-w-0">
            <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
              {currentPhase === 'to_pickup'
                ? 'Navigating to Passenger Pickup'
                : currentPhase === 'at_pickup'
                ? 'Arrived at Pickup Zone'
                : 'En Route to Passenger Destination'}
            </div>
            <div className="text-sm font-extrabold text-neutral-100 truncate">
              {currentPhase === 'to_pickup'
                ? `In 250m turn onto Rivonia Rd • ${request.pickup.name}`
                : currentPhase === 'at_pickup'
                ? `Waiting at ${request.pickup.name}`
                : `Continue on M1 Highway • Heading to ${request.dropoff.name}`}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0 ml-2">
          {/* Voice Nav Toggle */}
          <button
            onClick={() => {
              setVoiceNavMuted(!voiceNavMuted);
              sound.playTap();
            }}
            className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title={voiceNavMuted ? 'Voice Navigation Muted' : 'Voice Navigation Active'}
          >
            {voiceNavMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Speed / Sim Controls */}
          <button
            onClick={onSpeedUp}
            className="px-2 py-1 rounded-xl bg-neutral-800 border border-neutral-700 text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 hover:bg-neutral-750 transition-colors"
            title="Fast Forward Simulation"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>{simulationSpeed}x</span>
          </button>
        </div>
      </div>

      {/* Main Phase Card */}
      <div className="bg-neutral-950/95 backdrop-blur-xl border border-neutral-800 rounded-3xl p-4 shadow-2xl text-neutral-100 space-y-3.5">
        
        {/* Passenger Quick Bar & Contact Info */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={request.passengerPhoto}
              alt={request.passengerName}
              className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500/60 shadow"
            />
            <div className="min-w-0">
              <div className="text-sm font-bold text-neutral-100 truncate">
                {request.passengerName}
              </div>
              <div className="text-xs text-neutral-400 flex items-center gap-2">
                <span className="text-emerald-400 font-semibold">{request.category.name}</span>
                <span>•</span>
                <span>{request.paymentMethod === 'cash' ? 'Cash' : 'In-App Card'}</span>
              </div>
            </div>
          </div>

          {/* Actions: Call, Chat, Emergency SOS */}
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button
              onClick={() => setIsChatOpen(!isChatOpen)}
              className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700 transition-colors relative"
              title="Message Passenger"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
            </button>

            <a
              href="tel:+27825550192"
              className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700 transition-colors"
              title="Call Passenger"
            >
              <Phone className="w-4 h-4 text-sky-400" />
            </a>

            <button
              onClick={onOpenSos}
              className="p-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/40 transition-colors"
              title="Driver Armed Response SOS"
            >
              <ShieldAlert className="w-4 h-4 text-rose-400" />
            </button>

            {/* Cancel Trip Button */}
            {currentPhase !== 'in_transit' && (
              <button
                onClick={() => {
                  sound.playTap();
                  setIsCancelModalOpen(true);
                }}
                className={`p-2.5 rounded-xl border transition-colors ${
                  currentPhase === 'at_pickup' && waitSeconds >= 180
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
                    : 'bg-neutral-800 hover:bg-rose-950/40 text-neutral-300 hover:text-rose-400 border-neutral-700'
                }`}
                title={
                  currentPhase === 'at_pickup' && waitSeconds >= 180
                    ? 'Cancel Trip (Client Did Not Arrive • Protected Rating)'
                    : 'Cancel Trip (Requires Reason • Rating Drops if < 3 min)'
                }
              >
                <XCircle className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Quick In-App Passenger Chat Drawer (Collapsible) */}
        {isChatOpen && (
          <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-750 space-y-2 animate-in fade-in duration-150">
            <div className="flex items-center justify-between text-xs font-bold text-neutral-300 pb-1 border-b border-neutral-800">
              <span>Messages with {request.passengerName}</span>
              <button
                onClick={() => setIsChatOpen(false)}
                className="text-[11px] text-neutral-500 hover:text-neutral-300"
              >
                Close
              </button>
            </div>
            <div className="max-h-28 overflow-y-auto space-y-1.5 text-xs">
              {chatMessages.map((msg, i) => (
                <div key={i} className="p-2 rounded-xl bg-neutral-800/80 text-neutral-200">
                  {msg}
                </div>
              ))}
            </div>
            <div className="flex items-center gap-1.5 pt-1">
              <input
                type="text"
                placeholder="Send quick reply..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newMessage.trim()) {
                    setChatMessages([...chatMessages, `Driver: ${newMessage}`]);
                    setNewMessage('');
                    sound.playMessagePop();
                  }
                }}
                className="flex-1 bg-neutral-950 border border-neutral-750 rounded-xl px-3 py-1.5 text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={() => {
                  if (newMessage.trim()) {
                    setChatMessages([...chatMessages, `Driver: ${newMessage}`]);
                    setNewMessage('');
                    sound.playMessagePop();
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-500 text-neutral-950 text-xs font-bold"
              >
                Send
              </button>
            </div>
          </div>
        )}

        {/* ================= PHASE 1: TO PICKUP ================= */}
        {currentPhase === 'to_pickup' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs">
              <div>
                <span className="text-[10px] text-neutral-400 uppercase font-semibold">
                  Distance to Pickup
                </span>
                <div className="text-base font-extrabold text-neutral-100">
                  {remainingDistanceKm.toFixed(1)} km ({remainingEtaMin} min)
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-neutral-400 uppercase font-semibold">
                  Speed
                </span>
                <div className="text-base font-extrabold text-emerald-400 font-mono">
                  {speedKmh} km/h
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playDriverArrived();
                onUpdatePhase('at_pickup');
              }}
              className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-black text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5 fill-neutral-950 text-emerald-500" />
              <span>I HAVE ARRIVED AT PICKUP</span>
            </button>

            {/* Cancel early while navigating to pickup */}
            <button
              type="button"
              onClick={() => {
                sound.playTap();
                setIsCancelModalOpen(true);
              }}
              className="w-full py-2.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-850 text-neutral-400 hover:text-rose-400 border border-neutral-800 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
            >
              <XCircle className="w-3.5 h-3.5 text-rose-500" />
              <span>Cancel Request (Reason Required • Rating Penalty Applies)</span>
            </button>
          </div>
        )}

        {/* ================= PHASE 2: AT PICKUP & PIN VERIFICATION ================= */}
        {currentPhase === 'at_pickup' && (
          <div className="space-y-3">
            {/* Waiting Timer & Overtime banner */}
            <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-neutral-400">
                    Waiting Time
                  </div>
                  <div className="text-sm font-extrabold font-mono text-neutral-100">
                    {formatWaitTime(waitSeconds)}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-neutral-400">
                  {isOvertime ? 'Wait Fee Added' : 'Free Wait Window'}
                </div>
                <div className={`text-xs font-bold ${isOvertime ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {isOvertime ? `+R${overtimeFee.toFixed(2)}` : `${Math.max(0, Math.ceil((freeWaitLimit - waitSeconds) / 60))}m left`}
                </div>
              </div>
            </div>

            {/* 3-Minute Rule Banner / Simulation Controls */}
            {waitSeconds >= freeWaitLimit ? (
              <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/60 flex items-center justify-between gap-2.5 animate-in fade-in">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex-shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-black text-emerald-300">
                      Client No-Show • Over 3 Min Wait
                    </div>
                    <div className="text-[10px] text-emerald-400/90 truncate">
                      Cancel without rating penalty • +R25 fee earned
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    setIsCancelModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-xs font-black shadow-md flex-shrink-0 active:scale-95 transition-all"
                >
                  Cancel Trip
                </button>
              </div>
            ) : (
              <div className="p-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-2 text-[11px]">
                <div className="text-neutral-400 flex items-center gap-1.5 min-w-0">
                  <Clock className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                  <span className="truncate">
                    Wait {Math.max(0, freeWaitLimit - waitSeconds)}s to avoid rating penalty
                  </span>
                </div>

                {/* Fast forward wait chips */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      setWaitSeconds((prev) => prev + 60);
                    }}
                    className="px-2 py-0.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-amber-300 font-bold text-[10px] transition-colors"
                    title="Advance wait timer by 60 seconds"
                  >
                    +60s
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      sound.playTap();
                      setWaitSeconds(180);
                    }}
                    className="px-2 py-0.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/60 text-emerald-300 font-bold text-[10px] transition-colors"
                    title="Skip to 3 minutes (180s)"
                  >
                    Skip 3m
                  </button>
                </div>
              </div>
            )}

            {/* Safety PIN Verification Box */}
            <div className="p-3.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-200">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Passenger 4-Digit Safety PIN</span>
                </div>
                {pinVerified ? (
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    PIN Verified
                  </span>
                ) : (
                  <button
                    onClick={handleQuickVerifyPin}
                    className="text-[10px] font-bold text-emerald-400 underline hover:text-emerald-300"
                  >
                    Quick Verify ({request.safetyPin})
                  </button>
                )}
              </div>

              {!pinVerified ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="Ask rider for PIN..."
                    value={pinInput}
                    onChange={(e) => {
                      setPinInput(e.target.value);
                      if (e.target.value.length === 4) {
                        onVerifyPin(e.target.value);
                      }
                    }}
                    className={`flex-1 bg-neutral-950 border px-3 py-2.5 rounded-xl text-center font-mono text-base font-extrabold tracking-widest text-neutral-100 focus:outline-none ${
                      pinError ? 'border-rose-500' : 'border-neutral-750 focus:border-emerald-500'
                    }`}
                  />
                  <button
                    onClick={handlePinSubmit}
                    className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs"
                  >
                    Verify
                  </button>
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Passenger identity verified. You are ready to start.</span>
                </div>
              )}
            </div>

            {/* Start Trip Button */}
            <button
              disabled={!pinVerified}
              onClick={() => {
                sound.playTap();
                onUpdatePhase('in_transit');
              }}
              className={`w-full py-4 rounded-2xl font-black text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2 ${
                pinVerified
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-emerald-950/50 cursor-pointer active:scale-98'
                  : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-750'
              }`}
            >
              <Navigation className="w-5 h-5 fill-current" />
              <span>START TRIP TO DESTINATION</span>
            </button>

            {/* Secondary Cancel Trip button */}
            <button
              type="button"
              onClick={() => {
                sound.playTap();
                setIsCancelModalOpen(true);
              }}
              className={`w-full py-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                waitSeconds >= freeWaitLimit
                  ? 'bg-emerald-950/40 border-emerald-700/80 text-emerald-300 hover:bg-emerald-900/50'
                  : 'bg-neutral-900/80 hover:bg-neutral-850 border-neutral-800 text-neutral-400 hover:text-rose-400'
              }`}
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>
                {waitSeconds >= freeWaitLimit
                  ? 'Cancel Trip (Client Did Not Arrive • Protected Rating)'
                  : 'Cancel Trip (Reason Required • Rating Will Drop Before 3 Min)'}
              </span>
            </button>
          </div>
        )}

        {/* ================= PHASE 3: IN PROGRESS / IN TRANSIT ================= */}
        {currentPhase === 'in_transit' && (
          <div className="space-y-3">
            {/* Live Progress Metrics */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
                <span className="text-[10px] text-neutral-400 uppercase font-semibold">
                  Remaining
                </span>
                <div className="text-sm font-extrabold text-neutral-100 mt-0.5">
                  {remainingDistanceKm.toFixed(1)} km
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
                <span className="text-[10px] text-neutral-400 uppercase font-semibold">
                  ETA
                </span>
                <div className="text-sm font-extrabold text-emerald-400 mt-0.5">
                  {remainingEtaMin} min
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-center">
                <span className="text-[10px] text-neutral-400 uppercase font-semibold">
                  Speed
                </span>
                <div className="text-sm font-extrabold text-neutral-100 font-mono mt-0.5">
                  {speedKmh} km/h
                </div>
              </div>
            </div>

            {/* Dropoff Destination Banner */}
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
              <div className="min-w-0">
                <div className="text-[10px] uppercase font-bold text-rose-400">
                  Dropoff Location
                </div>
                <div className="text-xs font-bold text-neutral-100 truncate mt-0.5">
                  {request.dropoff.name}
                </div>
                <div className="text-[11px] text-neutral-400 truncate">
                  {request.dropoff.address}
                </div>
              </div>

              <div className="text-right flex-shrink-0 ml-2">
                <span className="text-xs font-black text-emerald-400">
                  R{request.estimatedNetEarnings.toFixed(2)}
                </span>
                <div className="text-[10px] text-neutral-400">Payout</div>
              </div>
            </div>

            {/* Complete Trip Action Button */}
            <button
              onClick={() => {
                sound.playTap();
                onCompleteTrip();
              }}
              className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-black text-sm tracking-wide transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>COMPLETE TRIP & COLLECT FARE</span>
            </button>
          </div>
        )}

      </div>

      {/* Driver Cancel Trip Modal */}
      <DriverCancelTripModal
        isOpen={isCancelModalOpen}
        onClose={() => setIsCancelModalOpen(false)}
        onConfirmCancel={(params) => {
          setIsCancelModalOpen(false);
          onCancelTrip(params);
        }}
        waitSeconds={waitSeconds}
        currentPhase={currentPhase}
        currentRating={driverRating}
        passengerName={request.passengerName}
        onFastForwardWait={(targetSecs) => setWaitSeconds(targetSecs)}
      />
    </div>
  );
};
