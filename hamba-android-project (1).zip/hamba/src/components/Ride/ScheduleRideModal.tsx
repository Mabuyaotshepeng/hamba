import React, { useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  Check,
  ChevronRight,
  Clock,
  Info,
  MapPin,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { LocationPoint, PaymentMethod, RideCategory, ScheduledRideRecord } from '../../types';
import { formatCurrency, getDistanceKm } from '../../utils/geo';

interface ScheduleRideModalProps {
  isOpen: boolean;
  onClose: () => void;
  pickup: LocationPoint;
  dropoff: LocationPoint | null;
  onSelectDropoff: () => void;
  categories: RideCategory[];
  selectedCategory: RideCategory;
  onSelectCategory: (cat: RideCategory) => void;
  selectedPayment: PaymentMethod;
  onScheduleConfirmed: (scheduledRide: ScheduledRideRecord) => void;
  currencySymbol: string;
}

export const ScheduleRideModal: React.FC<ScheduleRideModalProps> = ({
  isOpen,
  onClose,
  pickup,
  dropoff,
  onSelectDropoff,
  categories,
  selectedCategory,
  onSelectCategory,
  selectedPayment,
  onScheduleConfirmed,
  currencySymbol,
}) => {
  // Preset dates
  const today = new Date();
  const dateOptions = [
    { label: 'Today', value: 'Today, 11 Oct' },
    { label: 'Tomorrow', value: 'Tomorrow, 12 Oct' },
    { label: 'Mon, 13 Oct', value: 'Mon, 13 Oct' },
    { label: 'Tue, 14 Oct', value: 'Tue, 14 Oct' },
    { label: 'Wed, 15 Oct', value: 'Wed, 15 Oct' },
    { label: 'Thu, 16 Oct', value: 'Thu, 16 Oct' },
  ];

  const timeOptions = [
    '06:00 AM',
    '07:15 AM',
    '08:30 AM',
    '09:45 AM',
    '11:00 AM',
    '12:30 PM',
    '14:00 PM',
    '15:30 PM',
    '17:00 PM',
    '18:30 PM',
    '20:00 PM',
    '21:30 PM',
  ];

  const [selectedDate, setSelectedDate] = useState(dateOptions[1].value);
  const [selectedTime, setSelectedTime] = useState('08:30 AM');
  const [isCustomTime, setIsCustomTime] = useState(false);
  const [customTimeInput, setCustomTimeInput] = useState('08:30');

  if (!isOpen) return null;

  // Calculate fare
  const distanceKm = dropoff
    ? Math.max(1.5, getDistanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng))
    : 8.5;
  const estimatedDuration = Math.round((distanceKm / 32) * 60) + 3;
  const estimatedFare = Math.round(
    selectedCategory.baseFare +
      distanceKm * selectedCategory.perKmRate +
      estimatedDuration * selectedCategory.perMinuteRate
  );

  const handleConfirm = () => {
    if (!dropoff) {
      alert('Please select a destination first.');
      onSelectDropoff();
      return;
    }

    sound.playPaymentSuccess();
    const newScheduledRide: ScheduledRideRecord = {
      id: `sch-${Math.floor(100000 + Math.random() * 900000)}`,
      scheduledDate: selectedDate,
      scheduledTime: isCustomTime ? `${customTimeInput} hrs` : selectedTime,
      pickup,
      dropoff,
      category: selectedCategory,
      estimatedFare,
      paymentMethod: selectedPayment,
      status: 'scheduled',
      createdAt: Date.now(),
    };

    onScheduleConfirmed(newScheduledRide);
  };

  return (
    <div className="absolute inset-0 z-50 bg-neutral-950 flex flex-col animate-in slide-in-from-bottom duration-300">
      {/* Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-900/95 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onClose}
            className="p-1.5 -ml-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-sm font-extrabold text-neutral-100 flex items-center gap-1.5">
              <span>Schedule a Ride</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/70 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                Reserve
              </span>
            </h2>
            <p className="text-[10px] text-neutral-400">Lock in your ride up to 30 days in advance</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-full text-neutral-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Pickup & Dropoff Route Card */}
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] uppercase font-bold text-neutral-500">Pickup Location</div>
              <div className="text-xs font-semibold text-neutral-200 truncate">{pickup.name}</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 pt-1 border-t border-neutral-850">
            <div className="w-2.5 h-2.5 rounded-xs bg-rose-500 flex-shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] uppercase font-bold text-neutral-500">Destination</div>
              <div className="text-xs font-semibold text-neutral-200 truncate">
                {dropoff ? dropoff.name : 'Tap to select destination...'}
              </div>
            </div>
            {!dropoff && (
              <button
                onClick={onSelectDropoff}
                className="text-xs font-bold text-emerald-400 hover:underline px-2 py-1 rounded bg-emerald-950/40 border border-emerald-800/40"
              >
                Set
              </button>
            )}
          </div>
        </div>

        {/* Date Selection */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-400 px-1">
            <Calendar className="w-3.5 h-3.5 text-emerald-400" />
            <span>Select Pickup Date</span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {dateOptions.map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  setSelectedDate(opt.value);
                  sound.playTap();
                }}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  selectedDate === opt.value
                    ? 'bg-neutral-850 border-emerald-500 text-emerald-300 font-bold shadow-sm ring-1 ring-emerald-500/30'
                    : 'bg-neutral-900/80 border-neutral-800 text-neutral-300 hover:border-neutral-700 text-xs font-medium'
                }`}
              >
                <div className="text-xs">{opt.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Time Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-400">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Select Pickup Time</span>
            </div>
            <button
              onClick={() => setIsCustomTime(!isCustomTime)}
              className="text-[11px] text-emerald-400 hover:underline font-semibold"
            >
              {isCustomTime ? 'Preset Times' : 'Custom Time'}
            </button>
          </div>

          {isCustomTime ? (
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center gap-3">
              <input
                type="time"
                value={customTimeInput}
                onChange={(e) => setCustomTimeInput(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-750 rounded-xl px-4 py-2.5 text-base font-mono text-emerald-400 font-bold focus:outline-none focus:border-emerald-500 text-center"
              />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1 bg-neutral-950/60 rounded-2xl border border-neutral-850">
              {timeOptions.map((time) => (
                <button
                  key={time}
                  onClick={() => {
                    setSelectedTime(time);
                    sound.playTap();
                  }}
                  className={`py-2 px-1 rounded-xl text-xs font-mono font-medium transition-colors ${
                    selectedTime === time
                      ? 'bg-emerald-500 text-neutral-950 font-bold shadow-md'
                      : 'bg-neutral-900 text-neutral-300 hover:bg-neutral-800 border border-neutral-800'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Vehicle Selection for Schedule */}
        <div className="space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 px-1">
            Choose Category
          </div>

          <div className="space-y-2">
            {categories.slice(0, 3).map((cat) => {
              const isSelected = selectedCategory.id === cat.id;
              const catFare = Math.round(
                cat.baseFare +
                  distanceKm * cat.perKmRate +
                  estimatedDuration * cat.perMinuteRate
              );

              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat);
                    sound.playTap();
                  }}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-neutral-900 border-emerald-500 shadow-sm ring-1 ring-emerald-500/40'
                      : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center text-emerald-400 font-bold text-xs">
                      {cat.name.slice(6, 8) || 'GO'}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-neutral-100 flex items-center gap-1.5">
                        <span>{cat.name}</span>
                        <span className="text-[10px] text-neutral-400 flex items-center gap-0.5">
                          <Users className="w-2.5 h-2.5" /> {cat.capacity}
                        </span>
                      </div>
                      <div className="text-[10px] text-neutral-400">{cat.subtitle}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-bold text-neutral-100">
                      {formatCurrency(catFare, currencySymbol)}
                    </div>
                    <div className="text-[10px] text-emerald-400">Locked Price</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Guarantee Banner */}
        <div className="p-3 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-1.5 text-[11px] text-neutral-400">
          <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Hamba Reserve Guarantee</span>
          </div>
          <ul className="space-y-1 text-neutral-400 pl-5 list-disc">
            <li>Driver assigned and en route 10 minutes prior to scheduled time.</li>
            <li>Cancel for free up to 60 minutes before pickup.</li>
            <li>No surge pricing adjustments—locked upfront rate.</li>
          </ul>
        </div>
      </div>

      {/* Bottom Action Footer */}
      <div className="p-4 border-t border-neutral-800 bg-neutral-900 space-y-2">
        <div className="flex items-center justify-between text-xs text-neutral-400">
          <span>Scheduled Pickup:</span>
          <span className="font-bold text-neutral-100">
            {selectedDate} at {isCustomTime ? customTimeInput : selectedTime}
          </span>
        </div>

        <button
          onClick={handleConfirm}
          className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-sm shadow-xl shadow-emerald-500/20 active:scale-[0.98] transition-all flex items-center justify-between"
        >
          <span>Schedule {selectedCategory.name}</span>
          <span className="font-black font-mono">
            {formatCurrency(estimatedFare, currencySymbol)}
          </span>
        </button>
      </div>
    </div>
  );
};
