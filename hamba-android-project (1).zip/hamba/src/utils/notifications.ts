// Web Push & Browser Notifications utility for HAMBA e-hailing
export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }

  if (Notification.permission === 'granted') {
    return 'granted';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return Notification.permission;
  }
}

export function sendBrowserPushNotification(options: {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
}) {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    try {
      const notif = new Notification(options.title, {
        body: options.body,
        icon: options.icon || '/vite.svg',
        tag: options.tag || 'hamba-notification',
      });

      // Auto close after 7 seconds
      setTimeout(() => {
        try {
          notif.close();
        } catch {
          // safe
        }
      }, 7000);

      return true;
    } catch (e) {
      console.warn('Browser notification error:', e);
      return false;
    }
  }

  return false;
}
