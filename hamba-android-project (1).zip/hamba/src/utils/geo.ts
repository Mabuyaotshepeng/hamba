import { LocationPoint } from '../types';

// Haversine formula to compute distance in km
export function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

function rad2deg(rad: number): number {
  return rad * (180 / Math.PI);
}

// Calculate compass heading in degrees from point A to point B
export function getHeading(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const phi1 = deg2rad(lat1);
  const phi2 = deg2rad(lat2);
  const deltaLambda = deg2rad(lon2 - lon1);

  const y = Math.sin(deltaLambda) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(deltaLambda);
  const theta = Math.atan2(y, x);
  const bearing = (rad2deg(theta) + 360) % 360;
  return Math.round(bearing);
}

// Generate realistic polyline route with urban grid bends between two points
export function generateRoutePoints(
  start: [number, number],
  end: [number, number],
  numSteps: number = 24
): [number, number][] {
  const points: [number, number][] = [];
  const [lat1, lng1] = start;
  const [lat2, lng2] = end;

  // Midpoints with realistic city-grid deviations
  const midLat = (lat1 + lat2) / 2;
  const midLng = (lng1 + lng2) / 2;
  const devLat = (lng2 - lng1) * 0.15;
  const devLng = -(lat2 - lat1) * 0.15;

  const control1: [number, number] = [
    lat1 + (midLat - lat1) * 0.5 + devLat,
    lng1 + (midLng - lng1) * 0.5 + devLng,
  ];

  const control2: [number, number] = [
    midLat + (lat2 - midLat) * 0.5 - devLat * 0.6,
    midLng + (lng2 - midLng) * 0.5 - devLng * 0.6,
  ];

  for (let i = 0; i <= numSteps; i++) {
    const t = i / numSteps;
    // Cubic bezier interpolation for smooth realistic road curves
    const t1 = 1 - t;
    const lat =
      t1 * t1 * t1 * lat1 +
      3 * t1 * t1 * t * control1[0] +
      3 * t1 * t * t * control2[0] +
      t * t * t * lat2;
    const lng =
      t1 * t1 * t1 * lng1 +
      3 * t1 * t1 * t * control1[1] +
      3 * t1 * t * t * control2[1] +
      t * t * t * lng2;

    points.push([lat, lng]);
  }

  return points;
}

// Format currency
export function formatCurrency(amount: number, symbol: string = 'R'): string {
  return `${symbol} ${Math.max(0, amount).toFixed(2)}`;
}

// Estimate travel duration in minutes based on distance
export function estimateDurationMinutes(distanceKm: number): number {
  // Average city traffic speed ~ 32 km/h + 2 min pickup buffer
  const minutes = Math.round((distanceKm / 32) * 60) + 2;
  return Math.max(3, minutes);
}
