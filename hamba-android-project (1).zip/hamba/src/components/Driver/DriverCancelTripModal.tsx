import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowRight,
  CheckCircle,
  Clock,
  FastForward,
  Info,
  Shield,
  ShieldCheck,
  Star,
  TrendingDown,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';

export interface DriverCancelParams {
  reason: string;
  waitSeconds: number;
  isEarlyCancellation: boolean;
  notes?: string;
  ratingPenalty: number;
}

interface DriverCancelTripModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmCancel: (params: DriverCancelParams) => void;
  waitSeconds: number;
  currentPhase: 'to_pickup' | 'at_pickup' | 'in_transit' | 'dropped_off';
  currentRating: number;
  passengerName: string;
  onFastForwardWait?: (targetSeconds: number) => void;
}

const EARLY_REASONS = [
  { id: 'rider_requested', label: 'Client requested cancellation via call/chat', category: 'rider' },
  { id: 'vehicle_trouble', label: 'Vehicle trouble / flat tire or mechanical issue', category: 'driver' },
  { id: 'safety_concern', label: 'Unsafe pickup area / security concern', category: 'safety' },
  { id: 'heavy_traffic', label: 'Severe road obstruction / unreachable pickup pin', category: 'road' },
  { id: 'excess_luggage', label: 'Passenger has excess luggage or extra riders', category: 'rider' },
  { id: 'rider_unreachable', label: 'Client phone unreachable / unresponsive', category: 'rider' },
  { id: 'personal_emergency', label: 'Driver personal emergency', category: 'driver' },
  { id: 'other', label: 'Other specific reason', category: 'other' },
];

const NO_SHOW_REASONS = [
  { id: 'client_no_show', label: 'Client did not arrive within 3-minute waiting window', default: true },
  { id: 'client_unresponsive_pickup', label: 'Waited at pickup pin, client unreachable after 3 mins' },
  { id: 'client_wrong_address', label: 'Client at different location and did not show up' },
];

export const DriverCancelTripModal: React.FC<DriverCancelTripModalProps> = ({
  isOpen,
  onClose,
  onConfirmCancel,
  waitSeconds,
  currentPhase,
  currentRating,
  passengerName,
  onFastForwardWait,
}) => {
  if (!isOpen) return null;

  const freeWaitLimit = 180; // 3 minutes = 180 seconds
  const isAtPickup = currentPhase === 'at_pickup';
  // If driver has reached pickup and waited >= 180s, client did not arrive -> no penalty!
  const isNoShowEligible = isAtPickup && waitSeconds >= freeWaitLimit;
  const isEarlyCancellation = !isNoShowEligible;

  const [selectedReason, setSelectedReason] = useState<string>(
    isNoShowEligible ? NO_SHOW_REASONS[0].label : ''
  );
  const [customNotes, setCustomNotes] = useState<string>('');

  const formatWaitTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const remainingToThreeMins = Math.max(0, freeWaitLimit - waitSeconds);

  const handleSelectReason = (reason: string) => {
    sound.playTap();
    setSelectedReason(reason);
  };

  const handleSubmit = () => {
    if (!selectedReason) return;

    if (isEarlyCancellation) {
      sound.playCancelPenalty();
    } else {
      sound.playTripCancelled();
    }

    onConfirmCancel({
      reason: selectedReason,
      waitSeconds,
      isEarlyCancellation,
      notes: customNotes.trim() || undefined,
      ratingPenalty: isEarlyCancellation ? 0.05 : 0,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-750 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100 max-h-[92vh]">
        
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between ${
          isNoShowEligible 
            ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-200' 
            : 'bg-rose-950/60 border-rose-800/60 text-rose-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl flex-shrink-0 ${
              isNoShowEligible ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}>
              {isNoShowEligible ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-400" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-black text-neutral-100 uppercase tracking-wider">
                {isNoShowEligible ? 'Client No-Show Cancellation' : 'Cancel Trip Request'}
              </h3>
              <p className="text-[11px] opacity-80">
                Passenger: <strong className="text-white">{passengerName}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="p-1.5 rounded-xl hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 overflow-y-auto space-y-3.5 text-xs">
          
          {/* Waiting Time Status Indicator */}
          <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Clock className={`w-4 h-4 ${isNoShowEligible ? 'text-emerald-400' : 'text-amber-400'}`} />
              <div>
                <span className="text-[10px] text-neutral-400 uppercase font-bold">
                  {isAtPickup ? 'Waiting Time at Pickup' : 'Trip Navigation Status'}
                </span>
                <div className="text-sm font-extrabold font-mono text-neutral-100">
                  {isAtPickup ? formatWaitTime(waitSeconds) : 'En route to pickup'}
                  <span className="text-xs font-normal text-neutral-500 ml-1.5 font-sans">
                    (3 min standard requirement)
                  </span>
                </div>
              </div>
            </div>

            {/* Fast-forward simulator tool for easy testing */}
            {onFastForwardWait && isAtPickup && !isNoShowEligible && (
              <button
                onClick={() => {
                  sound.playTap();
                  onFastForwardWait(180);
                  setSelectedReason(NO_SHOW_REASONS[0].label);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-[10px] font-bold flex items-center gap-1 transition-all"
                title="Simulate 3 minutes elapsed"
              >
                <FastForward className="w-3 h-3" />
                <span>Simulate 3m wait</span>
              </button>
            )}
          </div>

          {/* CASE 1: EARLY CANCELLATION (< 3 MINUTES) -> RATING PENALTY WARNING */}
          {isEarlyCancellation ? (
            <div className="space-y-3 animate-in fade-in">
              <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-800/70 space-y-2">
                <div className="flex items-center gap-2 text-rose-300 font-extrabold text-xs">
                  <TrendingDown className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>Rating Impact Warning: Within 3 Minutes Window</span>
                </div>
                <p className="text-[11px] text-rose-200/90 leading-relaxed">
                  You have only waited <strong className="text-white">{formatWaitTime(waitSeconds)}</strong>. 
                  Cancelling before the mandatory <strong>3-minute client arrival window</strong> ({Math.ceil(remainingToThreeMins / 60)}m {remainingToThreeMins % 60}s remaining) 
                  will negatively impact your driver rating.
                </p>

                {/* Rating Drop Visualizer */}
                <div className="pt-2 border-t border-rose-900/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-rose-300/80">Current Rating:</span>
                    <span className="font-extrabold text-amber-400 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-amber-400" />
                      {currentRating.toFixed(2)}
                    </span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-rose-400" />
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-rose-300/80">Projected Rating:</span>
                    <span className="font-extrabold text-rose-400 flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-rose-400" />
                      {Math.max(4.0, currentRating - 0.05).toFixed(2)}
                      <span className="text-[10px] text-rose-500">(-0.05)</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Mandatory Reason Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-200">
                  Select Mandatory Cancellation Reason <span className="text-rose-400">*</span>
                </label>
                <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                  {EARLY_REASONS.map((r) => {
                    const isSelected = selectedReason === r.label;
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => handleSelectReason(r.label)}
                        className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-rose-950/60 border-rose-500 text-rose-100 font-bold shadow-md'
                            : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                        }`}
                      >
                        <span className="truncate pr-2">{r.label}</span>
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${
                          isSelected ? 'border-rose-400 bg-rose-500 text-neutral-950' : 'border-neutral-600'
                        }`}>
                          {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* CASE 2: CLIENT DID NOT ARRIVE IN 3 MINUTES -> RATING PROTECTED + NO-SHOW FEE */
            <div className="space-y-3 animate-in fade-in">
              <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-700/70 space-y-2.5">
                <div className="flex items-center gap-2 text-emerald-300 font-extrabold text-xs">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>3-Minute Waiting Limit Reached • Rating Protected</span>
                </div>
                <p className="text-[11px] text-emerald-200/90 leading-relaxed">
                  The client did not arrive within 3 minutes ({formatWaitTime(waitSeconds)} elapsed). 
                  Because you completed the full arrival window, you are entitled to cancel with zero rating penalty.
                </p>

                <div className="pt-2 border-t border-emerald-800/60 grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-neutral-900/80 border border-emerald-800/40 text-center">
                    <span className="text-[10px] text-neutral-400 uppercase font-bold">Driver Rating</span>
                    <div className="text-sm font-extrabold text-emerald-400 flex items-center justify-center gap-1 mt-0.5">
                      <Shield className="w-3.5 h-3.5" />
                      <span>Protected (No Drop)</span>
                    </div>
                  </div>
                  <div className="p-2 rounded-xl bg-neutral-900/80 border border-emerald-800/40 text-center">
                    <span className="text-[10px] text-neutral-400 uppercase font-bold">No-Show Fee</span>
                    <div className="text-sm font-extrabold text-emerald-400 font-mono mt-0.5">
                      +R25.00 Payout
                    </div>
                  </div>
                </div>
              </div>

              {/* No-show reasons */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-200">
                  Confirm Cancellation Reason
                </label>
                <div className="space-y-1.5">
                  {NO_SHOW_REASONS.map((r) => {
                    const isSelected = selectedReason === r.label;
                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => handleSelectReason(r.label)}
                        className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-emerald-950/60 border-emerald-500 text-emerald-100 font-bold shadow-md'
                            : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                        }`}
                      >
                        <span className="truncate pr-2">{r.label}</span>
                        <div className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${
                          isSelected ? 'border-emerald-400 bg-emerald-500 text-neutral-950' : 'border-neutral-600'
                        }`}>
                          {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Optional Notes */}
          <div className="space-y-1.5 pt-1">
            <label className="block text-[11px] font-semibold text-neutral-400">
              Additional Details / Dispatch Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Called passenger twice, no answer..."
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-600 rounded-xl px-3 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none"
            />
          </div>

        </div>

        {/* Action Buttons */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/70 flex flex-col gap-2">
          {/* Submit cancellation */}
          <button
            type="button"
            disabled={!selectedReason}
            onClick={handleSubmit}
            className={`w-full py-3.5 rounded-2xl font-black text-xs tracking-wider transition-all flex items-center justify-center gap-2 ${
              !selectedReason
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-750'
                : isNoShowEligible
                ? 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-lg shadow-emerald-950/50 active:scale-98 cursor-pointer'
                : 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/50 active:scale-98 cursor-pointer'
            }`}
          >
            {isNoShowEligible ? (
              <>
                <CheckCircle className="w-4 h-4 stroke-[2.5]" />
                <span>CONFIRM CLIENT NO-SHOW (+R25 FEE • RATING SAFE)</span>
              </>
            ) : (
              <>
                <AlertOctagon className="w-4 h-4 stroke-[2.5]" />
                <span>CONFIRM EARLY CANCELLATION (RATING WILL DROP)</span>
              </>
            )}
          </button>

          {/* Keep waiting button (especially if before 3 mins) */}
          <button
            type="button"
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-neutral-850 hover:bg-neutral-800 text-neutral-300 font-bold text-xs transition-colors"
          >
            {isEarlyCancellation ? 'Keep Waiting for Client (Avoid Rating Drop)' : 'Dismiss & Return to Trip'}
          </button>
        </div>

      </div>
    </div>
  );
};
