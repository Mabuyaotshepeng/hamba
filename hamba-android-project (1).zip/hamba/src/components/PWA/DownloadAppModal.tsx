import React, { useState } from 'react';
import {
  AlertCircle,
  Apple,
  ArrowDownToLine,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  Info,
  Laptop,
  QrCode,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface DownloadAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadAppModal: React.FC<DownloadAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'package' | 'ios'>('android');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://hamba.app';

  const handleCopyUrl = () => {
    sound.playTap();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl).then(() => {
        setCopiedUrl(true);
        setTimeout(() => setCopiedUrl(false), 2500);
      });
    }
  };

  const handleNativeInstall = async () => {
    sound.playTap();
    setIsInstalling(true);
    try {
      const outcome = await install();
      if (outcome) {
        onClose();
      }
    } finally {
      setIsInstalling(false);
    }
  };

  // Generate downloadable Android TWA & WebAPK packaging files
  const handleDownloadPackage = () => {
    sound.playTap();
    const configData = {
      appName: 'HAMBA - E-Hailing & Driver Partner',
      shortName: 'HAMBA',
      version: '1.0.0',
      versionCode: 1,
      packageId: 'com.hamba.rideshare',
      webUrl: currentUrl,
      themeColor: '#0a0a0a',
      backgroundColor: '#0a0a0a',
      displayMode: 'standalone',
      features: [
        'Real-time GPS ride tracking',
        'Offline trip caching & Service Worker',
        'Biometric Driver verification & Instant Cash Out',
        'Client Loyalty Free Rides (10 rides = R50 Free Ride)',
        'SOS Armed response & SAPS 10111 integration',
      ],
      quickBuildInstructions: [
        'Method 1 (Instant APK via PWABuilder - Zero Setup):',
        `1. Visit https://www.pwabuilder.com and paste your app URL: ${currentUrl}`,
        '2. Click "Package for Android" -> Click "Download APK".',
        '',
        'Method 2 (Google Bubblewrap CLI):',
        '1. npm install -g @bubblewrap/cli',
        `2. bubblewrap init --manifest=${currentUrl}/manifest.webmanifest`,
        '3. bubblewrap build',
        'This produces a signed, release-ready .apk file for direct installation.',
      ],
    };

    const blob = new Blob([JSON.stringify(configData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hamba-android-apk-config.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-750 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 pb-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/10 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <ArrowDownToLine className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-tight">Download & Install HAMBA</h2>
                <span className="px-1.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-[10px] font-bold text-emerald-400">
                  Android APK & PWA
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Install as a standalone native app on Android, iOS, or Desktop
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-neutral-800 bg-neutral-900/60 px-5 pt-2">
          <button
            onClick={() => setActiveTab('android')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'android'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android Install (WebAPK)</span>
          </button>

          <button
            onClick={() => setActiveTab('package')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'package'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>APK Package & Tools</span>
          </button>

          <button
            onClick={() => setActiveTab('ios')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'ios'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>iPhone / iPad</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* TAB 1: Android WebAPK Direct Install */}
          {activeTab === 'android' && (
            <div className="space-y-4">
              {/* Feature highlight card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-neutral-850 to-neutral-900 border border-emerald-500/40 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800/80">
                      Native Android Integration
                    </span>
                    <h3 className="text-base font-black text-white mt-1.5">
                      Install HAMBA Directly on Android
                    </h3>
                    <p className="text-xs text-neutral-300 mt-0.5">
                      On Android, installing creates an official <strong className="text-emerald-300">WebAPK</strong> registered with Android OS, with full splash screen, app icon, and standalone offline execution.
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 flex-shrink-0">
                    <Smartphone className="w-6 h-6" />
                  </div>
                </div>

                {isInstalled ? (
                  <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-600/60 flex items-center gap-2 text-emerald-300 text-xs font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>HAMBA is already installed and running in standalone app mode!</span>
                  </div>
                ) : isInstallable ? (
                  <button
                    onClick={handleNativeInstall}
                    disabled={isInstalling}
                    className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-neutral-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all cursor-pointer"
                  >
                    <ArrowDownToLine className="w-4 h-4" />
                    <span>{isInstalling ? 'Installing App...' : '1-Click Install to Android Home Screen'}</span>
                  </button>
                ) : (
                  <div className="space-y-2">
                    <div className="text-xs text-neutral-300">
                      To install on your phone right now, open this link in <strong>Chrome</strong>, <strong>Samsung Internet</strong>, or <strong>Edge</strong>:
                    </div>
                    <div className="flex items-center gap-2 p-2 rounded-xl bg-neutral-900 border border-neutral-750">
                      <span className="text-xs font-mono text-emerald-400 truncate flex-1">{currentUrl}</span>
                      <button
                        onClick={handleCopyUrl}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-xs font-bold text-neutral-200 flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Step by Step Android Guide */}
              <div className="p-4 rounded-2xl bg-neutral-850/70 border border-neutral-750 space-y-3">
                <h4 className="text-xs font-black text-neutral-200 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Manual Installation Steps on Android</span>
                </h4>

                <ol className="space-y-2.5 text-xs text-neutral-300 list-decimal list-inside">
                  <li className="leading-relaxed">
                    Open this app in <strong>Google Chrome</strong> or your preferred Android browser.
                  </li>
                  <li className="leading-relaxed">
                    Tap the <strong>three dots menu (⋮)</strong> at the top right of the browser.
                  </li>
                  <li className="leading-relaxed">
                    Tap <strong className="text-white">"Install app"</strong> or <strong className="text-white">"Add to Home screen"</strong>.
                  </li>
                  <li className="leading-relaxed">
                    Android will compile the <strong>HAMBA WebAPK</strong> and add the official icon to your app drawer and home screen.
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 2: Standalone APK Packaging & Tools */}
          {activeTab === 'package' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-neutral-850/80 border border-neutral-750 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-black text-white">Export & Build Standalone APK</h3>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      You can generate a standalone `.apk` file for Google Play or direct sideloading.
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 flex-shrink-0">
                    <Zap className="w-5 h-5" />
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={handleDownloadPackage}
                    className="w-full py-3 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
                  >
                    <ArrowDownToLine className="w-4 h-4 text-emerald-400" />
                    <span>Download Android App Configuration (.json)</span>
                  </button>

                  <a
                    href={`https://www.pwabuilder.com?url=${encodeURIComponent(currentUrl)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
                  >
                    <span>Package APK with PWABuilder (1-Click Free)</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                <div className="pt-2 border-t border-neutral-750 text-[11px] text-neutral-400 space-y-1">
                  <div className="font-bold text-neutral-300">How to generate a standalone APK:</div>
                  <div>1. PWABuilder packages your live URL directly into a signed `.apk` file ready to install on any Android phone.</div>
                  <div>2. Google Bubblewrap CLI can also build a release APK using: <code className="bg-neutral-900 px-1 py-0.5 rounded text-emerald-400">bubblewrap build</code>.</div>
                </div>
              </div>

              {/* Package Details */}
              <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-neutral-400">
                  <span>Package ID</span>
                  <span className="font-mono text-neutral-200">com.hamba.rideshare</span>
                </div>
                <div className="flex items-center justify-between text-neutral-400">
                  <span>App Version</span>
                  <span className="font-mono text-neutral-200">1.0.0 (Release)</span>
                </div>
                <div className="flex items-center justify-between text-neutral-400">
                  <span>Target Platform</span>
                  <span className="font-mono text-emerald-400">Android 8.0+ (API 26+)</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: iOS Installation */}
          {activeTab === 'ios' && (
            <div className="p-4 rounded-2xl bg-neutral-850/80 border border-neutral-750 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Apple className="w-4 h-4 text-neutral-300" />
                <span>Install on Apple iPhone & iPad</span>
              </div>

              <ol className="space-y-3 text-xs text-neutral-300 list-decimal list-inside">
                <li className="leading-relaxed">
                  Open this link in <strong className="text-white">Safari</strong> on your iPhone or iPad.
                </li>
                <li className="leading-relaxed">
                  Tap the <strong className="text-white">Share</strong> button at the bottom navigation bar (square icon with an upward arrow).
                </li>
                <li className="leading-relaxed">
                  Scroll down the share sheet and tap <strong className="text-emerald-400">"Add to Home Screen"</strong>.
                </li>
                <li className="leading-relaxed">
                  Confirm by tapping <strong className="text-white">"Add"</strong> in the top-right corner.
                </li>
              </ol>

              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-750 text-[11px] text-neutral-400 flex items-start gap-2">
                <Info className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <span>
                  The HAMBA app will launch full-screen without any Safari browser bars, with full offline caching and instant access.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-900/90 flex items-center justify-between gap-3">
          <div className="text-[11px] text-neutral-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>PWA & WebAPK Ready</span>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="py-2 px-5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
