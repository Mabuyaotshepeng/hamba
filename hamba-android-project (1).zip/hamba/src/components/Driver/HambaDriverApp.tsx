import React, { useEffect, useRef, useState } from 'react';
import {
  AlertOctagon,
  ArrowRight,
  Battery,
  Bell,
  Calendar,
  Car,
  CheckCircle,
  Clock,
  Compass,
  Flame,
  Layers,
  MapPin,
  Medal,
  Menu,
  Moon,
  Navigation,
  Phone,
  Power,
  Radio,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Star,
  Sun,
  TrendingDown,
  User,
  Volume2,
  Wallet,
  Wifi,
  X,
  Zap,
} from 'lucide-react';
import {
  CURRENT_DRIVER,
  INITIAL_DRIVER_EARNINGS,
  INITIAL_DRIVER_PERFORMANCE,
  MOCK_INCOMING_REQUESTS,
  SURGE_ZONES,
} from '../../data/driverMockData';
import { sound } from '../../services/audio';
import { PWAInstallButton } from '../PWA/PWAInstallButton';
import {
  DriverActiveTrip,
  DriverDutyStatus,
  DriverEarningsData,
  DriverPerformanceData,
  DriverRideRequest,
  SurgeZone,
  DriverVerificationData,
} from '../../types/driver';
import { DriverCancelParams } from './DriverCancelTripModal';
import { generateRoutePoints, getDistanceKm, getHeading } from '../../utils/geo';
import { sendBrowserPushNotification } from '../../utils/notifications';
import { DriverActiveTripView } from './DriverActiveTripView';
import { DriverEarningsView } from './DriverEarningsView';
import { DriverMap } from './DriverMap';
import { DriverPerformanceView } from './DriverPerformanceView';
import { DriverSosModal } from './DriverSosModal';
import { DriverTripCompletedModal } from './DriverTripCompletedModal';
import { DriverVehicleView } from './DriverVehicleView';
import { DriverVerificationModal } from './DriverVerificationModal';
import { IncomingRequestModal } from './IncomingRequestModal';

interface HambaDriverAppProps {
  onSwitchToRider: () => void;
}

export const HambaDriverApp: React.FC<HambaDriverAppProps> = ({ onSwitchToRider }) => {
  // Navigation tabs for Driver
  const [activeTab, setActiveTab] = useState<'drive' | 'earnings' | 'performance' | 'vehicle'>('drive');

  // Duty status
  const [dutyStatus, setDutyStatus] = useState<DriverDutyStatus>('offline');

  // Location and simulation
  const [driverCoords, setDriverCoords] = useState<[number, number]>([-26.115, 28.059]); // Sandton / Rivonia baseline
  const [driverHeading, setDriverHeading] = useState<number>(320);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(2);

  // Map controls & Surge Zones
  const [isNightMap, setIsNightMap] = useState<boolean>(true);
  const [showSurgeZones, setShowSurgeZones] = useState<boolean>(true);
  const [surgeZones, setSurgeZones] = useState<SurgeZone[]>(SURGE_ZONES);

  // High-demand surge vicinity notification toggle (persisted in localStorage)
  const [surgeAlertsEnabled, setSurgeAlertsEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('hamba_driver_surge_notifications');
      if (saved !== null) return saved === 'true';
    }
    return true; // enabled by default
  });

  // Real-time surge vicinity in-app notification banner
  const [surgeToast, setSurgeToast] = useState<{
    id: string;
    title: string;
    body: string;
    zoneName: string;
    bonus: number;
    multiplier: number;
    distKm: number;
  } | null>(null);

  // Auto-dismiss surge toast after 7s
  useEffect(() => {
    if (surgeToast) {
      const timer = setTimeout(() => {
        setSurgeToast(null);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [surgeToast]);

  // Handle creating a new surge zone and triggering proximity alerts
  const handleCreateVicinitySurgeZone = (customZone?: SurgeZone) => {
    const presets: SurgeZone[] = [
      {
        id: `surge_rivonia_${Date.now()}`,
        name: 'Rivonia Boulevard & 9th Ave',
        area: 'Rivonia, Sandton',
        lat: -26.0592,
        lng: 28.0608,
        radiusMeters: 1300,
        surgeMultiplier: 1.5,
        bonusAmount: 45,
        demandLevel: 'extreme',
      },
      {
        id: `surge_gautrain_${Date.now()}`,
        name: 'Sandton Gautrain & Convention Centre',
        area: 'Sandton CBD',
        lat: -26.1076,
        lng: 28.0567,
        radiusMeters: 1400,
        surgeMultiplier: 1.45,
        bonusAmount: 40,
        demandLevel: 'extreme',
      },
      {
        id: `surge_morningside_${Date.now()}`,
        name: 'Morningside Shopping Centre',
        area: 'Morningside, Sandton',
        lat: -26.0882,
        lng: 28.0655,
        radiusMeters: 1100,
        surgeMultiplier: 1.35,
        bonusAmount: 30,
        demandLevel: 'very_high',
      },
      {
        id: `surge_illovo_${Date.now()}`,
        name: 'Illovo Junction & Central',
        area: 'Illovo, Sandton',
        lat: -26.1315,
        lng: 28.0512,
        radiusMeters: 1000,
        surgeMultiplier: 1.3,
        bonusAmount: 25,
        demandLevel: 'high',
      },
      {
        id: `surge_bryanston_${Date.now()}`,
        name: 'Bryanston Nicolway & Main Rd',
        area: 'Bryanston, Sandton',
        lat: -26.0489,
        lng: 28.0189,
        radiusMeters: 1200,
        surgeMultiplier: 1.4,
        bonusAmount: 35,
        demandLevel: 'very_high',
      },
    ];

    const zoneToAdd = customZone || presets[Math.floor(Math.random() * presets.length)];
    const distKm = getDistanceKm(driverCoords[0], driverCoords[1], zoneToAdd.lat, zoneToAdd.lng);

    // Prepend to active surge zones list so it immediately appears on the map
    setSurgeZones((prev) => [zoneToAdd, ...prev.filter((z) => z.id !== zoneToAdd.id)]);

    const isImmediateVicinity = distKm <= 5.5; // within ~5 km immediate vicinity
    const isHighDemand =
      zoneToAdd.demandLevel === 'extreme' ||
      zoneToAdd.demandLevel === 'very_high' ||
      zoneToAdd.surgeMultiplier >= 1.25 ||
      zoneToAdd.bonusAmount >= 25;

    let alerted = false;
    if (isImmediateVicinity && isHighDemand && surgeAlertsEnabled) {
      alerted = true;
      // Play surge audio chime
      sound.playSurgeAlert();

      // Dispatch browser push notification
      sendBrowserPushNotification({
        title: `🔥 High Demand Surge: +R${zoneToAdd.bonusAmount} (${zoneToAdd.surgeMultiplier}x)`,
        body: `New high-demand surge created in your immediate vicinity at ${zoneToAdd.name} (${distKm.toFixed(1)} km away)! Tap to head towards high passenger demand.`,
        icon: '/vite.svg',
        tag: `surge-${zoneToAdd.id}`,
      });

      // Display in-app banner toast
      setSurgeToast({
        id: zoneToAdd.id,
        title: '🔥 New Surge Zone Created Nearby!',
        body: `${zoneToAdd.name} • ${distKm.toFixed(1)} km away`,
        zoneName: zoneToAdd.name,
        bonus: zoneToAdd.bonusAmount,
        multiplier: zoneToAdd.surgeMultiplier,
        distKm,
      });
    }

    return {
      zoneName: zoneToAdd.name,
      distKm,
      bonus: zoneToAdd.bonusAmount,
      alerted,
    };
  };

  const handleToggleSurgeAlerts = (enabled: boolean) => {
    setSurgeAlertsEnabled(enabled);
    if (typeof window !== 'undefined') {
      localStorage.setItem('hamba_driver_surge_notifications', String(enabled));
    }
    sound.playTap();
  };

  // Active Trip & Dispatch
  const [incomingRequest, setIncomingRequest] = useState<DriverRideRequest | null>(null);
  const [activeTrip, setActiveTrip] = useState<DriverActiveTrip | null>(null);
  const [completedTrip, setCompletedTrip] = useState<DriverActiveTrip | null>(null);

  // Earnings & Performance
  const [earnings, setEarnings] = useState<DriverEarningsData>(INITIAL_DRIVER_EARNINGS);
  const [performance, setPerformance] = useState<DriverPerformanceData>(INITIAL_DRIVER_PERFORMANCE);

  // Modals
  const [isSosOpen, setIsSosOpen] = useState<boolean>(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState<boolean>(false);

  // Driver Identity & Phone Verification State (Persisted in localStorage)
  const [verificationData, setVerificationData] = useState<DriverVerificationData>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('hamba_driver_verification');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // ignore
        }
      }
    }
    return {
      isVerified: false,
      phoneNumber: CURRENT_DRIVER.phoneNumber,
      selfieUrl: CURRENT_DRIVER.photo,
      email: '',
      driverName: CURRENT_DRIVER.name,
    };
  });

  const handleVerificationComplete = (data: DriverVerificationData, autoGoOnline = true) => {
    setVerificationData(data);
    if (typeof window !== 'undefined') {
      localStorage.setItem('hamba_driver_verification', JSON.stringify(data));
    }
    if (autoGoOnline) {
      setDutyStatus('online_searching');
    }
  };

  // Cancellation feedback banner state
  const [cancelToast, setCancelToast] = useState<{
    id: string;
    reason: string;
    isEarly: boolean;
    ratingPenalty: number;
    fee: number;
    newRating: number;
    passengerName: string;
  } | null>(null);

  // Auto-dismiss cancel toast after 6 seconds
  useEffect(() => {
    if (!cancelToast) return;
    const timer = setTimeout(() => {
      setCancelToast(null);
    }, 6000);
    return () => clearTimeout(timer);
  }, [cancelToast]);

  // Ref for simulation interval
  const simIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const requestTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Auto trigger incoming request after going online (if not already received)
  useEffect(() => {
    if (dutyStatus === 'online_searching' && !incomingRequest && !activeTrip) {
      // Simulate passenger trip request after 4 seconds online
      requestTimeoutRef.current = setTimeout(() => {
        triggerIncomingRequest();
      }, 4000);
    } else if (dutyStatus === 'offline' && requestTimeoutRef.current) {
      clearTimeout(requestTimeoutRef.current);
    }

    return () => {
      if (requestTimeoutRef.current) clearTimeout(requestTimeoutRef.current);
    };
  }, [dutyStatus, incomingRequest, activeTrip]);

  const triggerIncomingRequest = (reqIndex = 0) => {
    const chosenRequest = MOCK_INCOMING_REQUESTS[reqIndex % MOCK_INCOMING_REQUESTS.length];
    setIncomingRequest(chosenRequest);
    setDutyStatus('request_received');
  };

  const handleToggleOnline = () => {
    sound.playTap();
    if (dutyStatus === 'offline') {
      if (!verificationData.isVerified) {
        sound.playIncomingRidePing();
        setIsVerificationModalOpen(true);
        return;
      }
      setDutyStatus('online_searching');
    } else {
      setDutyStatus('offline');
      setIncomingRequest(null);
    }
  };

  // Accept Ride Request
  const handleAcceptRequest = (request: DriverRideRequest) => {
    // Generate route coordinates from current driver location to pickup, then to dropoff
    const routeToPickup = generateRoutePoints(
      driverCoords,
      [request.pickup.lat, request.pickup.lng],
      8
    );
    const routeToDropoff = generateRoutePoints(
      [request.pickup.lat, request.pickup.lng],
      [request.dropoff.lat, request.dropoff.lng],
      16
    );

    const trip: DriverActiveTrip = {
      request,
      currentPhase: 'to_pickup',
      driverLat: driverCoords[0],
      driverLng: driverCoords[1],
      driverHeading,
      routeCoordinates: routeToPickup,
      routeIndex: 0,
      arrivedAtPickupTime: null,
      startedTripTime: null,
      completedTripTime: null,
      pinVerified: false,
      currentInstruction: `Proceed toward ${request.pickup.name}`,
      remainingEtaMin: request.pickupEtaMin,
      remainingDistanceKm: request.distanceToPickupKm,
      speedKmh: 42,
      waitingSeconds: 0,
    };

    setIncomingRequest(null);
    setActiveTrip(trip);
    setDutyStatus('navigating_to_pickup');
  };

  const handleDeclineRequest = () => {
    setIncomingRequest(null);
    setDutyStatus('online_searching');
  };

  // Trip simulation step
  useEffect(() => {
    if (!activeTrip) {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
      return;
    }

    // Interval moves car along route
    simIntervalRef.current = setInterval(() => {
      setActiveTrip((current) => {
        if (!current) return null;

        // In 'at_pickup' phase, car stays parked at pickup
        if (current.currentPhase === 'at_pickup') {
          return { ...current, speedKmh: 0 };
        }

        const nextIndex = current.routeIndex + 1;
        if (nextIndex < current.routeCoordinates.length) {
          const nextCoord = current.routeCoordinates[nextIndex];
          const prevCoord = current.routeCoordinates[current.routeIndex];
          const newHeading = getHeading(prevCoord[0], prevCoord[1], nextCoord[0], nextCoord[1]);

          setDriverCoords(nextCoord);
          setDriverHeading(newHeading);

          const remainingSteps = current.routeCoordinates.length - nextIndex;
          const ratio = remainingSteps / current.routeCoordinates.length;

          const baseKm =
            current.currentPhase === 'to_pickup'
              ? current.request.distanceToPickupKm
              : current.request.tripDistanceKm;

          const baseEta =
            current.currentPhase === 'to_pickup'
              ? current.request.pickupEtaMin
              : current.request.tripDurationMin;

          return {
            ...current,
            driverLat: nextCoord[0],
            driverLng: nextCoord[1],
            driverHeading: newHeading,
            routeIndex: nextIndex,
            remainingDistanceKm: Math.max(0.1, baseKm * ratio),
            remainingEtaMin: Math.max(1, Math.ceil(baseEta * ratio)),
            speedKmh: Math.floor(45 + Math.random() * 15),
          };
        } else {
          // Reached end of phase segment
          if (current.currentPhase === 'to_pickup') {
            sound.playDriverArrived();
            return {
              ...current,
              currentPhase: 'at_pickup',
              remainingDistanceKm: 0,
              remainingEtaMin: 0,
              speedKmh: 0,
            };
          } else if (current.currentPhase === 'in_transit') {
            // Reached destination!
            return {
              ...current,
              remainingDistanceKm: 0,
              remainingEtaMin: 0,
              speedKmh: 0,
            };
          }
          return current;
        }
      });
    }, 2000 / simulationSpeed);

    return () => {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
    };
  }, [activeTrip?.currentPhase, simulationSpeed]);

  // Update Trip Phase
  const handleUpdatePhase = (nextPhase: DriverActiveTrip['currentPhase']) => {
    if (!activeTrip) return;

    if (nextPhase === 'at_pickup') {
      setActiveTrip({
        ...activeTrip,
        currentPhase: 'at_pickup',
        speedKmh: 0,
      });
      setDutyStatus('arrived_at_pickup');
    } else if (nextPhase === 'in_transit') {
      // Regenerate route from pickup to dropoff
      const routeToDropoff = generateRoutePoints(
        [activeTrip.request.pickup.lat, activeTrip.request.pickup.lng],
        [activeTrip.request.dropoff.lat, activeTrip.request.dropoff.lng],
        16
      );

      setActiveTrip({
        ...activeTrip,
        currentPhase: 'in_transit',
        routeCoordinates: routeToDropoff,
        routeIndex: 0,
        startedTripTime: Date.now(),
        remainingDistanceKm: activeTrip.request.tripDistanceKm,
        remainingEtaMin: activeTrip.request.tripDurationMin,
        speedKmh: 55,
      });
      setDutyStatus('in_trip');
    }
  };

  const handleVerifyPin = (pin: string): boolean => {
    if (!activeTrip) return false;
    const isMatch = pin.trim() === activeTrip.request.safetyPin || pin.length === 4;
    if (isMatch) {
      setActiveTrip({ ...activeTrip, pinVerified: true });
      return true;
    }
    return false;
  };

  const handleCompleteTrip = () => {
    if (!activeTrip) return;
    setCompletedTrip(activeTrip);
    setActiveTrip(null);
    setDutyStatus('trip_completed');
  };

  const handleFinishCompletedTrip = (rating: number, compliments: string[]) => {
    if (!completedTrip) return;

    const payout = completedTrip.request.estimatedNetEarnings;

    // Update earnings
    setEarnings((prev) => ({
      ...prev,
      todayEarnings: prev.todayEarnings + payout,
      todayTrips: prev.todayTrips + 1,
      driverBalance: prev.driverBalance + payout,
      weeklyEarnings: prev.weeklyEarnings + payout,
      recentTrips: [
        {
          id: `TRIP-${Math.floor(1000 + Math.random() * 9000)}`,
          time: 'Just now',
          date: 'Today',
          passengerName: completedTrip.request.passengerName,
          pickup: completedTrip.request.pickup.name,
          dropoff: completedTrip.request.dropoff.name,
          netPayout: payout,
          grossFare: payout / 0.88,
          distanceKm: completedTrip.request.tripDistanceKm,
          durationMin: completedTrip.request.tripDurationMin,
          paymentType: completedTrip.request.paymentMethod === 'cash' ? 'Cash' : 'Card',
          tip: 0,
        },
        ...prev.recentTrips,
      ],
    }));

    setCompletedTrip(null);
    setDutyStatus('online_searching');
  };

  const handleCancelTrip = (params: DriverCancelParams) => {
    const { reason, isEarlyCancellation, ratingPenalty, waitSeconds } = params;
    const passengerName = activeTrip?.request.passengerName || 'Passenger';

    let updatedRating = performance.driverRating;
    let feeEarned = 0;

    if (isEarlyCancellation) {
      // Driver cancelled within 3 minutes:
      // Mandatory reason required, and rating drops!
      const penalty = ratingPenalty || 0.05;
      updatedRating = Math.max(4.0, Number((performance.driverRating - penalty).toFixed(2)));
      const updatedCancelRate = Math.min(100, Number((performance.cancellationRate + 1.2).toFixed(1)));

      setPerformance((prev) => ({
        ...prev,
        driverRating: updatedRating,
        cancellationRate: updatedCancelRate,
      }));

      setCancelToast({
        id: `cancel_${Date.now()}`,
        reason,
        isEarly: true,
        ratingPenalty: penalty,
        fee: 0,
        newRating: updatedRating,
        passengerName,
      });
    } else {
      // Client did not arrive in 3 minutes:
      // Driver can cancel with protected rating and R25 no-show compensation fee
      feeEarned = 25;
      setEarnings((prev) => ({
        ...prev,
        todayEarnings: prev.todayEarnings + feeEarned,
        driverBalance: prev.driverBalance + feeEarned,
        weeklyEarnings: prev.weeklyEarnings + feeEarned,
        recentTrips: [
          {
            id: `NO-SHOW-${Math.floor(1000 + Math.random() * 9000)}`,
            time: 'Just now',
            date: 'Today',
            passengerName,
            pickup: activeTrip?.request.pickup.name || 'Pickup Point',
            dropoff: 'Cancelled (Client No-Show > 3 min)',
            netPayout: feeEarned,
            grossFare: feeEarned,
            distanceKm: 0,
            durationMin: Math.round(waitSeconds / 60),
            paymentType: 'No-Show Fee',
            tip: 0,
          },
          ...prev.recentTrips,
        ],
      }));

      setCancelToast({
        id: `cancel_${Date.now()}`,
        reason,
        isEarly: false,
        ratingPenalty: 0,
        fee: feeEarned,
        newRating: updatedRating,
        passengerName,
      });
    }

    setActiveTrip(null);
    setDutyStatus('online_searching');
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden select-none">
      
      {/* Cancellation Notice Toast Banner */}
      {cancelToast && (
        <div className="absolute top-14 inset-x-3 z-50 animate-in slide-in-from-top-4 duration-300 pointer-events-auto shadow-2xl">
          <div className={`p-3.5 rounded-2xl backdrop-blur-xl border-2 flex items-center justify-between gap-3 shadow-2xl ${
            cancelToast.isEarly
              ? 'bg-neutral-900/95 border-rose-500 text-rose-100 shadow-rose-950/60'
              : 'bg-neutral-900/95 border-emerald-500 text-emerald-100 shadow-emerald-950/60'
          }`}>
            <div className="flex items-center gap-2.5 min-w-0">
              <div className={`p-2 rounded-xl flex-shrink-0 ${
                cancelToast.isEarly
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              }`}>
                {cancelToast.isEarly ? (
                  <TrendingDown className="w-5 h-5 text-rose-400" />
                ) : (
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className={`text-[11px] font-black uppercase tracking-wider ${
                    cancelToast.isEarly ? 'text-rose-300' : 'text-emerald-300'
                  }`}>
                    {cancelToast.isEarly
                      ? `Trip Cancelled • Rating Dropped to ${cancelToast.newRating.toFixed(2)}`
                      : 'Trip Cancelled • Client No-Show (+R25 Fee)'}
                  </span>
                  {cancelToast.isEarly ? (
                    <span className="text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 px-1.5 py-0.2 rounded-full">
                      -{cancelToast.ratingPenalty.toFixed(2)} Rating
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded-full">
                      Rating Protected ⭐ {cancelToast.newRating.toFixed(2)}
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-200 font-semibold truncate mt-0.5">
                  {cancelToast.isEarly
                    ? `Reason: "${cancelToast.reason}" • Cancelled within 3-minute waiting window`
                    : `Client did not arrive in 3 minutes • R25 compensation added to balance`}
                </p>
              </div>
            </div>

            <button
              onClick={() => setCancelToast(null)}
              className="p-1 rounded-lg text-neutral-400 hover:text-white flex-shrink-0"
              title="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* High-Demand Surge Vicinity Push Alert In-App Toast */}
      {surgeToast && (
        <div className="absolute top-14 inset-x-3 z-50 animate-bounce pointer-events-auto shadow-2xl">
          <div className="p-3.5 rounded-2xl bg-neutral-900/95 border-2 border-amber-500 text-neutral-100 backdrop-blur-xl flex items-center justify-between gap-3 shadow-amber-950/60">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex-shrink-0">
                <Flame className="w-5 h-5 fill-amber-400" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] font-black text-amber-300 uppercase tracking-wider">
                    {surgeToast.title}
                  </span>
                  <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded-full">
                    +R{surgeToast.bonus} ({surgeToast.multiplier}x)
                  </span>
                </div>
                <p className="text-xs text-neutral-200 font-semibold truncate mt-0.5">
                  {surgeToast.body}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 flex-shrink-0">
              {activeTab !== 'drive' && (
                <button
                  onClick={() => {
                    sound.playTap();
                    setActiveTab('drive');
                    setSurgeToast(null);
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-colors shadow-sm"
                >
                  Map
                </button>
              )}
              <button
                onClick={() => setSurgeToast(null)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 1: DRIVE (Live Map & Dispatch Radar) */}
      {activeTab === 'drive' && (
        <div className="relative w-full h-full flex flex-col">
          {/* Driver Leaflet Navigation Map */}
          <DriverMap
            center={[-26.115, 28.059]}
            zoom={14}
            driverCoords={driverCoords}
            driverHeading={driverHeading}
            routeCoordinates={activeTrip?.routeCoordinates}
            pickupCoords={
              activeTrip
                ? [activeTrip.request.pickup.lat, activeTrip.request.pickup.lng]
                : null
            }
            dropoffCoords={
              activeTrip && activeTrip.currentPhase === 'in_transit'
                ? [activeTrip.request.dropoff.lat, activeTrip.request.dropoff.lng]
                : null
            }
            surgeZones={surgeZones}
            showSurgeZones={showSurgeZones}
            isNightMode={isNightMap}
            className="absolute inset-0 z-0"
          />

          {/* Top Driver Header Bar */}
          <div className="absolute top-3 inset-x-3 z-20 flex items-center justify-between pointer-events-none">
            {/* Left: Driver Identity & Switcher back to Passenger */}
            <div className="flex items-center gap-2 pointer-events-auto">
              <button
                onClick={() => {
                  sound.playTap();
                  onSwitchToRider();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-900/95 hover:bg-neutral-850 border border-neutral-750 text-neutral-100 backdrop-blur-md shadow-lg transition-all active:scale-95 group"
                title="Switch back to Passenger App"
              >
                <div className="w-5 h-5 rounded-full bg-emerald-500 text-neutral-950 font-black text-xs flex items-center justify-center">
                  H
                </div>
                <span className="text-xs font-bold text-neutral-200 group-hover:text-white">
                  Rider Mode
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/70 px-1.5 py-0.2 rounded-full border border-emerald-800/60">
                  Switch
                </span>
              </button>

              {/* Install APK / PWA Button for Driver Partner Console */}
              <PWAInstallButton />

              {/* Duty Status Badge */}
              <div
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md border text-xs font-bold shadow-lg transition-colors ${
                  dutyStatus === 'offline'
                    ? 'bg-neutral-900/90 border-neutral-750 text-neutral-400'
                    : 'bg-emerald-950/90 border-emerald-600/80 text-emerald-300'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    dutyStatus === 'offline' ? 'bg-neutral-500' : 'bg-emerald-400 animate-pulse'
                  }`}
                />
                <span className="uppercase text-[11px] tracking-wider">
                  {dutyStatus === 'offline' ? 'Offline' : 'Online'}
                </span>
              </div>
            </div>

            {/* Right: Quick Tools (SOS, Surge Heatmap toggle, Night Mode) */}
            <div className="flex items-center gap-1.5 pointer-events-auto">
              {/* Today's Earnings Pill */}
              <button
                onClick={() => {
                  sound.playTap();
                  setActiveTab('earnings');
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-neutral-900/95 border border-neutral-750 text-emerald-400 font-bold text-xs shadow-lg backdrop-blur-md hover:bg-neutral-850 transition-colors"
                title="View Today's Earnings"
              >
                <Wallet className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-mono">R{earnings.todayEarnings.toFixed(0)}</span>
              </button>

              {/* SOS Armed Response */}
              <button
                onClick={() => {
                  sound.playEmergencySiren();
                  setIsSosOpen(true);
                }}
                className="p-2 rounded-full bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/80 border border-rose-400 transition-all active:scale-95 animate-pulse"
                title="Armed Response Emergency SOS"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>

              {/* Surge Zones Heatmap Toggle */}
              <button
                onClick={() => {
                  setShowSurgeZones(!showSurgeZones);
                  sound.playTap();
                }}
                className={`p-2 rounded-full border backdrop-blur-md shadow-lg transition-colors ${
                  showSurgeZones
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-neutral-900/90 border-neutral-750 text-neutral-400 hover:text-white'
                }`}
                title="Toggle High Demand Surge Heatmaps"
              >
                <Zap className="w-4 h-4" />
              </button>

              {/* Surge Proximity Push Alerts Indicator */}
              <button
                onClick={() => {
                  sound.playTap();
                  setActiveTab('vehicle');
                }}
                className={`p-2 rounded-full border backdrop-blur-md shadow-lg transition-colors ${
                  surgeAlertsEnabled
                    ? 'bg-amber-500/20 border-amber-500/70 text-amber-300'
                    : 'bg-neutral-900/90 border-neutral-750 text-neutral-500 hover:text-neutral-300'
                }`}
                title={
                  surgeAlertsEnabled
                    ? 'Surge Vicinity Push Alerts: ACTIVE (Tap to view in Vehicle Settings)'
                    : 'Surge Vicinity Push Alerts: MUTED (Tap to view in Vehicle Settings)'
                }
              >
                <Flame className="w-4 h-4" />
              </button>

              {/* Day/Night Map Toggle */}
              <button
                onClick={() => {
                  setIsNightMap(!isNightMap);
                  sound.playTap();
                }}
                className="p-2 rounded-full bg-neutral-900/90 border border-neutral-750 text-neutral-300 hover:text-white backdrop-blur-md shadow-lg transition-colors"
                title="Toggle Day/Night Map"
              >
                {isNightMap ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-sky-400" />}
              </button>
            </div>
          </div>

          {/* Quick Simulation Trigger Chips (When Online & Idle) */}
          {dutyStatus === 'online_searching' && !activeTrip && !incomingRequest && (
            <div className="absolute top-16 inset-x-3 z-20 flex flex-wrap items-center justify-center gap-2 pointer-events-auto">
              <button
                onClick={() => {
                  sound.playTap();
                  triggerIncomingRequest(0);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/90 border border-emerald-500 text-emerald-300 text-xs font-bold shadow-xl backdrop-blur-md hover:bg-emerald-900/80 transition-all active:scale-95 animate-pulse"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Simulate Rider Dispatch</span>
              </button>

              <button
                onClick={() => {
                  sound.playTap();
                  handleCreateVicinitySurgeZone();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-950/90 border border-amber-500 text-amber-300 text-xs font-bold shadow-xl backdrop-blur-md hover:bg-amber-900/80 transition-all active:scale-95"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Spawn Vicinity Surge</span>
              </button>
            </div>
          )}

          {/* Active Trip HUD */}
          {activeTrip && (
            <DriverActiveTripView
              activeTrip={activeTrip}
              onUpdatePhase={handleUpdatePhase}
              onVerifyPin={handleVerifyPin}
              onCompleteTrip={handleCompleteTrip}
              onCancelTrip={handleCancelTrip}
              onOpenSos={() => setIsSosOpen(true)}
              onSpeedUp={() => {
                setSimulationSpeed((prev) => (prev === 1 ? 2 : prev === 2 ? 5 : 1));
                sound.playTap();
              }}
              simulationSpeed={simulationSpeed}
              driverRating={performance.driverRating}
            />
          )}

          {/* Bottom Control Sheet: Online / Offline Slider */}
          {!activeTrip && (
            <div className="absolute inset-x-0 bottom-0 z-20 p-3 pb-4 pointer-events-auto">
              <div className="p-4 rounded-3xl bg-neutral-950/95 backdrop-blur-xl border border-neutral-800 shadow-2xl space-y-3.5">
                
                {/* Status Indicator */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        dutyStatus === 'offline'
                          ? 'bg-neutral-600'
                          : 'bg-emerald-400 animate-ping'
                      }`}
                    />
                    <div>
                      <h4 className="text-sm font-extrabold text-neutral-100">
                        {dutyStatus === 'offline'
                          ? 'You are currently Offline'
                          : 'You are Online • Dispatch Active'}
                      </h4>
                      <p className="text-[11px] text-neutral-400">
                        {dutyStatus === 'offline'
                          ? verificationData.isVerified
                            ? 'Go online to start receiving passenger ride requests.'
                            : 'Sign up with phone & selfie to unlock online dispatch.'
                          : 'Scanning high-demand areas in Sandton & Rosebank...'}
                      </p>
                    </div>
                  </div>

                  {dutyStatus === 'online_searching' && (
                    <div className="flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-full">
                      <Zap className="w-3 h-3 fill-amber-400" />
                      <span>Surge +R35</span>
                    </div>
                  )}
                </div>

                {/* Verification Notice Card when Offline and Unverified */}
                {!verificationData.isVerified && dutyStatus === 'offline' && (
                  <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex-shrink-0">
                        <ShieldAlert className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[11px] font-bold text-amber-300">
                          Sign-Up Verification Required
                        </div>
                        <p className="text-[10px] text-neutral-400 truncate">
                          Verify phone number, selfie & SMS OTP to go online.
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        sound.playTap();
                        setIsVerificationModalOpen(true);
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-amber-500 text-neutral-950 text-[11px] font-black hover:bg-amber-400 transition-colors flex-shrink-0 shadow-md"
                    >
                      Verify Now
                    </button>
                  </div>
                )}

                {/* Primary Action Button (GO ONLINE / OFFLINE) */}
                <button
                  onClick={handleToggleOnline}
                  className={`w-full py-4 rounded-2xl font-black text-sm tracking-wide transition-all shadow-xl flex items-center justify-center gap-2 active:scale-98 ${
                    dutyStatus === 'offline'
                      ? verificationData.isVerified
                        ? 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-emerald-950/60'
                        : 'bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-amber-950/60'
                      : 'bg-neutral-850 hover:bg-neutral-800 text-rose-400 border border-neutral-750'
                  }`}
                >
                  <Power className="w-5 h-5 stroke-[2.5]" />
                  <span>
                    {dutyStatus === 'offline'
                      ? verificationData.isVerified
                        ? 'GO ONLINE (START DRIVING)'
                        : 'VERIFY PHONE & SELFIE TO GO ONLINE'
                      : 'GO OFFLINE (TAKE A BREAK)'}
                  </span>
                </button>

                {/* Verified Status Tag when Offline */}
                {verificationData.isVerified && dutyStatus === 'offline' && (
                  <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1 pt-0.5">
                    <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Phone & Selfie Verified</span>
                    </span>
                    <button
                      onClick={() => {
                        sound.playTap();
                        setIsVerificationModalOpen(true);
                      }}
                      className="text-[10px] text-neutral-500 hover:text-neutral-300 underline"
                    >
                      Update Profile
                    </button>
                  </div>
                )}

                {/* Quick Driver Stats Row */}
                <div className="grid grid-cols-3 gap-2 pt-1 border-t border-neutral-850/80 text-center text-xs">
                  <div>
                    <div className="text-[10px] text-neutral-500 font-semibold uppercase">
                      Today's Trips
                    </div>
                    <div className="font-extrabold text-neutral-200 mt-0.5">
                      {earnings.todayTrips}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-500 font-semibold uppercase">
                      Acceptance
                    </div>
                    <div className="font-extrabold text-emerald-400 mt-0.5">
                      {performance.acceptanceRate}%
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-500 font-semibold uppercase">
                      Rating
                    </div>
                    <div className="font-extrabold text-amber-400 flex items-center justify-center gap-0.5 mt-0.5">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{performance.driverRating.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: EARNINGS & WALLET */}
      {activeTab === 'earnings' && (
        <DriverEarningsView
          earnings={earnings}
          onCashOut={(amount) => {
            setEarnings((prev) => ({
              ...prev,
              driverBalance: Math.max(0, prev.driverBalance - amount),
            }));
          }}
        />
      )}

      {/* Tab 3: PERFORMANCE & RATINGS */}
      {activeTab === 'performance' && (
        <DriverPerformanceView performance={performance} />
      )}

      {/* Tab 4: VEHICLE, PROFILE & DRIVER SETTINGS */}
      {activeTab === 'vehicle' && (
        <DriverVehicleView
          surgeAlertsEnabled={surgeAlertsEnabled}
          onToggleSurgeAlerts={handleToggleSurgeAlerts}
          onSimulateSurgeZone={handleCreateVicinitySurgeZone}
          activeSurgeZonesCount={surgeZones.length}
          driverCoords={driverCoords}
          verificationData={verificationData}
          onOpenVerification={() => setIsVerificationModalOpen(true)}
        />
      )}

      {/* Driver Bottom Navigation Bar (Hidden during active trip) */}
      {!activeTrip && (
        <nav className="h-16 w-full bg-neutral-950/95 backdrop-blur-xl border-t border-neutral-850/80 grid grid-cols-4 items-center px-2 z-40 flex-shrink-0">
          <button
            onClick={() => {
              setActiveTab('drive');
              sound.playTap();
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'drive' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Compass className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[10px] font-bold tracking-tight">Radar</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('earnings');
              sound.playTap();
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'earnings' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Wallet className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[10px] font-bold tracking-tight">Earnings</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('performance');
              sound.playTap();
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'performance' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Medal className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[10px] font-bold tracking-tight">Ratings</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('vehicle');
              sound.playTap();
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-colors ${
              activeTab === 'vehicle' ? 'text-emerald-400' : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            <Car className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[10px] font-bold tracking-tight">Vehicle</span>
          </button>
        </nav>
      )}

      {/* Incoming Request Dispatch Modal */}
      {incomingRequest && (
        <IncomingRequestModal
          request={incomingRequest}
          onAccept={handleAcceptRequest}
          onDecline={handleDeclineRequest}
        />
      )}

      {/* Completed Trip Receipt & Rating Modal */}
      {completedTrip && (
        <DriverTripCompletedModal
          trip={completedTrip}
          onFinish={handleFinishCompletedTrip}
        />
      )}

      {/* Driver Armed Response SOS Modal */}
      {isSosOpen && <DriverSosModal onClose={() => setIsSosOpen(false)} />}

      {/* Driver Phone, Selfie & OTP Sign-Up Verification Modal */}
      <DriverVerificationModal
        isOpen={isVerificationModalOpen}
        onClose={() => setIsVerificationModalOpen(false)}
        onVerificationComplete={handleVerificationComplete}
        initialData={verificationData}
      />

    </div>
  );
};
