import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Car,
  Clock,
  MapPin,
  Navigation,
  Shield,
  Star,
  User,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { DriverRideRequest } from '../../types/driver';

interface IncomingRequestModalProps {
  request: DriverRideRequest;
  onAccept: (request: DriverRideRequest) => void;
  onDecline: () => void;
}

export const IncomingRequestModal: React.FC<IncomingRequestModalProps> = ({
  request,
  onAccept,
  onDecline,
}) => {
  const [secondsLeft, setSecondsLeft] = useState<number>(request.expiresInSeconds || 15);
  const totalSeconds = request.expiresInSeconds || 15;

  useEffect(() => {
    // Play alert sound on mount
    sound.playIncomingRidePing();
    const soundInterval = setInterval(() => {
      sound.playIncomingRidePing();
    }, 3000);

    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          clearInterval(soundInterval);
          onDecline();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(timer);
      clearInterval(soundInterval);
    };
  }, [onDecline]);

  const percentage = (secondsLeft / totalSeconds) * 100;
  const strokeDashoffset = 283 - (283 * percentage) / 100;

  const handleAccept = () => {
    sound.playTripAccepted();
    onAccept(request);
  };

  const handleDecline = () => {
    sound.playTap();
    onDecline();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-750 sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden flex flex-col text-neutral-100 animate-in slide-in-from-bottom-5 duration-300">
        
        {/* Top Header with Category & Surge */}
        <div className="bg-gradient-to-r from-emerald-950 via-neutral-900 to-emerald-950/80 px-5 py-3 border-b border-emerald-900/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
              Incoming Trip Request
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 text-[11px] font-bold border border-neutral-700">
              {request.category.name}
            </span>
            {request.surgeBonus > 0 && (
              <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[11px] font-bold border border-amber-500/40">
                <Zap className="w-3 h-3 fill-amber-400" />
                +R{request.surgeBonus} Surge
              </span>
            )}
          </div>
        </div>

        {/* Guaranteed Net Payout & Radial Timer Banner */}
        <div className="p-5 flex items-center justify-between border-b border-neutral-800 bg-neutral-900/60">
          <div>
            <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
              Guaranteed Net Payout
            </div>
            <div className="text-3xl font-black text-emerald-400 tracking-tight flex items-baseline gap-1 mt-0.5">
              <span>R{request.estimatedNetEarnings.toFixed(2)}</span>
              <span className="text-xs text-neutral-400 font-medium">after 12% fee</span>
            </div>
            <div className="text-xs text-neutral-300 mt-1 flex items-center gap-2">
              <span className="capitalize font-semibold text-neutral-200">
                {request.paymentMethod === 'cash' ? '💵 Cash Payment' : '💳 In-App Payment'}
              </span>
              <span>•</span>
              <span>{request.tripDistanceKm} km total</span>
            </div>
          </div>

          {/* Radial Countdown Timer */}
          <div className="relative w-18 h-18 flex items-center justify-center flex-shrink-0">
            <svg className="w-18 h-18 -rotate-90 transform" viewBox="0 0 100 100">
              {/* Background track */}
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="8"
                className="text-neutral-800"
                fill="transparent"
              />
              {/* Animated Progress Ring */}
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="8"
                className="text-emerald-400 transition-all duration-1000 ease-linear"
                fill="transparent"
                strokeDasharray="283"
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center font-mono">
              <span className="text-xl font-black text-neutral-100 leading-none">
                {secondsLeft}
              </span>
              <span className="text-[9px] uppercase tracking-wider text-neutral-400">sec</span>
            </div>
          </div>
        </div>

        {/* Passenger Details & Addresses */}
        <div className="p-5 space-y-4">
          {/* Passenger Info */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-850/80 border border-neutral-750">
            <div className="flex items-center gap-3">
              <img
                src={request.passengerPhoto}
                alt={request.passengerName}
                className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500/60 shadow-md"
              />
              <div>
                <div className="text-sm font-bold text-neutral-100 flex items-center gap-1.5">
                  <span>{request.passengerName}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-400 mt-0.5">
                  <span className="flex items-center gap-0.5 text-amber-400 font-bold">
                    <Star className="w-3 h-3 fill-amber-400" />
                    {request.passengerRating.toFixed(2)}
                  </span>
                  <span>•</span>
                  <span>{request.passengerTotalTrips} trips taken</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2.5 py-1 rounded-xl">
              <Shield className="w-3.5 h-3.5" />
              <span>Verified PIN</span>
            </div>
          </div>

          {/* Route details: Pickup & Dropoff */}
          <div className="space-y-3 bg-neutral-950/60 p-3.5 rounded-2xl border border-neutral-800">
            {/* Pickup */}
            <div className="flex items-start gap-3">
              <div className="w-6 flex flex-col items-center mt-0.5">
                <div className="w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-neutral-950 shadow-md" />
                <div className="w-0.5 h-6 bg-neutral-700 my-0.5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-emerald-400">
                    Pickup ({request.distanceToPickupKm} km • {request.pickupEtaMin} min away)
                  </span>
                </div>
                <p className="text-xs font-bold text-neutral-100 truncate mt-0.5">
                  {request.pickup.name}
                </p>
                <p className="text-[11px] text-neutral-400 truncate">
                  {request.pickup.address}
                </p>
              </div>
            </div>

            {/* Dropoff */}
            <div className="flex items-start gap-3">
              <div className="w-6 flex flex-col items-center mt-0.5">
                <div className="w-3.5 h-3.5 rounded-full bg-rose-500 border-2 border-neutral-950 shadow-md" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-rose-400">
                    Destination ({request.tripDistanceKm} km • ~{request.tripDurationMin} min)
                  </span>
                </div>
                <p className="text-xs font-bold text-neutral-100 truncate mt-0.5">
                  {request.dropoff.name}
                </p>
                <p className="text-[11px] text-neutral-400 truncate">
                  {request.dropoff.address}
                </p>
              </div>
            </div>
          </div>

          {/* Passenger Special Note (if any) */}
          {request.specialNote && (
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-amber-950/30 border border-amber-800/40 text-[11px] text-amber-200">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 text-amber-400" />
              <span className="truncate">"{request.specialNote}"</span>
            </div>
          )}
        </div>

        {/* Action Controls: Accept (Primary) & Decline */}
        <div className="p-5 pt-1 bg-neutral-900 border-t border-neutral-800 flex items-center gap-3">
          <button
            onClick={handleDecline}
            className="w-1/3 py-3.5 px-4 rounded-2xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 text-xs font-bold transition-all active:scale-95 border border-neutral-700 flex items-center justify-center gap-1.5"
          >
            <X className="w-4 h-4" />
            <span>Decline</span>
          </button>

          <button
            onClick={handleAccept}
            className="flex-1 py-4 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 text-base font-black tracking-tight transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2"
          >
            <Navigation className="w-5 h-5 fill-neutral-950" />
            <span>ACCEPT RIDE (R{request.estimatedNetEarnings.toFixed(0)})</span>
          </button>
        </div>

      </div>
    </div>
  );
};
