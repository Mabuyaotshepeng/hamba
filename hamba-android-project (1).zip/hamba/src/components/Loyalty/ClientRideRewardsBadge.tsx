import React from 'react';
import { Gift, Sparkles, Car } from 'lucide-react';
import { ClientLoyaltyData } from '../../types';

interface ClientRideRewardsBadgeProps {
  loyalty: ClientLoyaltyData;
  onClick: () => void;
}

export const ClientRideRewardsBadge: React.FC<ClientRideRewardsBadgeProps> = ({
  loyalty,
  onClick,
}) => {
  const isExpired =
    loyalty.freeRideExpiresAt !== null && Date.now() > loyalty.freeRideExpiresAt;
  const isFreeRideUnlocked = loyalty.freeRidesAvailable > 0 && !isExpired;

  // Calculate remaining time for the 7-day free ride
  let daysLeft = 7;
  let timeTag = '7d left';
  if (loyalty.freeRideExpiresAt) {
    const msLeft = Math.max(0, loyalty.freeRideExpiresAt - Date.now());
    const hours = Math.floor(msLeft / (1000 * 60 * 60));
    daysLeft = Math.ceil(msLeft / (1000 * 60 * 60 * 24));
    if (hours < 24) {
      timeTag = `${Math.max(1, hours)}h left`;
    } else {
      timeTag = `${daysLeft}d left`;
    }
  }

  const ridesRemaining = Math.max(0, 10 - loyalty.completedRidesCount);

  if (isFreeRideUnlocked) {
    return (
      <button
        onClick={onClick}
        type="button"
        title="1 Free Ride Active! Max R50 value · 7 days validity. Tap for details."
        className="group relative flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-950/90 via-neutral-900/95 to-emerald-950/90 border border-amber-400/80 text-amber-200 backdrop-blur-md shadow-lg shadow-amber-950/40 hover:border-amber-300 transition-all active:scale-95 text-left cursor-pointer"
      >
        {/* Glowing aura ping */}
        <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-400"></span>
        </span>

        <div className="flex items-center gap-1.5">
          <Gift className="w-3.5 h-3.5 text-amber-400 animate-pulse flex-shrink-0" />
          <span className="text-xs font-black tracking-tight text-amber-300">
            1 Free Ride
          </span>
        </div>

        <span className="text-[10px] text-emerald-300 font-extrabold bg-emerald-950/80 border border-emerald-700/70 px-1.5 py-0.5 rounded-full flex items-center gap-1">
          <span>Max R50</span>
          <span className="text-neutral-500">·</span>
          <span className="text-amber-300">{timeTag}</span>
        </span>
      </button>
    );
  }

  // Counting to 10 completed rides status
  return (
    <button
      onClick={onClick}
      type="button"
      title={`${loyalty.completedRidesCount} of 10 completed rides. Complete 10 to earn 1 Free Ride (Max R50). Tap for details.`}
      className="group flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900/95 border border-neutral-750 hover:border-neutral-600 text-neutral-100 backdrop-blur-md shadow-lg transition-all active:scale-95 text-left cursor-pointer"
    >
      {/* Mini Progress Icon / Dot Track */}
      <div className="relative flex items-center justify-center w-4 h-4 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-[9px] font-black text-emerald-400 flex-shrink-0">
        <Car className="w-2.5 h-2.5 text-emerald-400" />
      </div>

      <div className="flex items-center gap-1">
        <span className="text-xs font-bold tracking-tight text-neutral-100">
          {loyalty.completedRidesCount}/10 Rides
        </span>
      </div>

      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/70 border border-emerald-800/60 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
        <span>{ridesRemaining} to Free</span>
      </span>
    </button>
  );
};
