import React, { useState } from 'react';
import {
  ArrowLeft,
  Banknote,
  Car,
  Check,
  ChevronRight,
  Clock,
  CreditCard,
  Gift,
  ShieldCheck,
  Sparkles,
  Tag,
  Users,
  Wallet,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { ClientLoyaltyData, LocationPoint, PaymentMethod, RideCategory } from '../../types';
import { formatCurrency, getDistanceKm } from '../../utils/geo';

interface RideCategorySelectorProps {
  pickup: LocationPoint;
  dropoff: LocationPoint;
  categories: RideCategory[];
  selectedCategory: RideCategory;
  onSelectCategory: (category: RideCategory) => void;
  selectedPayment: PaymentMethod;
  allPaymentMethods: PaymentMethod[];
  onSelectPayment: (method: PaymentMethod) => void;
  onOpenPaymentPicker: () => void;
  onConfirmRide: (fare: number, discount: number) => void;
  onBack: () => void;
  currencySymbol: string;
  loyalty?: ClientLoyaltyData;
  onRedeemFreeRide?: () => void;
}

export const RideCategorySelector: React.FC<RideCategorySelectorProps> = ({
  pickup,
  dropoff,
  categories,
  selectedCategory,
  onSelectCategory,
  selectedPayment,
  allPaymentMethods,
  onSelectPayment,
  onOpenPaymentPicker,
  onConfirmRide,
  onBack,
  currencySymbol,
  loyalty,
  onRedeemFreeRide,
}) => {
  const isExpired =
    loyalty?.freeRideExpiresAt !== null &&
    loyalty?.freeRideExpiresAt !== undefined &&
    Date.now() > loyalty.freeRideExpiresAt;
  const isFreeRideUnlocked = !!loyalty && loyalty.freeRidesAvailable > 0 && !isExpired;

  const [applyFreeRide, setApplyFreeRide] = useState<boolean>(isFreeRideUnlocked);
  const [promoCode, setPromoCode] = useState('HAMBA20');
  const [promoApplied, setPromoApplied] = useState(!isFreeRideUnlocked);
  const [isPromoOpen, setIsPromoOpen] = useState(false);
  const [promoInput, setPromoInput] = useState('');

  const isCash = selectedPayment.type === 'cash';

  // Calculate distance
  const distanceKm = Math.max(1.5, getDistanceKm(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng));
  const travelDurationMin = Math.round((distanceKm / 32) * 60) + 3;

  // Calculate fare for a category
  const calculateFare = (cat: RideCategory) => {
    const raw = cat.baseFare + distanceKm * cat.perKmRate + travelDurationMin * cat.perMinuteRate;
    return Math.round(raw * cat.surgeMultiplier);
  };

  const selectedFare = calculateFare(selectedCategory);

  // Determine discounts: Free ride covers up to R50. If fare is <= R50, fare is R0!
  let discountAmount = 0;
  let finalFare = selectedFare;

  if (applyFreeRide && isFreeRideUnlocked) {
    discountAmount = Math.min(50, selectedFare);
    finalFare = Math.max(0, selectedFare - discountAmount);
  } else if (promoApplied) {
    discountAmount = Math.round(selectedFare * 0.2);
    finalFare = Math.max(20, selectedFare - discountAmount);
  }

  const handleApplyPromo = () => {
    if (promoInput.trim().toUpperCase() === 'HAMBA50' || promoInput.trim().toUpperCase() === 'HAMBA20') {
      setPromoCode(promoInput.trim().toUpperCase());
      setPromoApplied(true);
      setIsPromoOpen(false);
    } else {
      alert('Invalid code. Try "HAMBA20" or "HAMBA50"!');
    }
  };

  const handleTogglePaymentMode = (mode: 'card' | 'cash') => {
    sound.playTap();
    if (mode === 'cash') {
      const cashMethod = allPaymentMethods.find((m) => m.type === 'cash') || {
        id: 'pm_cash',
        type: 'cash',
        title: 'Cash Payment',
        subtitle: 'Pay driver directly at trip conclusion',
        isDefault: false,
      };
      onSelectPayment(cashMethod);
    } else {
      // Switch back to default card or wallet
      const cardMethod = allPaymentMethods.find((m) => m.type === 'card' || m.type === 'wallet') || allPaymentMethods[0];
      if (cardMethod) {
        onSelectPayment(cardMethod);
      }
    }
  };

  // Helper for vehicle SVG icon
  const getVehicleIcon = (tier: string) => {
    switch (tier) {
      case 'boda':
        return (
          <div className="w-12 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
            <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="5.5" cy="17.5" r="3.5" />
              <circle cx="18.5" cy="17.5" r="3.5" />
              <path d="M15 6h-5l-3 6.5h11.5" />
              <path d="M12 17.5V10" />
            </svg>
          </div>
        );
      case 'xl':
        return (
          <div className="w-12 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.5 8H17V6.5c0-.8-.7-1.5-1.5-1.5h-7C7.7 5 7 5.7 7 6.5V8H4.5C3.7 8 3 8.7 3 9.5v8c0 .8.7 1.5 1.5 1.5h1c.8 0 1.5-.7 1.5-1.5v-.5h10v.5c0 .8.7 1.5 1.5 1.5h1c.8 0 1.5-.7 1.5-1.5v-8c0-.8-.7-1.5-1.5-1.5zM6 15c-.8 0-1.5-.7-1.5-1.5S5.2 12 6 12s1.5.7 1.5 1.5S6.8 15 6 15zm12 0c-.8 0-1.5-.7-1.5-1.5s.7-1.5 1.5-1.5 1.5.7 1.5 1.5-.7 1.5-1.5 1.5z" />
            </svg>
          </div>
        );
      case 'black':
        return (
          <div className="w-12 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="w-12 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z" />
            </svg>
          </div>
        );
    }
  };

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 max-h-[92%] bg-neutral-950/95 backdrop-blur-xl rounded-t-3xl border-t border-neutral-800 shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-300">
      {/* Drag handle & Header */}
      <div className="p-3 pb-2 flex flex-col items-center border-b border-neutral-850">
        <div className="w-10 h-1 rounded-full bg-neutral-700 mb-2" />
        <div className="w-full flex items-center justify-between px-2">
          <button
            onClick={onBack}
            className="p-1.5 -ml-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="text-center">
            <div className="text-xs font-semibold text-neutral-200">Choose a Ride</div>
            <div className="text-[11px] text-neutral-400 flex items-center justify-center gap-1.5">
              <span>{distanceKm} km</span>
              <span>·</span>
              <Clock className="w-3 h-3 text-neutral-500" />
              <span>~{travelDurationMin} mins trip</span>
            </div>
          </div>
          <div className="w-6" />
        </div>
      </div>

      {/* Ride Categories Scrollable List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 max-h-[220px]">
        {categories.map((cat) => {
          const fare = calculateFare(cat);
          const isSelected = selectedCategory.id === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat)}
              className={`w-full p-3 rounded-2xl flex items-center justify-between transition-all border text-left ${
                isSelected
                  ? 'bg-neutral-900 border-emerald-500 shadow-lg shadow-emerald-950/30 ring-1 ring-emerald-500/50'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center gap-3">
                {getVehicleIcon(cat.tier)}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-neutral-100">{cat.name}</span>
                    <span className="text-[11px] text-neutral-400 flex items-center gap-0.5">
                      <Users className="w-3 h-3 text-neutral-500" />
                      {cat.capacity}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 flex items-center gap-1 mt-0.5">
                    <span className="text-emerald-400 font-medium">{cat.etaMinutes} min away</span>
                    <span>·</span>
                    <span className="truncate max-w-[140px]">{cat.popularCarModels.split(',')[0]}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-base font-extrabold text-neutral-100 tracking-tight">
                  {formatCurrency(fare, currencySymbol)}
                </div>
                {cat.surgeMultiplier > 1 && (
                  <span className="text-[10px] text-amber-400 font-medium">Surge ×{cat.surgeMultiplier}</span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Payment Selection Bar */}
      <div className="p-3 border-t border-neutral-850 bg-neutral-900/80 space-y-2.5">
        {/* EXPLICIT RIDER CHOICE: In-App Card vs Cash */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-neutral-400 px-1">
            <span>Payment Method</span>
            <span className={isCash ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
              {isCash ? '💵 Cash to Driver' : '💳 In-App Card'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5 p-1 bg-neutral-950 border border-neutral-800 rounded-xl">
            <button
              type="button"
              onClick={() => handleTogglePaymentMode('card')}
              className={`py-2 px-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                !isCash
                  ? 'bg-emerald-500 text-neutral-950 shadow-md font-extrabold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>In-App Card / Wallet</span>
            </button>

            <button
              type="button"
              onClick={() => handleTogglePaymentMode('cash')}
              className={`py-2 px-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                isCash
                  ? 'bg-amber-400 text-neutral-950 shadow-md font-extrabold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Banknote className="w-3.5 h-3.5" />
              <span>Cash to Driver</span>
            </button>
          </div>
        </div>

        {/* Free Ride Loyalty Voucher Banner */}
        {isFreeRideUnlocked && (
          <div className="p-2.5 rounded-xl bg-gradient-to-r from-amber-950/60 via-neutral-900 to-emerald-950/60 border border-amber-400/60 flex items-center justify-between gap-2 shadow-md">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 flex-shrink-0">
                <Gift className="w-4 h-4" />
              </div>
              <div className="truncate">
                <div className="text-xs font-black text-amber-300 flex items-center gap-1.5 truncate">
                  <span>1 Free Ride Available</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-extrabold">
                    Max R50 Off
                  </span>
                </div>
                <div className="text-[10px] text-neutral-300 truncate">
                  {selectedFare <= 50 ? 'Covers 100% of this trip (R0 total)!' : 'R50 deducted from your total fare'}
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playTap();
                setApplyFreeRide(!applyFreeRide);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex-shrink-0 cursor-pointer ${
                applyFreeRide
                  ? 'bg-amber-400 text-neutral-950 shadow-sm shadow-amber-500/30 font-extrabold'
                  : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-300 border border-neutral-700'
              }`}
            >
              {applyFreeRide ? 'Applied' : 'Apply'}
            </button>
          </div>
        )}

        {/* Selected Payment Details & Promo row */}
        <div className="flex items-center justify-between gap-2">
          {!isCash ? (
            <button
              onClick={onOpenPaymentPicker}
              className="flex-1 flex items-center justify-between p-2 rounded-xl bg-neutral-800/80 border border-neutral-750 hover:bg-neutral-800 transition-colors text-left"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-6 h-6 rounded bg-neutral-700 flex items-center justify-center flex-shrink-0">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-neutral-200 truncate">{selectedPayment.title}</div>
                  <div className="text-[10px] text-emerald-400">Card Vault (Tap to change)</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-400" />
            </button>
          ) : (
            <div className="flex-1 flex items-center gap-2 p-2 rounded-xl bg-amber-950/30 border border-amber-800/50 text-left">
              <Banknote className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <div className="text-[11px] text-amber-200">
                <span>Pay driver exact fare in cash at destination</span>
              </div>
            </div>
          )}

          {/* Promo Code Chip */}
          <button
            onClick={() => setIsPromoOpen(!isPromoOpen)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-medium transition-colors ${
              promoApplied && !applyFreeRide
                ? 'bg-emerald-950/40 border-emerald-800/70 text-emerald-300'
                : 'bg-neutral-800/80 border-neutral-750 text-neutral-300 hover:bg-neutral-800'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>{promoApplied && !applyFreeRide ? promoCode : 'Promo'}</span>
          </button>
        </div>

        {/* Promo code drawer if toggled */}
        {isPromoOpen && (
          <div className="p-2.5 rounded-xl bg-neutral-800/90 border border-neutral-700 flex items-center gap-2 animate-in fade-in duration-200">
            <input
              type="text"
              placeholder="Enter promo code (e.g. HAMBA50)"
              value={promoInput}
              onChange={(e) => setPromoInput(e.target.value)}
              className="flex-1 bg-neutral-900 px-3 py-1.5 text-xs text-white rounded-lg border border-neutral-700 focus:outline-none focus:border-emerald-500 uppercase"
            />
            <button
              onClick={handleApplyPromo}
              className="px-3 py-1.5 text-xs font-bold bg-emerald-500 text-neutral-950 rounded-lg hover:bg-emerald-400 transition-colors"
            >
              Apply
            </button>
          </div>
        )}

        {/* Security / Cash Notice */}
        <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isCash ? 'Cash verified with digital receipt' : 'PCI-DSS encrypted card checkout'}</span>
          </div>
          {applyFreeRide && isFreeRideUnlocked ? (
            <span className="text-amber-300 font-extrabold flex items-center gap-1">
              <Gift className="w-3.5 h-3.5 text-amber-400" />
              <span>Free Ride: -{formatCurrency(discountAmount, currencySymbol)}</span>
            </span>
          ) : (
            promoApplied && (
              <span className="text-emerald-400 font-semibold">
                Save {formatCurrency(discountAmount, currencySymbol)}!
              </span>
            )
          )}
        </div>

        {/* Primary CTA Confirm Ride Button */}
        <button
          onClick={() => {
            if (applyFreeRide && isFreeRideUnlocked) {
              onRedeemFreeRide?.();
            }
            onConfirmRide(finalFare, discountAmount);
          }}
          className={`w-full py-3.5 px-4 rounded-2xl font-bold text-base flex items-center justify-between shadow-xl active:scale-[0.98] transition-all cursor-pointer ${
            applyFreeRide && isFreeRideUnlocked && finalFare === 0
              ? 'bg-gradient-to-r from-amber-400 to-emerald-400 hover:brightness-105 text-neutral-950 shadow-emerald-500/30 font-black'
              : isCash
              ? 'bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-amber-500/20'
              : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950 shadow-emerald-500/20'
          }`}
        >
          <span className="flex items-center gap-2">
            <span>
              {applyFreeRide && isFreeRideUnlocked && finalFare === 0
                ? `Confirm 100% Free Ride (${selectedCategory.name})`
                : `Confirm ${selectedCategory.name} (${isCash ? 'Cash' : 'In-App'})`}
            </span>
          </span>
          <span className="text-lg font-black tracking-tight">
            {finalFare === 0 ? 'FREE (R0.00)' : formatCurrency(finalFare, currencySymbol)}
          </span>
        </button>

      </div>
    </div>
  );
};
