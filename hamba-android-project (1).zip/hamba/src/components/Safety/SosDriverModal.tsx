import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  Bell,
  Check,
  Copy,
  Flame,
  Phone,
  Radio,
  Share2,
  ShieldAlert,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { Driver, LocationPoint } from '../../types';

interface SosDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  driver?: Driver | null;
  currentLocation?: LocationPoint | null;
}

export const SosDriverModal: React.FC<SosDriverModalProps> = ({
  isOpen,
  onClose,
  driver,
  currentLocation,
}) => {
  const [isSirenActive, setIsSirenActive] = useState(false);
  const [silentAlarmSent, setSilentAlarmSent] = useState(false);
  const [armedResponseDispatched, setArmedResponseDispatched] = useState(false);
  const [shareBeaconCopied, setShareBeaconCopied] = useState(false);

  if (!isOpen) return null;

  const lat = driver ? driver.currentLat.toFixed(5) : currentLocation ? currentLocation.lat.toFixed(5) : '-26.10760';
  const lng = driver ? driver.currentLng.toFixed(5) : currentLocation ? currentLocation.lng.toFixed(5) : '28.05670';

  const handleToggleSiren = () => {
    if (!isSirenActive) {
      sound.playEmergencySiren();
      setIsSirenActive(true);
    } else {
      setIsSirenActive(false);
    }
  };

  const handleDispatchArmedResponse = () => {
    sound.playTap();
    setArmedResponseDispatched(true);
  };

  const handleSilentAlarm = () => {
    sound.playTap();
    setSilentAlarmSent(true);
  };

  const handleShareEmergencyBeacon = () => {
    const text = `🚨 HAMBA EMERGENCY SOS: I require immediate armed assistance! Vehicle: ${
      driver ? `${driver.carModel} (${driver.licensePlate})` : 'Hamba Ride'
    }. GPS Location: https://maps.google.com/?q=${lat},${lng}. Driver: ${driver?.name || 'Assigned Driver'}.`;
    navigator.clipboard.writeText(text).catch(() => {});
    setShareBeaconCopied(true);
    setTimeout(() => setShareBeaconCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-neutral-900 border-2 border-rose-600/80 rounded-3xl w-full max-w-sm overflow-hidden shadow-[0_0_50px_rgba(225,29,72,0.4)] flex flex-col max-h-[90vh]">
        {/* Urgent Header */}
        <div className="p-4 bg-gradient-to-r from-rose-950 via-neutral-900 to-rose-950 border-b border-rose-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-lg animate-pulse">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black uppercase tracking-wider text-rose-400">
                  EMERGENCY SOS
                </span>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              </div>
              <div className="text-[11px] text-neutral-300 font-semibold">
                SAPS 10111 & Private Armed Response
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-3.5 overflow-y-auto flex-1">
          {/* Live GPS Telemetry Box */}
          <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs font-mono">
            <div className="flex justify-between text-neutral-400 text-[11px]">
              <span>SOUTH AFRICA LIVE BEACON:</span>
              <span className="text-emerald-400 font-bold">ONLINE (ACCURACY ±3m)</span>
            </div>
            <div className="text-neutral-200 font-bold text-sm">
              LAT: {lat} · LNG: {lng}
            </div>
            {driver && (
              <div className="text-[11px] text-neutral-400 font-sans pt-1 border-t border-neutral-850 flex justify-between">
                <span>Driver: {driver.name}</span>
                <span className="font-mono text-neutral-200 font-bold">{driver.licensePlate}</span>
              </div>
            )}
          </div>

          {/* Primary SAPS Police Dispatch */}
          <button
            onClick={() => {
              if (confirm('Call SAPS Emergency Services (10111)? Your coordinates will be transmitted to South African Police.')) {
                window.location.href = 'tel:10111';
              }
            }}
            className="w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-900/50 active:scale-[0.98] transition-all"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>Call Police Dispatch (10111)</span>
          </button>

          {/* Armed Security Vehicle Dispatch */}
          <button
            onClick={handleDispatchArmedResponse}
            disabled={armedResponseDispatched}
            className={`w-full py-3 px-4 rounded-2xl border text-xs font-bold flex items-center justify-between transition-all ${
              armedResponseDispatched
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                : 'bg-neutral-850 hover:bg-neutral-800 border-neutral-750 text-neutral-100 hover:border-rose-500/50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Radio className={`w-4 h-4 ${armedResponseDispatched ? 'text-emerald-400 animate-spin' : 'text-rose-400'}`} />
              <div className="text-left">
                <div>{armedResponseDispatched ? 'Armed Response Unit Dispatched' : 'Dispatch Armed Security Unit'}</div>
                <div className="text-[10px] text-neutral-400">
                  {armedResponseDispatched ? 'Vehicle ETA ~4 mins to coordinates' : 'Private armed patrol in Sandton/SA metro'}
                </div>
              </div>
            </div>
            {armedResponseDispatched && <Check className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Silent Alarm Trigger (For Driver or Passenger in Danger) */}
          <button
            onClick={handleSilentAlarm}
            disabled={silentAlarmSent}
            className={`w-full py-3 px-4 rounded-2xl border text-xs font-bold flex items-center justify-between transition-all ${
              silentAlarmSent
                ? 'bg-neutral-950 border-emerald-500/70 text-emerald-300'
                : 'bg-neutral-850 hover:bg-neutral-800 border-neutral-750 text-neutral-200'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Bell className="w-4 h-4 text-amber-400" />
              <div className="text-left">
                <div>{silentAlarmSent ? 'Silent Security Alarm Active' : 'Trigger Silent Panic Alarm'}</div>
                <div className="text-[10px] text-neutral-400">
                  {silentAlarmSent ? 'HAMBA SOC monitoring live telemetry' : 'Silently alerts Hamba SOC with zero cabin alert'}
                </div>
              </div>
            </div>
            {silentAlarmSent && <span className="text-[10px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded">SENT</span>}
          </button>

          {/* Siren Deterrence Alarm Toggle */}
          <button
            onClick={handleToggleSiren}
            className={`w-full py-2.5 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
              isSirenActive
                ? 'bg-rose-500 text-neutral-950 border-rose-400 font-bold'
                : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            {isSirenActive ? <Volume2 className="w-4 h-4 animate-bounce" /> : <VolumeX className="w-4 h-4" />}
            <span>{isSirenActive ? 'Siren Active (Tap to Stop)' : 'Sound Audible Deterrent Siren'}</span>
          </button>

          {/* Share Live Emergency Beacon */}
          <button
            onClick={handleShareEmergencyBeacon}
            className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-xs font-semibold text-neutral-300 hover:text-white flex items-center justify-center gap-2 transition-colors"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{shareBeaconCopied ? 'Emergency Beacon Copied to Clipboard!' : 'Share Live GPS Beacon with Contacts'}</span>
          </button>
        </div>

        {/* Footer */}
        <div className="p-3 bg-neutral-950 border-t border-neutral-850 text-center">
          <span className="text-[10px] text-neutral-500">
            Protected by South African Emergency Communications Act & HAMBA 24/7 Rapid Response.
          </span>
        </div>
      </div>
    </div>
  );
};
