import React, { useState, useEffect, useRef } from 'react';
import {
  AlertTriangle,
  ChevronUp,
  Maximize2,
  Navigation,
  Phone,
  ShieldAlert,
  X,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { ActiveTrip } from '../../types';

interface FloatingPipWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onExpand: () => void;
  onOpenSos: () => void;
  activeTrip: ActiveTrip | null;
  currencySymbol: string;
}

export const FloatingPipWidget: React.FC<FloatingPipWidgetProps> = ({
  isOpen,
  onClose,
  onExpand,
  onOpenSos,
  activeTrip,
  currencySymbol,
}) => {
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 20, y: 70 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number }>({
    startX: 0,
    startY: 0,
    initialX: 20,
    initialY: 70,
  });

  const totalJourneySteps = Math.max(1, (activeTrip?.routeCoordinates?.length || 1) - 1);
  const journeyPercent =
    activeTrip?.status === 'completed'
      ? 100
      : activeTrip?.status === 'in_progress'
      ? Math.min(100, Math.max(0, Math.round(((activeTrip?.tripStepIndex || 0) / totalJourneySteps) * 100)))
      : 0;

  if (!isOpen) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    // Prevent dragging when clicking buttons
    if ((e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: position.x,
      initialY: position.y,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;
    setPosition({
      x: Math.max(10, Math.min(window.innerWidth - 300, dragStartRef.current.initialX + deltaX)),
      y: Math.max(10, Math.min(window.innerHeight - 150, dragStartRef.current.initialY + deltaY)),
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        left: `${position.x}px`,
        top: `${position.y}px`,
        zIndex: 9999,
        touchAction: 'none',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      className={`w-72 bg-neutral-900/95 backdrop-blur-xl border border-emerald-500/80 rounded-2xl shadow-[0_15px_40px_rgba(0,0,0,0.8),0_0_15px_rgba(16,185,129,0.3)] select-none transition-shadow ${
        isDragging ? 'cursor-grabbing shadow-2xl scale-[1.02]' : 'cursor-grab'
      }`}
    >
      {/* Top Header of Floating Bubble */}
      <div className="p-2.5 pb-2 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[10px] uppercase font-black tracking-wider text-emerald-400">
            HAMBA OVERLAY · ONLINE
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Emergency SOS button directly on PiP */}
          <button
            onClick={onOpenSos}
            className="p-1 rounded-lg bg-rose-600/30 text-rose-400 hover:bg-rose-600 hover:text-white transition-colors"
            title="Emergency SOS"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
          </button>

          {/* Maximize to full app */}
          <button
            onClick={() => {
              onExpand();
              sound.playTap();
            }}
            className="p-1 rounded-lg bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-750 transition-colors"
            title="Expand App"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          {/* Close PiP */}
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors"
            title="Close Floating Widget"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bubble Content */}
      <div className="p-3 space-y-2">
        {activeTrip ? (
          <>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <img
                  src={activeTrip.driver.photo}
                  alt={activeTrip.driver.name}
                  className="w-8 h-8 rounded-full object-cover border border-emerald-400"
                />
                <div className="min-w-0">
                  <div className="text-xs font-bold text-neutral-100 truncate">
                    {activeTrip.driver.name.split(' ')[0]}
                  </div>
                  <div className="text-[10px] text-neutral-400 font-mono">
                    {activeTrip.driver.licensePlate}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-black text-emerald-400 font-mono">
                  {activeTrip.etaMinutes > 0 ? `~${activeTrip.etaMinutes} MINS` : 'ARRIVED'}
                </div>
                <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-bold">
                  {activeTrip.status === 'driver_arrived'
                    ? 'Waiting Outside'
                    : activeTrip.status === 'in_progress'
                    ? 'On Trip'
                    : 'En Route'}
                </div>
              </div>
            </div>

            {/* Quick route label */}
            <div className="flex items-center gap-1.5 text-[10px] text-neutral-300 bg-neutral-950 px-2 py-1 rounded-lg truncate">
              <Navigation className="w-3 h-3 text-emerald-400 flex-shrink-0" />
              <span className="truncate">
                {activeTrip.status === 'in_progress' ? activeTrip.dropoff.name : activeTrip.pickup.name}
              </span>
            </div>

            {/* Visual Progress Bar in PiP */}
            <div className="space-y-1 pt-1 border-t border-neutral-800/60">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-neutral-400 font-medium">Pickup → Dropoff:</span>
                <span className="text-emerald-400 font-bold font-mono">{journeyPercent}%</span>
              </div>
              <div className="w-full bg-neutral-950 rounded-full h-1.5 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-300 transition-all duration-300 rounded-full"
                  style={{ width: `${journeyPercent}%` }}
                />
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-1">
            <div className="text-xs font-bold text-neutral-100">HAMBA Standby Mode</div>
            <div className="text-[10px] text-neutral-400">
              Online nationwide in South Africa · Ready for bookings
            </div>
          </div>
        )}
      </div>

      {/* Drag instruction notice */}
      <div className="px-3 pb-2 flex items-center justify-between text-[9px] text-neutral-500">
        <span>Drag bubble anywhere on screen</span>
        <span className="text-emerald-500 font-bold">Floating Active</span>
      </div>
    </div>
  );
};
