import React, { useState } from 'react';
import {
  Check,
  CreditCard,
  Lock,
  Plus,
  ShieldCheck,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import { sound } from '../../services/audio';
import { PaymentMethod } from '../../types';
import { formatCurrency } from '../../utils/geo';
import { ThreeDSecureModal } from './ThreeDSecureModal';

interface PaymentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  paymentMethods: PaymentMethod[];
  selectedPayment: PaymentMethod;
  onSelectPayment: (method: PaymentMethod) => void;
  onAddPaymentMethod: (method: PaymentMethod) => void;
  walletBalance: number;
  onTopUpWallet: (amount: number) => void;
  currencySymbol: string;
}

export const PaymentDrawer: React.FC<PaymentDrawerProps> = ({
  isOpen,
  onClose,
  paymentMethods,
  selectedPayment,
  onSelectPayment,
  onAddPaymentMethod,
  walletBalance,
  onTopUpWallet,
  currencySymbol,
}) => {
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [is3DSecureOpen, setIs3DSecureOpen] = useState(false);

  // New card form state
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [saveCard, setSaveCard] = useState(true);

  if (!isOpen) return null;

  const handleCardNumberChange = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 16);
    const formatted = raw.replace(/(\d{4})/g, '$1 ').trim();
    setCardNumber(formatted);
  };

  const handleExpiryChange = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 3) {
      setCardExpiry(`${raw.slice(0, 2)}/${raw.slice(2, 4)}`);
    } else {
      setCardExpiry(raw);
    }
  };

  const handleSaveCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawDigits = cardNumber.replace(/\s/g, '');
    if (rawDigits.length < 15) {
      alert('Please enter a valid 16-digit card number');
      return;
    }
    // Launch 3D-Secure bank verification
    setIs3DSecureOpen(true);
  };

  const handle3DSecureSuccess = () => {
    setIs3DSecureOpen(false);
    const last4 = cardNumber.replace(/\s/g, '').slice(-4) || '8831';
    const isMaster = cardNumber.startsWith('5');
    const brand: 'visa' | 'mastercard' = isMaster ? 'mastercard' : 'visa';

    const newMethod: PaymentMethod = {
      id: `pm_${Date.now()}`,
      type: 'card',
      title: `${brand === 'mastercard' ? 'Mastercard' : 'Visa'} •••• ${last4}`,
      subtitle: '3D Secure v2.2 Tokenized · Active',
      last4,
      expiry: cardExpiry || '12/28',
      brand,
      isDefault: true,
      tokenizedId: `tok_live_${Math.random().toString(36).substring(2, 9)}`,
    };

    onAddPaymentMethod(newMethod);
    onSelectPayment(newMethod);
    setIsAddingCard(false);
    setCardNumber('');
    setCardHolder('');
    setCardExpiry('');
    setCardCvv('');
  };

  return (
    <>
      <div className="absolute inset-0 z-40 bg-neutral-950 flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-neutral-100 text-sm">Secure Payment Vault</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Hamba Wallet Balance Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-neutral-900 to-neutral-850 border border-neutral-750 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-neutral-400 font-medium">Hamba In-App Wallet</div>
                  <div className="text-xl font-black text-neutral-100">
                    {formatCurrency(walletBalance, currencySymbol)}
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full font-bold">
                0% Surcharge
              </div>
            </div>

            {/* Quick Top-Up buttons */}
            <div className="pt-2 border-t border-neutral-800">
              <div className="text-[11px] text-neutral-400 mb-2 font-medium">Instant Top-Up Balance:</div>
              <div className="grid grid-cols-3 gap-2">
                {[100, 250, 500].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => {
                      onTopUpWallet(amt);
                      sound.playTap();
                    }}
                    className="py-1.5 px-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-xs font-bold text-emerald-300 transition-colors flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+{currencySymbol}{amt}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Payment Methods List */}
          <div className="space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-neutral-500 px-1">
              Select Payment Method
            </div>

            {paymentMethods.map((method) => {
              const isSelected = selectedPayment.id === method.id;
              return (
                <button
                  key={method.id}
                  onClick={() => {
                    onSelectPayment(method);
                    sound.playTap();
                  }}
                  className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-neutral-900 border-emerald-500 shadow-md ring-1 ring-emerald-500/30'
                      : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300 flex-shrink-0">
                      {method.type === 'wallet' ? (
                        <Wallet className="w-5 h-5 text-emerald-400" />
                      ) : method.type === 'card' ? (
                        <CreditCard className="w-5 h-5 text-blue-400" />
                      ) : (
                        <Zap className="w-5 h-5 text-amber-400" />
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-xs text-neutral-100 flex items-center gap-2">
                        <span>{method.title}</span>
                        {method.brand && (
                          <span className="text-[10px] text-neutral-400 uppercase font-mono">
                            {method.brand}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-neutral-400 mt-0.5">
                        {method.type === 'wallet'
                          ? `Available: ${formatCurrency(walletBalance, currencySymbol)}`
                          : method.subtitle}
                      </div>
                    </div>
                  </div>

                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center border transition-colors ${
                      isSelected
                        ? 'bg-emerald-500 border-emerald-500 text-neutral-950'
                        : 'border-neutral-700 bg-neutral-800'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Add New Card Section */}
          {!isAddingCard ? (
            <button
              onClick={() => setIsAddingCard(true)}
              className="w-full py-3 px-4 rounded-2xl border border-dashed border-neutral-700 hover:border-emerald-500/70 text-neutral-300 hover:text-emerald-400 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Debit / Credit Card (3DS Protected)</span>
            </button>
          ) : (
            <form
              onSubmit={handleSaveCardSubmit}
              className="p-4 rounded-2xl bg-neutral-900 border border-neutral-750 space-y-3 animate-in fade-in duration-200"
            >
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                <span className="text-xs font-bold text-neutral-200">Enter Card Credentials</span>
                <button
                  type="button"
                  onClick={() => setIsAddingCard(false)}
                  className="text-neutral-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Card Number</label>
                <input
                  type="text"
                  placeholder="4532 •••• •••• 8831"
                  value={cardNumber}
                  onChange={(e) => handleCardNumberChange(e.target.value)}
                  className="w-full mt-1 bg-neutral-950 border border-neutral-750 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-neutral-400 uppercase">Cardholder Name</label>
                <input
                  type="text"
                  placeholder="e.g. S. Dlamini"
                  value={cardHolder}
                  onChange={(e) => setCardHolder(e.target.value)}
                  className="w-full mt-1 bg-neutral-950 border border-neutral-750 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase">Expiry (MM/YY)</label>
                  <input
                    type="text"
                    placeholder="08/29"
                    value={cardExpiry}
                    onChange={(e) => handleExpiryChange(e.target.value)}
                    className="w-full mt-1 bg-neutral-950 border border-neutral-750 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase">CVV / CVC</label>
                  <input
                    type="password"
                    maxLength={4}
                    placeholder="•••"
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                    className="w-full mt-1 bg-neutral-950 border border-neutral-750 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                    required
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-neutral-400 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={saveCard}
                  onChange={(e) => setSaveCard(e.target.checked)}
                  className="accent-emerald-500 rounded"
                />
                <span>Tokenize and save securely for 1-tap booking</span>
              </label>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Verify & Save Card with 3D Secure</span>
              </button>
            </form>
          )}

          {/* Security & Compliance Badges */}
          <div className="p-3 rounded-xl bg-neutral-900/40 border border-neutral-850 flex items-start gap-2.5 text-[11px] text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-neutral-300">Bank-Grade Payment Security:</span>
              <p className="mt-0.5 leading-relaxed">
                All card payments are tokenized via PCI-DSS Level 1 certified gateways. HAMBA never stores raw CVV or magnetic stripe data.
              </p>
            </div>
          </div>
        </div>

        {/* Done Button */}
        <div className="p-4 border-t border-neutral-850 bg-neutral-900">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-100 font-bold text-xs transition-colors"
          >
            Apply Payment Method
          </button>
        </div>
      </div>

      {/* 3D-Secure Bank Modal */}
      <ThreeDSecureModal
        isOpen={is3DSecureOpen}
        onClose={() => setIs3DSecureOpen(false)}
        onSuccess={handle3DSecureSuccess}
        amount={1.0} // Verification test auth
        currencySymbol={currencySymbol}
        cardLast4={cardNumber.replace(/\s/g, '').slice(-4) || '8831'}
      />
    </>
  );
};
