import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { ActiveTrip, Driver, LocationPoint } from '../../types';

interface LiveMapProps {
  center: [number, number];
  zoom: number;
  pickup: LocationPoint | null;
  dropoff: LocationPoint | null;
  activeTrip: ActiveTrip | null;
  nearbyDrivers: Driver[];
  isNightMode?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  className?: string;
}

export const LiveMap: React.FC<LiveMapProps> = ({
  center,
  zoom,
  pickup,
  dropoff,
  activeTrip,
  nearbyDrivers,
  isNightMode = true,
  onMapClick,
  className = '',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Markers & Layers refs
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropoffMarkerRef = useRef<L.Marker | null>(null);
  const activeDriverMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const nearbyCarMarkersRef = useRef<Map<string, L.Marker>>(new Map());

  // 1. Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center,
        zoom,
        zoomControl: false,
        attributionControl: false,
      });

      // CartoDB Dark Matter for sleek modern navigation, or Positron for light mode
      const tileUrl = isNightMode
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';

      const tileLayer = L.tileLayer(tileUrl, {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      tileLayerRef.current = tileLayer;

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (onMapClick) {
          onMapClick(e.latlng.lat, e.latlng.lng);
        }
      });

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // 2. Handle theme toggle (dark vs light tile switch)
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;
    const tileUrl = isNightMode
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';

    tileLayerRef.current.setUrl(tileUrl);
  }, [isNightMode]);

  // 3. Center and zoom sync when changed from outside (e.g. city selector)
  useEffect(() => {
    if (mapInstanceRef.current && !activeTrip) {
      mapInstanceRef.current.setView(center, zoom, { animate: true });
    }
  }, [center, zoom, activeTrip]);

  // 4. Pickup Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (pickup) {
      const pickupIconHtml = `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-8 h-8 rounded-full bg-emerald-500/30 animate-ping"></div>
          <div class="relative flex items-center justify-center w-7 h-7 rounded-full bg-emerald-500 text-white shadow-lg border-2 border-white">
            <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="5" />
            </svg>
          </div>
          <div class="absolute -bottom-6 px-2 py-0.5 bg-neutral-900/90 text-white text-[10px] font-semibold tracking-wide rounded-md border border-neutral-700 shadow-md whitespace-nowrap pointer-events-none">
            PICKUP
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'hamba-pin-container',
        html: pickupIconHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      if (!pickupMarkerRef.current) {
        pickupMarkerRef.current = L.marker([pickup.lat, pickup.lng], { icon: customIcon }).addTo(map);
      } else {
        pickupMarkerRef.current.setLatLng([pickup.lat, pickup.lng]);
        pickupMarkerRef.current.setIcon(customIcon);
      }
    } else if (pickupMarkerRef.current) {
      pickupMarkerRef.current.remove();
      pickupMarkerRef.current = null;
    }
  }, [pickup]);

  // 5. Dropoff Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (dropoff) {
      const dropoffIconHtml = `
        <div class="relative flex items-center justify-center">
          <div class="relative flex items-center justify-center w-7 h-7 rounded-full bg-rose-500 text-white shadow-lg border-2 border-white">
            <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <rect x="7" y="7" width="10" height="10" rx="2" />
            </svg>
          </div>
          <div class="absolute -bottom-6 px-2 py-0.5 bg-neutral-900/90 text-white text-[10px] font-semibold tracking-wide rounded-md border border-neutral-700 shadow-md whitespace-nowrap pointer-events-none">
            DESTINATION
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'hamba-pin-container',
        html: dropoffIconHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      if (!dropoffMarkerRef.current) {
        dropoffMarkerRef.current = L.marker([dropoff.lat, dropoff.lng], { icon: customIcon }).addTo(map);
      } else {
        dropoffMarkerRef.current.setLatLng([dropoff.lat, dropoff.lng]);
        dropoffMarkerRef.current.setIcon(customIcon);
      }
    } else if (dropoffMarkerRef.current) {
      dropoffMarkerRef.current.remove();
      dropoffMarkerRef.current = null;
    }
  }, [dropoff]);

  // 6. Draw Polyline Route
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (activeTrip && activeTrip.routeCoordinates && activeTrip.routeCoordinates.length > 1) {
      if (!routePolylineRef.current) {
        routePolylineRef.current = L.polyline(activeTrip.routeCoordinates, {
          color: '#10b981',
          weight: 5,
          opacity: 0.85,
          lineCap: 'round',
          lineJoin: 'round',
          dashArray: activeTrip.status === 'driver_arriving' ? '6, 8' : undefined,
        }).addTo(map);
      } else {
        routePolylineRef.current.setLatLngs(activeTrip.routeCoordinates);
        routePolylineRef.current.setStyle({
          color: activeTrip.status === 'in_progress' ? '#10b981' : '#38bdf8',
          dashArray: activeTrip.status === 'driver_arriving' ? '6, 8' : undefined,
        });
      }

      // Auto-fit bounds comfortably with bottom sheet padding
      try {
        const bounds = L.latLngBounds(activeTrip.routeCoordinates);
        map.fitBounds(bounds, {
          paddingBottomRight: [20, 260],
          paddingTopLeft: [20, 70],
          maxZoom: 16,
          animate: true,
        });
      } catch {
        // Safe fallback
      }
    } else if (pickup && dropoff) {
      // Preview polyline between pickup & dropoff
      const routePreview = [
        [pickup.lat, pickup.lng],
        [(pickup.lat + dropoff.lat) / 2 + 0.005, (pickup.lng + dropoff.lng) / 2 - 0.005],
        [dropoff.lat, dropoff.lng],
      ] as [number, number][];

      if (!routePolylineRef.current) {
        routePolylineRef.current = L.polyline(routePreview, {
          color: '#10b981',
          weight: 4,
          opacity: 0.75,
          lineCap: 'round',
        }).addTo(map);
      } else {
        routePolylineRef.current.setLatLngs(routePreview);
      }

      try {
        const bounds = L.latLngBounds([
          [pickup.lat, pickup.lng],
          [dropoff.lat, dropoff.lng],
        ]);
        map.fitBounds(bounds, {
          paddingBottomRight: [30, 240],
          paddingTopLeft: [30, 60],
          maxZoom: 15,
        });
      } catch {
        // Safe fallback
      }
    } else if (routePolylineRef.current) {
      routePolylineRef.current.remove();
      routePolylineRef.current = null;
    }
  }, [activeTrip?.routeCoordinates, activeTrip?.status, pickup, dropoff]);

  // 7. Active Driver Real-Time Animated Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (activeTrip && activeTrip.driverCoordinates) {
      const heading = activeTrip.driverHeading || 0;
      const isArrived = activeTrip.status === 'driver_arrived';

      const driverIconHtml = `
        <div class="relative flex items-center justify-center">
          ${isArrived ? '<div class="absolute w-12 h-12 rounded-full bg-emerald-400/40 animate-ping"></div>' : ''}
          <div class="hamba-car-marker relative flex items-center justify-center w-11 h-11 bg-neutral-900 rounded-full shadow-2xl border-2 border-emerald-400" style="transform: rotate(${heading}deg);">
            <svg class="w-6 h-6 text-emerald-400" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z"/>
              <circle cx="7.5" cy="14.5" r="1.5"/>
              <circle cx="16.5" cy="14.5" r="1.5"/>
            </svg>
          </div>
          <div class="absolute -top-7 px-2 py-0.5 bg-emerald-500 text-neutral-950 text-[10px] font-bold rounded-full shadow-md whitespace-nowrap">
            ${activeTrip.driver.name.split(' ')[0]} · ${activeTrip.driver.licensePlate}
          </div>
        </div>
      `;

      const driverIcon = L.divIcon({
        className: 'hamba-pin-container',
        html: driverIconHtml,
        iconSize: [44, 44],
        iconAnchor: [22, 22],
      });

      if (!activeDriverMarkerRef.current) {
        activeDriverMarkerRef.current = L.marker(activeTrip.driverCoordinates, { icon: driverIcon }).addTo(map);
      } else {
        activeDriverMarkerRef.current.setLatLng(activeTrip.driverCoordinates);
        activeDriverMarkerRef.current.setIcon(driverIcon);
      }
    } else if (activeDriverMarkerRef.current) {
      activeDriverMarkerRef.current.remove();
      activeDriverMarkerRef.current = null;
    }
  }, [activeTrip?.driverCoordinates, activeTrip?.driverHeading, activeTrip?.status]);

  // 8. Roaming Nearby Drivers on Idle Map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (activeTrip) {
      // Clear roaming drivers when on an active trip
      nearbyCarMarkersRef.current.forEach((marker) => marker.remove());
      nearbyCarMarkersRef.current.clear();
      return;
    }

    // Render roaming cars
    const currentIds = new Set(nearbyDrivers.map((d) => d.id));

    // Remove old
    nearbyCarMarkersRef.current.forEach((marker, id) => {
      if (!currentIds.has(id)) {
        marker.remove();
        nearbyCarMarkersRef.current.delete(id);
      }
    });

    // Add or update
    nearbyDrivers.forEach((driver) => {
      const heading = driver.heading || 0;
      const carHtml = `
        <div class="hamba-car-marker flex items-center justify-center w-8 h-8 rounded-full bg-neutral-900/90 border border-neutral-600 shadow-md" style="transform: rotate(${heading}deg);">
          <svg class="w-4 h-4 text-emerald-400" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.22.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4.66l.12-.34h13.77l.11.34V17z"/>
          </svg>
        </div>
      `;

      const carIcon = L.divIcon({
        className: 'hamba-pin-container',
        html: carHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const existingMarker = nearbyCarMarkersRef.current.get(driver.id);
      if (existingMarker) {
        existingMarker.setLatLng([driver.currentLat, driver.currentLng]);
        existingMarker.setIcon(carIcon);
      } else {
        const marker = L.marker([driver.currentLat, driver.currentLng], { icon: carIcon }).addTo(map);
        nearbyCarMarkersRef.current.set(driver.id, marker);
      }
    });
  }, [nearbyDrivers, activeTrip]);

  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      <div ref={mapContainerRef} className="w-full h-full" />
    </div>
  );
};
